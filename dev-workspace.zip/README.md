# Paragon CRM + Job P&L

Single-tenant job tracker for Paragon Exteriors LLC: one system from first call
to final dollar. A job is entered once; the pipeline board, job costing, and
P&L all read the same record.

## Run

```bash
npm install
npm start          # http://localhost:3000
npm test           # end-to-end smoke tests
```

Locally, data lives in `data/pgdata` (embedded PGlite Postgres, created on
first run) and uploads in `data/uploads/`.

## Deploy — Vercel + Neon (the only supported stack)

Production runs 100% on Vercel: the whole Express app is one serverless
function (`api/index.js`), `public/` is served from the CDN, and all data
lives in **Neon Postgres** (`DATABASE_URL`, pooled) so nothing is wiped by a
redeploy. Uploads persist in **Vercel Blob** when `BLOB_READ_WRITE_TOKEN` is
set. Schema + seed run automatically on cold start against an empty database.

## What's here (MVP scope)

- **Pipeline board** — jobs by derived status: Lead → Proposal Sent → Signed →
  Scheduled → In Progress → Completed → Paid. Status is computed from the
  job's dates and payments, never hand-set.
- **Job detail** — contact, scope quantities, payments (Deposit / Additional /
  Final, or any number of rows), material documents, expenses, and computed
  Balance Owed, Material/Labor/Dumpster cost, Net Profit and margin.
- **Material documents** — modeled on the ABC Supply quote: header
  (document #, type, fuel surcharge, tax) plus SKU line items. Subtotal and
  total are computed. Line items carry an optional trade tag for a future
  per-trade cost split.
- **P&L table** — one row per completed job, date-range filter, totals row.
- **Expenses** — entry form with optional job link (job-linked = direct job
  cost, unlinked = overhead), receipt upload, monthly view by category, and
  CSV export with QuickBooks account-type flags. Owner's Draw and Partner
  Capital Investment are marked `equity` — same entry screen, but they never
  hit job cost or the P&L, and export flagged for the bookkeeper.
- **Reference lists** — contractors (specialties, license/insurance expiry
  with lapsed-doc flags, insurance/W9/license uploads), dumpster vendors with
  extensible sizes, suppliers (ABC Supply Toms River seeded), scope types,
  expense categories. Every list is add-a-row: data, not schema.

## Conventions

- All money is integer cents in the database and API; dollars exist only in
  the UI. No float math on currency.
- To avoid double-counting job costs: enter supplier material invoices as
  Material Documents on the job; use the "Supplier Payment" expense category
  only for account-level payments not tied to a material document.

## Not yet built (per the brief)

- PDF upload → auto-extracted line items (manual entry ships first).
- Per-trade cost split within a job (trade tags are captured, not reported).
- Direct QuickBooks sync (CSV export is phase 1; sync after the category
  structure survives a month of real use).
- Logins/permissions (single-tenant, pending open question 5).
- Auto-created Lead records from the website / AI receptionist — the Job
  record already accepts a row with only Name + Phone to support this.

## Open questions for Joe

Tracked in the design brief (section 8); the schema hedges where answers are
pending — e.g. payments are rows (not three fixed fields) and "Job Cost" /
"Job Total" are treated as one field, the contract price.
