// Dev Dechado's endpoint: admin-only, and a friendly setup reply (not an
// error) when ANTHROPIC_API_KEY is missing.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

test('dev-agent: admin-gated, graceful no-key reply', async () => {
  delete process.env.ANTHROPIC_API_KEY;
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = `http://localhost:${server.address().port}`;
  const post = (cookie, body) => fetch(base + '/api/dev-agent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) },
    body: JSON.stringify(body),
  });
  try {
    assert.equal((await post(null, { messages: '[]' })).status, 401);

    const r = await fetch(base + '/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
    });
    const cookie = r.headers.get('set-cookie').split(';')[0];

    const reply = await post(cookie, { messages: JSON.stringify([{ role: 'user', content: 'status' }]) });
    assert.equal(reply.status, 200);
    const data = await reply.json();
    assert.match(data.reply, /ANTHROPIC_API_KEY/);
  } finally { server.close(); }
});
