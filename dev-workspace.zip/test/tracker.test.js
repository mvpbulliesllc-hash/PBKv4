// P&L Job Tracker: Joe's spreadsheet must go in messy and come back out
// identical — exact header order (including "Interior Repir"), totals row,
// computed profit. Plus PIN login and audit fields.
const { test } = require('node:test');
const assert = require('node:assert');
const XLSX = require('xlsx');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

let COOKIE = '';
async function login(server, email = 'j@ecoaisolutions.com', pw = PW) {
  const res = await fetch(`http://localhost:${server.address().port}/api/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: pw }),
  });
  COOKIE = res.headers.get('set-cookie').split(';')[0];
  return res;
}
async function req(server, method, url, body) {
  const res = await fetch(`http://localhost:${server.address().port}${url}`, {
    method, headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
    body: body ? JSON.stringify(body) : undefined,
  });
  const ct = res.headers.get('content-type') || '';
  return { status: res.status, res,
    body: ct.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer()) };
}

// Joe's sheet, warts and all: misspelled header, trailing spaces, $ and
// commas, US dates, a blank spacer row, computed columns he typed by hand.
const JOES_SHEET = [
  'Date Signed,Date Completed ,Customer Name,Job Total,Interior Repir,Bathroom,Windows Quantity,Deck Feet,Siding Feet,Roof SQ Size,Material Cost,Labor Cost,Dumpster Cost,Net Profit,Cost,Profit,Notes',
  '1/5/2026,1/20/2026,"Smith, Bill","$18,500.00",$0.00,$0.00,0,0,0,32,"$6,200.00","$4,000.00",$550.00,"$7,750.00",58%,42%,gate code 4411',
  ',,,,,,,,,,,,,,,,',
  '2/10/2026,,Rosa Delgado,"$9,800",,"$2,500",8,,,,"$3,100","$2,800",$0,,,,waiting on windows',
].join('\r\n');

test('tracker: import Joe\'s messy sheet → export .xlsx in his exact format → re-import idempotently', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);

    // Dry run preview: "here's what I found".
    let r = await req(server, 'POST', '/api/tracker/import', { csv: JOES_SHEET, dry_run: true });
    assert.equal(r.status, 200);
    assert.equal(r.body.count, 2);                         // blank row skipped
    assert.ok(r.body.headers_matched.includes('Interior Repir'));
    assert.deepEqual(r.body.headers_ignored, []);          // computed cols recognized, not "ignored"
    assert.equal((await req(server, 'GET', '/api/tracker/jobs')).body.length, 0);

    // Real import.
    r = await req(server, 'POST', '/api/tracker/import', { csv: JOES_SHEET });
    assert.equal(r.body.created, 2);
    const jobs = (await req(server, 'GET', '/api/tracker/jobs')).body;
    const bill = jobs.find(j => j.customer_name === 'Smith, Bill');
    assert.equal(bill.date_signed, '2026-01-05');
    assert.equal(bill.job_total_cents, 1850000);
    assert.equal(bill.roof_sq_size, 32);
    // Computed, never trusted from his hand-typed column:
    assert.equal(bill.net_profit_cents, 1850000 - 620000 - 400000 - 55000);
    assert.equal(bill.profit_pct, +((bill.net_profit_cents / 1850000) * 100).toFixed(1));
    assert.ok(bill.created_by);                            // audit trail

    // Export: exact column order incl. the misspelling, plus a totals row.
    r = await req(server, 'GET', '/api/tracker/export.xlsx');
    assert.equal(r.status, 200);
    const wb = XLSX.read(r.body, { type: 'buffer' });
    const grid = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
    assert.deepEqual(grid[0], ['Date Signed', 'Date Completed', 'Customer Name', 'Job Total',
      'Interior Repir', 'Bathroom', 'Windows Quantity', 'Deck Feet', 'Siding Feet', 'Roof SQ Size',
      'Material Cost', 'Labor Cost', 'Dumpster Cost', 'Net Profit', 'Cost', 'Profit', 'Notes']);
    const totals = grid[grid.length - 1];
    assert.equal(totals[2], 'TOTALS');   // dollar-value assertions in the next test
  } finally { server.close(); }
});

test('tracker: export totals + round trip + add-a-job math + summary', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);
    await req(server, 'POST', '/api/tracker/import', { csv: JOES_SHEET });

    let r = await req(server, 'GET', '/api/tracker/export.xlsx');
    const wb = XLSX.read(r.body, { type: 'buffer' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const grid = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    const totals = grid[grid.length - 1];
    assert.equal(totals[3], 18500 + 9800);                 // Job Total total, dollars
    assert.equal(totals[13], 7750 + (9800 - 3100 - 2800)); // Net Profit total

    // Round trip: re-import the exported .xlsx → updates, no duplicates.
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    const fd = new FormData();
    fd.append('file', new Blob([buf]), 'export.xlsx');
    const res = await fetch(`http://localhost:${server.address().port}/api/tracker/import`, {
      method: 'POST', headers: { Cookie: COOKIE }, body: fd,
    });
    const back = await res.json();
    assert.equal(back.created, 0);
    assert.equal(back.updated, 2);
    assert.equal((await req(server, 'GET', '/api/tracker/jobs')).body.length, 2);

    // Add-a-job: computed live, Joe never does math.
    r = await req(server, 'POST', '/api/tracker/jobs', {
      customer_name: 'New Guy', date_signed: '2026-07-01', job_total_cents: 1000000,
      material_cost_cents: 300000, labor_cost_cents: 250000, dumpster_cost_cents: 50000,
    });
    assert.equal(r.status, 201);
    assert.equal(r.body.net_profit_cents, 400000);
    assert.equal(r.body.cost_pct, 60);
    assert.equal(r.body.profit_pct, 40);

    // Summary has months array + current-month rollup.
    r = await req(server, 'GET', '/api/tracker/summary');
    assert.equal(r.body.months.length, 6);
    assert.equal(r.body.total_jobs, 3);
  } finally { server.close(); }
});

test('PIN login: 4 digits in, year-long session out; bad PIN rejected; tracker is staff-only', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = () => `http://localhost:${server.address().port}`;
  try {
    await login(server);
    const users = (await req(server, 'GET', '/api/users')).body;
    const joe = users.find(u => u.email.startsWith('joe@'));
    await req(server, 'PUT', `/api/users/${joe.id}`, { pin: '4411' });

    // Wrong PIN → 401. Right PIN → logged in as Joe.
    let res = await fetch(base() + '/api/login-pin', { method: 'POST',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: '9999' }) });
    assert.equal(res.status, 401);
    res = await fetch(base() + '/api/login-pin', { method: 'POST',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: '4411' }) });
    assert.equal(res.status, 200);
    assert.match(res.headers.get('set-cookie'), /Max-Age=31536000/);
    const joeCookie = res.headers.get('set-cookie').split(';')[0];
    const me = await (await fetch(base() + '/api/me', { headers: { Cookie: joeCookie } })).json();
    assert.equal(me.email, joe.email);

    // Contractor role can't touch the tracker.
    const c = await req(server, 'POST', '/api/contractors',
      { name: 'Sub T', specialty_ids: [1], login_email: 'subt@x.com' });
    await login(server, 'subt@x.com', c.body.login.temp_password);
    assert.equal((await req(server, 'GET', '/api/tracker/jobs')).status, 403);
  } finally { server.close(); COOKIE = ''; }
});
