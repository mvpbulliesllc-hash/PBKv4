// /join self-serve onboarding portal: signup gives an onboarding-only
// account + wizard link, and that account can reach NOTHING else.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');

const jreq = (base, url, body, cookie) => fetch(base + url, {
  method: body ? 'POST' : 'GET',
  headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
  body: body ? JSON.stringify(body) : undefined,
});

test('join portal: signup → onboarding wizard link, locked out of everything else', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    // Signup as a 1099 vendor.
    let r = await jreq(base, '/api/join/signup',
      { name: 'Shore Dumpsters', email: 'dump@shore.com', password: 'secret1', worker_type: 'vendor' });
    assert.equal(r.status, 201);
    const { link } = await r.json();
    assert.match(link, /^\/onboard\/[0-9a-f-]{36}$/);
    const cookie = r.headers.get('set-cookie').split(';')[0];

    // The wizard token works (public endpoint) and carries the classification.
    const token = link.split('/').pop();
    r = await jreq(base, `/api/onboard/${token}`);
    assert.equal(r.status, 200);
    assert.equal((await r.json()).data.worker_type, 'vendor');

    // Logged in, but onboarding-only: /api/me ok, everything else 403.
    assert.equal((await jreq(base, '/api/me', null, cookie)).status, 200);
    for (const path of ['/api/jobs', '/api/tracker/jobs', '/api/expenses', '/api/leads', '/api/users']) {
      assert.equal((await jreq(base, path, null, cookie)).status, 403, path);
    }
    r = await jreq(base, '/api/assistant', {}, cookie);
    assert.equal(r.status, 403);

    // Duplicate signup rejected; login returns the SAME invite (no dupes).
    assert.equal((await jreq(base, '/api/join/signup',
      { name: 'x', email: 'dump@shore.com', password: 'secret1' })).status, 400);
    r = await jreq(base, '/api/join/login', { email: 'dump@shore.com', password: 'secret1' });
    assert.equal(r.status, 200);
    assert.equal((await r.json()).link, link);

    // Google sign-in gracefully off without GOOGLE_CLIENT_ID.
    r = await jreq(base, '/api/join/config');
    assert.equal((await r.json()).google_client_id, null);
    assert.equal((await jreq(base, '/api/join/google', { credential: 'x' })).status, 503);

    // The public /join page serves.
    assert.equal((await fetch(base + '/join')).status, 200);
  } finally { server.close(); }
});
