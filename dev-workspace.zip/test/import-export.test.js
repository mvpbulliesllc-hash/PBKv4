// CRM sheet import/export: the "CRM Outline" column layout must round-trip —
// import a sheet the office made in Excel, export it back in the same shape,
// and re-importing an export must update (not duplicate) jobs.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

let COOKIE = '';
async function login(server) {
  const res = await fetch(`http://localhost:${server.address().port}/api/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
  });
  COOKIE = res.headers.get('set-cookie').split(';')[0];
}
async function req(server, method, url, body) {
  const res = await fetch(`http://localhost:${server.address().port}${url}`, {
    method, headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: res.headers.get('content-type')?.includes('json') ? await res.json() : await res.text() };
}

const SHEET = [
  'Name,Phone Number,Email,Address,Scope of Work,Proposal Sent (Date),Signed Contract,Sub Assigned,Job Cost,Schedule Date,Completed Date,Deposit,Additional Payment,Final Payment,Balance Owed,Notes',
  '"Smith, Jane",732-555-0100,jane@x.com,12 Main St,Roof,6/1/2026,6/5/2026,Shore Roofing LLC,"$18,500.00",6/20/2026,6/25/2026,"$9,250.00",,"$9,250.00",0.00,Key under mat',
  'Bob Builderfan,848-555-0177,,9 Bay Ave,Siding,,,,"12,000",,,,,,,"Call after 5"',
  'EXAMPLE - Jane Homeowner (this row is ignored on import),1,,,,,,,,,,,,,,',
].join('\r\n');

test('CRM Outline sheet imports, exports in the same format, and re-imports idempotently', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);

    // Dry run: previews without writing.
    let r = await req(server, 'POST', '/api/jobs/import', { csv: SHEET, dry_run: true });
    assert.equal(r.status, 200);
    assert.equal(r.body.created, 2);
    assert.equal(r.body.skipped, 1);              // EXAMPLE row
    assert.deepEqual(r.body.new_subs, ['Shore Roofing LLC']);
    assert.equal((await req(server, 'GET', '/api/jobs')).body.length, 0);

    // Real import.
    r = await req(server, 'POST', '/api/jobs/import', { csv: SHEET });
    assert.equal(r.body.created, 2);
    const jobs = (await req(server, 'GET', '/api/jobs')).body;
    assert.equal(jobs.length, 2);
    const jane = jobs.find(j => j.customer_name === 'Smith, Jane');
    assert.equal(jane.job_total_cents, 1850000);
    assert.equal(jane.payments_cents, 1850000);   // deposit + final
    assert.equal(jane.balance_owed_cents, 0);
    assert.equal(jane.status, 'Paid');
    assert.equal(jane.proposal_sent, '2026-06-01');
    const subs = (await req(server, 'GET', '/api/contractors')).body;
    assert.ok(subs.find(c => c.name === 'Shore Roofing LLC'));
    assert.equal(jane.contractor_id, subs.find(c => c.name === 'Shore Roofing LLC').id);

    // Export: exact CRM Outline header, extras after Notes, money as plain numbers.
    r = await req(server, 'GET', '/api/jobs/export.csv');
    assert.equal(r.status, 200);
    const lines = r.body.split('\r\n');
    assert.equal(lines[0],
      'Name,Phone Number,Email,Address,Scope of Work,Proposal Sent (Date),Signed Contract,Sub Assigned,Job Cost,Schedule Date,Completed Date,Deposit,Additional Payment,Final Payment,Balance Owed,Notes,City,State,Zip,Contacted Date,Inspection Date,Status');
    assert.match(r.body, /"Smith, Jane",732-555-0100,jane@x\.com,12 Main St,Roof,2026-06-01,2026-06-05,Shore Roofing LLC,18500\.00/);
    assert.match(r.body, /Paid/);

    // Re-import the export: updates, no duplicates.
    r = await req(server, 'POST', '/api/jobs/import', { csv: r.body });
    assert.equal(r.body.created, 0);
    assert.equal(r.body.updated, 2);
    assert.equal((await req(server, 'GET', '/api/jobs')).body.length, 2);
    // Payments not duplicated either.
    const j = (await req(server, 'GET', `/api/jobs/${jane.id}`)).body;
    assert.equal(j.payments_cents, 1850000);
    assert.equal(j.payment_list.length, 2);

    // Template downloads and is import-safe (example rows are skipped).
    r = await req(server, 'GET', '/api/jobs/import-template.csv');
    assert.equal(r.status, 200);
    assert.match(r.body, /^Name,Phone Number/);
    const tpl = await req(server, 'POST', '/api/jobs/import', { csv: r.body });
    assert.equal(tpl.body.created, 0);
    assert.equal(tpl.body.skipped, 2);
  } finally {
    server.close();
  }
});

test('sheet endpoints are staff-only and importer rejects garbage', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);
    let r = await req(server, 'POST', '/api/jobs/import', { csv: 'not,a\nreal,sheet' });
    assert.equal(r.status, 400);

    // Contractor role: no sheet access, no Ellian.
    const c = await req(server, 'POST', '/api/contractors',
      { name: 'Sub One', specialty_ids: [1], login_email: 'sub2@x.com' });
    const res = await fetch(`http://localhost:${server.address().port}/api/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'sub2@x.com', password: c.body.login.temp_password }),
    });
    COOKIE = res.headers.get('set-cookie').split(';')[0];
    assert.equal((await req(server, 'GET', '/api/jobs/export.csv')).status, 403);
    assert.equal((await req(server, 'POST', '/api/jobs/import', { csv: 'Name\nX' })).status, 403);
    assert.equal((await req(server, 'POST', '/api/assistant', {})).status, 403);
  } finally {
    server.close();
    COOKIE = '';
  }
});
