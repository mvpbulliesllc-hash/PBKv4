// The auth contract: all seven admin accounts log in with the universal
// password (case-insensitive email), a user can set their own PIN and log in
// with it afterwards, and wrong credentials are 401.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

const ADMINS = [
  'j@ecoaisolutions.com',
  'joe@paragonexteriorsnj.com',
  'contact@paragonhomeimprovementco.com',
  'HQ@paragonhomeimprovementco.com',
  'Elliana@paragonhomeimprovementco.com',
  'HelpDeskClaims@paragonhomeimprovementco.com',
  'paragonexteriors.co@gmail.com',
];

const login = (base, email, password) => fetch(base + '/api/login', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});

test('all 7 admins log in with the universal password; PIN self-serve flow', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    for (const email of ADMINS) {
      const r = await login(base, email, PW);
      assert.equal(r.status, 200, `${email} should log in`);
      const u = await r.json();
      assert.equal(u.role, 'admin', `${email} is admin`);
    }
    assert.equal((await login(base, 'j@ecoaisolutions.com', 'wrong-password')).status, 401);
    assert.equal((await login(base, 'nobody@example.com', PW)).status, 401);

    // Set own PIN, then log in with it.
    const r = await login(base, 'joe@paragonexteriorsnj.com', PW);
    const cookie = r.headers.get('set-cookie').split(';')[0];
    const setPin = await fetch(base + '/api/me/pin', {
      method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ pin: '4721' }),
    });
    assert.equal(setPin.status, 200);
    const pinLogin = await fetch(base + '/api/login-pin', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: '4721' }),
    });
    assert.equal(pinLogin.status, 200);
    const badPin = await fetch(base + '/api/login-pin', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: '0000' }),
    });
    assert.equal(badPin.status, 401);
    // Password still works after a PIN exists.
    assert.equal((await login(base, 'joe@paragonexteriorsnj.com', PW)).status, 200);
  } finally { server.close(); }
});
