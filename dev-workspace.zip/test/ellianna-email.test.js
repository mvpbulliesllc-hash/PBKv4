// Ellianna's mailbox endpoints: staff-only, and a readable 503 (not a crash)
// until the mailbox app password is configured on the server.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

async function login(base) {
  const r = await fetch(base + '/api/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
  });
  assert.equal(r.status, 200);
  return r.headers.get('set-cookie').split(';')[0];
}

test('ellianna email: staff-gated, graceful 503 when unconfigured', async () => {
  delete process.env.ELLIANNA_EMAIL_PASSWORD;
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    // No auth → 401 on everything under /api/ellianna.
    assert.equal((await fetch(base + '/api/ellianna/email/status')).status, 401);
    assert.equal((await fetch(base + '/api/ellianna/email/inbox')).status, 401);

    const cookie = await login(base);
    const get = (p) => fetch(base + p, { headers: { cookie } });

    // Status reports unconfigured with her address.
    const st = await (await get('/api/ellianna/email/status')).json();
    assert.equal(st.configured, false);
    assert.match(st.address, /paragonhomeimprovementco\.com$/i);

    // Mailbox reads/sends are a clear 503, not a crash.
    assert.equal((await get('/api/ellianna/email/inbox')).status, 503);
    assert.equal((await get('/api/ellianna/email/sent')).status, 503);
    const send = await fetch(base + '/api/ellianna/email/send', {
      method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
      body: JSON.stringify({ to: 'x@example.com', body: 'hi' }),
    });
    assert.equal(send.status, 503);
  } finally { server.close(); }
});
