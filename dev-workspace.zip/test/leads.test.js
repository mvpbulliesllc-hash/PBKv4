// Lead pipeline: import upsert, truthful stage history, contact-type gates,
// DNC suppression, scoring. Mirrors the smoke-test harness (in-memory SQLite).
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';
const { scoreLead } = require('../src/lead-score');

let COOKIE = '';
async function login(server) {
  const res = await fetch(`http://localhost:${server.address().port}/api/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
  });
  assert.equal(res.status, 200);
  COOKIE = res.headers.get('set-cookie').split(';')[0];
}
async function req(server, method, url, body) {
  const res = await fetch(`http://localhost:${server.address().port}${url}`, {
    method, headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: res.headers.get('content-type')?.includes('json') ? await res.json() : await res.text() };
}

const ENRICHED_ROW = {
  external_id: 'PAR-00001', source: 'ASSESSOR-KEANSBURG-07734',
  property_address: '86 MORNINGSIDE AVE', city: 'Keansburg', state: 'NJ', zip: '07734',
  owner_first: 'William', owner_last: 'Scobie',
  primary_phone: '7326103256', phone_type: 'Mobile',
  landlines: '7324950538;7323358181', emails: 'a@x.com;b@y.com',
  mail_address: '1 Elsewhere St', mail_city: 'Trenton', mail_state: 'NJ', mail_zip: '08601',
  year_built: '1905', roof_age_min: '121', assessed_value: '291500', bldg_desc: '1SF',
};
const SCRAPED_ROW = {
  source: 'ASSESSOR-MIDDLETOWN-07748',
  property_address: '12 OAK ST', city: 'Middletown', state: 'NJ', zip: '07748',
  year_built: '1980', roof_age_min: '18', assessed_value: '400000',
};

test('lead pipeline: import, stages, gates, dnc', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);

    // Import: one enriched, one scraped-only.
    let r = await req(server, 'POST', '/api/leads/import', { rows: [ENRICHED_ROW, SCRAPED_ROW] });
    assert.equal(r.status, 200);
    assert.deepEqual([r.body.created, r.body.updated], [2, 0]);

    // Re-import is an idempotent upsert, even with a differently punctuated address.
    r = await req(server, 'POST', '/api/leads/import',
      { rows: [{ ...ENRICHED_ROW, property_address: '86 Morningside Avenue' }] });
    assert.deepEqual([r.body.created, r.body.updated], [0, 1]);

    const counts = (await req(server, 'GET', '/api/leads/counts')).body;
    assert.equal(counts.total, 2);
    assert.equal(counts.stages.enriched, 1);   // contact data → promoted
    assert.equal(counts.stages.scraped, 1);    // no contact → stays put

    const list = (await req(server, 'GET', '/api/leads?enriched=Y')).body;
    assert.equal(list.length, 1);
    const lead = (await req(server, 'GET', '/api/leads/' + list[0].id)).body;

    // Truthful history: landed in scraped, then promoted to enriched.
    assert.deepEqual(lead.stage_history.map(h => h.to_stage), ['scraped', 'enriched']);
    // Contacts parsed: 1 mobile (primary) + 2 landlines + 2 emails.
    assert.equal(lead.contacts.length, 5);
    assert.ok(lead.contacts.find(c => c.value === '7326103256' && c.is_primary));
    // Absentee derived from mailing != property; score includes the bonus.
    assert.equal(lead.absentee, 1);
    assert.equal(lead.score, scoreLead({ roof_age_min: 121, assessed_value: 291500, absentee: 1 }));

    // Gate: scraped lead (no contacts) cannot enter emailed or called.
    const scraped = (await req(server, 'GET', '/api/leads?enriched=N')).body[0];
    for (const stage of ['emailed', 'called']) {
      r = await req(server, 'POST', `/api/leads/${scraped.id}/stage`, { stage });
      assert.equal(r.status, 400, stage + ' must be gated');
    }

    // Enriched lead moves forward; history + last_touch stamp.
    r = await req(server, 'POST', `/api/leads/${lead.id}/stage`, { stage: 'called' });
    assert.equal(r.status, 200);
    assert.ok(r.body.last_touch_at);

    // DNC: blocks outbound stage moves and call/email activities.
    await req(server, 'PUT', '/api/leads/' + lead.id, { dnc: 1 });
    r = await req(server, 'POST', `/api/leads/${lead.id}/stage`, { stage: 'emailed' });
    assert.equal(r.status, 400);
    r = await req(server, 'POST', `/api/leads/${lead.id}/activities`, { kind: 'call', detail: 'x' });
    assert.equal(r.status, 400);
    // …but notes and non-outbound moves still work.
    r = await req(server, 'POST', `/api/leads/${lead.id}/activities`, { kind: 'note', detail: 'homeowner asked us to stop' });
    assert.equal(r.status, 201);
    r = await req(server, 'POST', `/api/leads/${lead.id}/stage`, { stage: 'dead' });
    assert.equal(r.status, 200);
    assert.equal(r.body.pipeline_stage, 'dead');
  } finally {
    server.close();
  }
});

test('leads are staff-only; import is admin-only', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);
    // Seed one lead, then create an office user and a contractor user.
    await req(server, 'POST', '/api/leads/import', { rows: [ENRICHED_ROW] });
    const office = (await req(server, 'POST', '/api/users',
      { email: 'o@x.com', name: 'Office', role: 'office' })).body;
    const sub = (await req(server, 'POST', '/api/users',
      { email: 'c@x.com', name: 'Sub', role: 'contractor' })).body;

    const as = async (u, method, url, body) => {
      const login2 = await fetch(`http://localhost:${server.address().port}/api/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: u.email, password: u.temp_password }),
      });
      const cookie = login2.headers.get('set-cookie').split(';')[0];
      const res = await fetch(`http://localhost:${server.address().port}${url}`, {
        method, headers: { 'Content-Type': 'application/json', Cookie: cookie },
        body: body ? JSON.stringify(body) : undefined,
      });
      return res.status;
    };

    assert.equal(await as(office, 'GET', '/api/leads'), 200);
    assert.equal(await as(office, 'POST', '/api/leads/import', { rows: [SCRAPED_ROW] }), 403);
    assert.equal(await as(sub, 'GET', '/api/leads'), 403);
  } finally {
    server.close();
  }
});
