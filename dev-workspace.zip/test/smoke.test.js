// End-to-end smoke test: job lifecycle from lead to paid, with the ABC Supply
// quote (#2010133559) numbers from the design brief as the material document.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

let COOKIE = '';
async function login(server) {
  const res = await fetch(`http://localhost:${server.address().port}/api/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
    body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
  });
  assert.equal(res.status, 200);
  COOKIE = res.headers.get('set-cookie').split(';')[0];
}

async function req(server, method, url, body) {
  const res = await fetch(`http://localhost:${server.address().port}${url}`, {
    method, headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: res.headers.get('content-type')?.includes('json') ? await res.json() : await res.text() };
}

test('job lifecycle: lead → signed → completed → paid, with correct math', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);
    // Lead with only name + phone is a valid row.
    let r = await req(server, 'POST', '/api/jobs', { customer_name: 'Test Customer', phone: '555-1234' });
    assert.equal(r.status, 201);
    const id = r.body.id;
    assert.equal(r.body.status, 'Lead');

    r = await req(server, 'PUT', `/api/jobs/${id}`, {
      proposal_sent: '2026-06-01', signed_contract: '2026-06-05',
      job_total_cents: 1850000, scope_of_work: 'Roof + soffit',
    });
    assert.equal(r.body.status, 'Signed');
    assert.equal(r.body.balance_owed_cents, 1850000);

    // Material document mirrors the ABC quote: subtotal 9127.02 + 75 fuel + 609.63 tax = 9811.65.
    r = await req(server, 'POST', '/api/material-documents', {
      job_id: id, supplier_id: 1, document_number: '2010133559', doc_type: 'Quote',
      fuel_surcharge_cents: 7500, sales_tax_cents: 60963,
      lines: [
        { sku: '02OCTDUON', description: 'OC TruDef Duration Onyx Black', quantity: 90, uom: 'BD', unit_price_cents: 9000, trade_tag: 'Roofing' },
        { sku: 'SOFFIT1', description: 'Soffit panel', quantity: 6, uom: 'PNL', unit_price_cents: 17117, trade_tag: 'Soffit' },
      ],
    });
    assert.equal(r.status, 201);
    assert.equal(r.body.subtotal_cents, 912702);
    assert.equal(r.body.total_cents, 981165);

    // Labor + dumpster as job-linked expenses.
    const cats = (await req(server, 'GET', '/api/expense-categories')).body;
    const laborCat = cats.find(c => c.name === 'Contractor Payment').id;
    const dumpCat = cats.find(c => c.name === 'Dumpster').id;
    const equityCat = cats.find(c => c.name === "Owner's Draw");
    assert.equal(equityCat.qb_type, 'equity');

    await fetch(`http://localhost:${server.address().port}/api/expenses`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
      body: JSON.stringify({ amount_cents: 400000, category_id: laborCat, job_id: id, vendor: 'Sub LLC' }),
    });
    await fetch(`http://localhost:${server.address().port}/api/expenses`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
      body: JSON.stringify({ amount_cents: 55000, category_id: dumpCat, job_id: id }),
    });
    // Equity entry linked to nothing — must never hit job cost or P&L.
    await fetch(`http://localhost:${server.address().port}/api/expenses`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
      body: JSON.stringify({ amount_cents: 100000, category_id: equityCat.id }),
    });

    // Payments: deposit + final → balance owed 0 → status Paid once completed.
    await req(server, 'POST', `/api/jobs/${id}/payments`, { label: 'Deposit', amount_cents: 925000, date: '2026-06-05' });
    await req(server, 'PUT', `/api/jobs/${id}`, { schedule_date: '2026-06-20', completed_date: '2026-06-25' });
    r = await req(server, 'GET', `/api/jobs/${id}`);
    assert.equal(r.body.status, 'Completed');
    await req(server, 'POST', `/api/jobs/${id}/payments`, { label: 'Final Payment', amount_cents: 925000, date: '2026-06-26' });

    r = await req(server, 'GET', `/api/jobs/${id}`);
    assert.equal(r.body.status, 'Paid');
    assert.equal(r.body.balance_owed_cents, 0);
    assert.equal(r.body.material_cost_cents, 981165);
    assert.equal(r.body.labor_cost_cents, 400000);
    assert.equal(r.body.dumpster_cost_cents, 55000);
    // Net profit = 18500.00 − 9811.65 − 4000 − 550 = 4138.35
    assert.equal(r.body.net_profit_cents, 413835);

    // P&L view picks up the completed job with totals.
    r = await req(server, 'GET', '/api/pnl?from=2026-06-01&to=2026-06-30');
    assert.equal(r.body.rows.length, 1);
    assert.equal(r.body.totals.net_profit_cents, 413835);

    // QB export flags equity rows.
    r = await req(server, 'GET', '/api/expenses/export.csv');
    assert.match(r.body, /Owner's Draw.*Equity/);
    assert.match(r.body, /Contractor Payment.*Expense/);
  } finally {
    server.close();
  }
});

test('reference lists are extensible (add-a-row is the contract)', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    await login(server);
    let r = await req(server, 'POST', '/api/scope-types', { name: 'Gutters', unit: 'LF' });
    assert.equal(r.status, 201);
    r = await req(server, 'POST', '/api/expense-categories', { name: 'TikTok', parent_id: null, qb_type: 'expense' });
    assert.equal(r.status, 201);

    // Contractor with lapsed insurance gets flagged.
    r = await req(server, 'POST', '/api/contractors',
      { name: 'Lapsed LLC', insurance_expiry: '2025-01-01', specialty_ids: [1] });
    assert.equal(r.body.insurance_lapsed, true);

    // Dumpster vendor with an extensible size list.
    r = await req(server, 'POST', '/api/dumpster-vendors', { name: 'Shore Disposal' });
    r = await req(server, 'POST', '/api/dumpster-prices',
      { vendor_id: r.body.id, size_label: '40 Yard', cost_cents: 75000 });
    assert.equal(r.status, 201);

    // ABC Supply Toms River is seeded as supplier row one.
    r = await req(server, 'GET', '/api/suppliers');
    assert.equal(r.body[0].account_number, '2173114');
  } finally {
    server.close();
  }
});

test('roles are enforced server-side', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    // No cookie → 401.
    COOKIE = '';
    let r = await req(server, 'GET', '/api/jobs');
    assert.equal(r.status, 401);
    await login(server);

    // Two jobs, one assigned to contractor 1.
    const c = await req(server, 'POST', '/api/contractors',
      { name: 'Sub One', specialty_ids: [1], login_email: 'sub@x.com' });
    assert.ok(c.body.login.temp_password);
    const j1 = await req(server, 'POST', '/api/jobs', { customer_name: 'A', contractor_id: c.body.id });
    await req(server, 'POST', '/api/jobs', { customer_name: 'B' });

    // Office user: CRM yes, P&L/users no.
    const office = await req(server, 'POST', '/api/users', { email: 'o@x.com', name: 'O', role: 'office' });
    const adminCookie = COOKIE;
    const loginAs = async (email, pw) => {
      const res = await fetch(`http://localhost:${server.address().port}/api/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pw }) });
      COOKIE = res.headers.get('set-cookie').split(';')[0];
    };
    await loginAs('o@x.com', office.body.temp_password);
    assert.equal((await req(server, 'GET', '/api/jobs')).status, 200);
    assert.equal((await req(server, 'GET', '/api/pnl')).status, 403);
    assert.equal((await req(server, 'GET', '/api/users')).status, 403);
    assert.equal((await req(server, 'GET', '/api/expenses')).status, 403);

    // Contractor: only their job, read-only, no money fields.
    await loginAs('sub@x.com', c.body.login.temp_password);
    r = await req(server, 'GET', '/api/jobs');
    assert.equal(r.body.length, 1);
    assert.equal(r.body[0].customer_name, 'A');
    assert.equal(r.body[0].job_total_cents, undefined);
    assert.equal((await req(server, 'POST', '/api/jobs', { customer_name: 'X' })).status, 403);
    assert.equal((await req(server, 'GET', '/api/contractors')).status, 403);

    // Client: scoped to one job with balance visible.
    COOKIE = adminCookie;
    const cl = await req(server, 'POST', '/api/users',
      { email: 'home@x.com', name: 'H', role: 'client', job_id: j1.body.id });
    await loginAs('home@x.com', cl.body.temp_password);
    r = await req(server, 'GET', '/api/jobs');
    assert.equal(r.body.length, 1);
    assert.ok('balance_owed_cents' in r.body[0]);
  } finally {
    server.close();
  }
});

test('contractor self-onboarding: invite → wizard → approve → 1099', async () => {
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = () => `http://localhost:${server.address().port}`;
  try {
    await login(server);
    // Invite → public link token.
    let r = await req(server, 'POST', '/api/onboarding/invite', { name: 'Shore Roofing', email: 'sub@shore.com' });
    assert.equal(r.status, 201);
    const t = r.body.token;

    // The public wizard needs NO auth; other endpoints stay walled off.
    const pub = (m, u, b) => fetch(base() + u, { method: m,
      headers: { 'Content-Type': 'application/json' }, body: b && JSON.stringify(b) })
      .then(async res => ({ status: res.status, body: await res.json() }));
    assert.equal((await pub('GET', `/api/onboard/${t}`)).status, 200);
    assert.equal((await fetch(base() + '/api/jobs')).status, 401);
    assert.equal((await pub('GET', '/api/onboard/wrong-token')).status, 404);

    // Steps: identity+TIN, bank, credentials data, signatures (w9 + all six).
    r = await pub('PUT', `/api/onboard/${t}`, {
      legal_name: 'Shore Roofing LLC', entity_type: 'LLC', tin: '12-3456789', tin_type: 'EIN',
      address: '9 Bay Ave', city: 'Keansburg', state: 'NJ', zip: '07734',
      email: 'sub@shore.com', hic_number: '13VH12345678', gl_expiry: '2027-01-01', wc_exempt: 1,
      specialties: [1], crew_size: '4', service_zips: '07734,07748',
      bank: { bank_name: 'Chase', routing: '021000021', account: '123456789', account_type: 'Checking' },
    });
    // Secrets come back masked only.
    assert.equal(r.body.data.tin_masked, '****6789');
    assert.equal(r.body.data.bank_masked.account, '****6789');
    assert.ok(!JSON.stringify(r.body).includes('123456789'));

    for (const a of ['w9', 'ica', 'insurance', 'hicpa', 'esign', 'ach', 'privacy']) {
      await pub('PUT', `/api/onboard/${t}`, { sign: { agreement: a, typed_name: 'Sal Shore' } });
    }
    // Docs (drivers license + GL cert required).
    for (const kind of ['drivers_license', 'gl_cert']) {
      const fd = new FormData();
      fd.append('file', new Blob(['x']), 'doc.pdf');
      await fetch(`${base()}/api/onboard/${t}/doc/${kind}`, { method: 'POST', body: fd });
    }
    r = await pub('POST', `/api/onboard/${t}/submit`);
    assert.equal(r.body.status, 'submitted');
    // Wizard is closed after submit.
    assert.equal((await pub('PUT', `/api/onboard/${t}`, { legal_name: 'x' })).status, 400);

    // Approve → contractor + login + 1099-ready.
    const q = await req(server, 'GET', '/api/onboarding');
    const inv = q.body.find(i => i.status === 'submitted');
    r = await req(server, 'POST', `/api/onboarding/${inv.id}/approve`, {});
    assert.equal(r.body['1099_ready'], true);
    assert.ok(r.body.login.temp_password);
    const cid = r.body.contractor_id;

    // Pay them $700 → shows on 1099 with decrypted TIN in CSV.
    const cats = (await req(server, 'GET', '/api/expense-categories')).body;
    const cp = cats.find(c => c.name === 'Contractor Payment').id;
    await fetch(base() + '/api/expenses', { method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: COOKIE },
      body: JSON.stringify({ amount_cents: 70000, category_id: cp, contractor_id: cid }) });
    r = await req(server, 'GET', '/api/1099?year=' + new Date().getFullYear());
    assert.equal(r.body.length, 1);
    assert.equal(r.body[0].tin_masked, '****6789');
    r = await req(server, 'GET', `/api/1099?year=${new Date().getFullYear()}&format=csv`);
    assert.match(r.body, /123456789/);   // full TIN only in the admin CSV
    assert.match(r.body, /700.00/);
  } finally {
    server.close();
  }
});
