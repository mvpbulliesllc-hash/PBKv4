// Mux video endpoints: staff-only, readable 503 until the Mux keys are set.
const { test } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

test('video: staff-gated, graceful 503 when unconfigured', async () => {
  delete process.env.MUX_TOKEN_ID;
  delete process.env.MUX_TOKEN_SECRET;
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    assert.equal((await fetch(base + '/api/video/assets')).status, 401);

    const r = await fetch(base + '/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
    });
    const cookie = r.headers.get('set-cookie').split(';')[0];
    const get = (p) => fetch(base + p, { headers: { cookie } });

    const st = await (await get('/api/video/status')).json();
    assert.equal(st.configured, false);
    assert.equal((await get('/api/video/assets')).status, 503);
    assert.equal((await fetch(base + '/api/video/uploads', {
      method: 'POST', headers: { 'Content-Type': 'application/json', cookie }, body: '{}',
    })).status, 503);
  } finally { server.close(); }
});
