// Hume EVI webhook (/api/callbacks/hume): HMAC-verified, stale-timestamp
// rejected, events land in the staff-only call log.
const { test } = require('node:test');
const assert = require('node:assert');
const crypto = require('crypto');
const { createApp } = require('../src/server');
const PW = process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-pw';

const KEY = 'test-signing-key';

function signed(base, body, { ts = Math.floor(Date.now() / 1000), key = KEY } = {}) {
  const payload = JSON.stringify(body);
  const sig = crypto.createHmac('sha256', key).update(`${payload}.${ts}`).digest('hex');
  return fetch(base + '/api/callbacks/hume', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json',
      'X-Hume-AI-Webhook-Signature': sig, 'X-Hume-AI-Webhook-Timestamp': String(ts) },
    body: payload,
  });
}

test('hume callback: verified events stored; bad/stale signatures rejected', async () => {
  process.env.HUME_WEBHOOK_SIGNING_KEY = KEY;
  const app = createApp(':memory:');
  const server = app.listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    // Valid chat_ended event.
    let r = await signed(base, { event_name: 'chat_ended', chat_id: 'c1', chat_group_id: 'g1',
      caller_number: '+17325550100', duration_seconds: 95, end_reason: 'user_ended' });
    assert.equal(r.status, 200);

    // Wrong key → 401. Stale timestamp → 401. No signature → 401.
    assert.equal((await signed(base, { event_name: 'chat_started' }, { key: 'wrong' })).status, 401);
    assert.equal((await signed(base, { event_name: 'chat_started' },
      { ts: Math.floor(Date.now() / 1000) - 3600 })).status, 401);
    assert.equal((await fetch(base + '/api/callbacks/hume', { method: 'POST',
      headers: { 'Content-Type': 'application/json' }, body: '{}' })).status, 401);

    // The verified event shows in the staff call log; log needs staff auth.
    assert.equal((await fetch(base + '/api/calls')).status, 401);
    const login = await fetch(base + '/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'j@ecoaisolutions.com', password: PW }),
    });
    const cookie = login.headers.get('set-cookie').split(';')[0];
    const calls = await (await fetch(base + '/api/calls', { headers: { Cookie: cookie } })).json();
    assert.equal(calls.length, 1);
    assert.equal(calls[0].caller_number, '+17325550100');
    assert.equal(calls[0].duration_seconds, 95);
  } finally {
    server.close();
    delete process.env.HUME_WEBHOOK_SIGNING_KEY;
  }
});

test('hume callback: clear 503 when the signing key is not configured', async () => {
  delete process.env.HUME_WEBHOOK_SIGNING_KEY;
  const app = createApp(':memory:');
  const server = app.listen(0);
  try {
    const r = await signed(`http://localhost:${server.address().port}`, { event_name: 'chat_started' });
    assert.equal(r.status, 503);
  } finally { server.close(); }
});
