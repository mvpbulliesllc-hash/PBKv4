# paragon-pnl

Query Paragon's P&L Job Tracker and books over its REST API. Use this
whenever Jarad or Joe asks about jobs, revenue, profit, customers, or
spending. Never guess numbers — if the API errors or returns nothing, say so
(fail closed) and escalate.

Requires env (in `~/.hermes/.env`): `PARAGON_PNL_URL`, `PARAGON_PNL_TOKEN`.

## Commands (run `./pnl.sh <cmd>`)

| Command | Returns |
|---|---|
| `./pnl.sh summary` | jobs / revenue / profit for this month + last 6 months |
| `./pnl.sh jobs` | every tracker job with computed net profit and percentages |
| `./pnl.sh jobs "<search>"` | tracker jobs filtered by customer/notes text |
| `./pnl.sh crm` | CRM pipeline jobs (status, balance owed) |
| `./pnl.sh expenses <YYYY-MM>` | that month's expense entries |

All money values are integer **cents** unless the field name says otherwise —
divide by 100 and report dollars.

## Debrief guidance

For the morning debrief pull `summary` + yesterday's changes from `jobs`;
flag anomalies plainly: negative-profit jobs, jobs signed >30 days with no
schedule, balance owed on completed jobs.
