#!/usr/bin/env bash
# Paragon P&L tracker API helper. Auth via service bearer token (Dev Tools →
# mint one). Fails closed: any error prints NOTHING but the error and exits 1.
set -euo pipefail
: "${PARAGON_PNL_URL:?set PARAGON_PNL_URL in ~/.hermes/.env}"
: "${PARAGON_PNL_TOKEN:?set PARAGON_PNL_TOKEN in ~/.hermes/.env}"

get() { curl -fsS -H "Authorization: Bearer $PARAGON_PNL_TOKEN" "$PARAGON_PNL_URL$1"; }

case "${1:-help}" in
  summary)  get /api/tracker/summary ;;
  jobs)     if [ -n "${2:-}" ]; then get /api/tracker/jobs | \
              node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const q=process.argv[1].toLowerCase();console.log(JSON.stringify(JSON.parse(d).filter(j=>(j.customer_name+" "+j.notes).toLowerCase().includes(q))))})' "$2"
            else get /api/tracker/jobs; fi ;;
  crm)      get /api/jobs ;;
  expenses) get "/api/expenses?month=${2:?usage: pnl.sh expenses YYYY-MM}" ;;
  *) echo "usage: pnl.sh summary | jobs [search] | crm | expenses YYYY-MM" >&2; exit 1 ;;
esac
