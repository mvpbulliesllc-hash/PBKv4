# Ellianna — Hermes Deployment Package

Ellianna runs in two places:

1. **In-app** (already live): the chat bubble / "Ellianna ✨" tab in this web
   app, served by `src/assistant.js` (`claude-fable-5`, low effort, Opus
   fallback). Nothing to install — just set `ANTHROPIC_API_KEY`.
2. **Full harness** (this folder): a Hermes instance
   (https://github.com/mvpbulliesllc-hash/hermes-agent) with email, cron
   debriefs, telephony, and Ruflo memory. Hermes runs on an always-on box —
   it cannot live inside Vercel serverless. Jarad installs it on a VPS or a
   home server following the checklist below.

## Install checklist (Jarad, ~30 min)

1. **Clone + configure Hermes**
   ```sh
   git clone https://github.com/mvpbulliesllc-hash/hermes-agent.git && cd hermes-agent
   cp cli-config.yaml.example cli-config.yaml
   ```
   Merge `cli-config.additions.yaml` (this folder) into `cli-config.yaml`:
   - `model.default: "anthropic/claude-fable-5"`, `model.provider: "anthropic"`
   - `reasoning_effort: "low"` (agent config section, ~line 647 of the
     example). If the direct Anthropic path ignores the knob, switch the
     provider block to OpenRouter with the same model + effort.
   - the `personalities.ellianna` block, set as default persona.
2. **Secrets** — create `${HERMES_HOME:-~/.hermes}/.env` with
   `ANTHROPIC_API_KEY=...`. Never commit it, never paste it into chat/logs.
3. **Pair the only two users** — Hermes gateway (`gateway/pairing.py`,
   `authz_mixin.py`, allowlists in `gateway/config.py`): pair **Jarad** and
   **Joe**, nobody else. Hermes memory (`agent/curator.py` + Honcho user
   modeling) keeps a separate model of each across sessions automatically.
4. **P&L skill** — copy `skills/paragon-pnl/` (this folder) to
   `~/.hermes/skills/paragon-pnl/`. Mint a service token: log into the web
   app as admin → Dev Tools → "mint one" (`GET /api/token`), put it in
   `~/.hermes/.env` as `PARAGON_PNL_TOKEN`, and set `PARAGON_PNL_URL` to the
   deployed app origin.
5. **Email** — configure the bundled `skills/email/` (himalaya) against a
   Paragon-owned mailbox (IMAP/SMTP creds in `~/.hermes/.env`). Covers send,
   receive, search, forward.
6. **Telephony** — install `optional-skills/productivity/telephony/` into
   `~/.hermes/skills/` (Twilio SMS/MMS + outbound calls via Vapi/Bland).
   **Do NOT build a second inbound phone agent** — inbound live answering
   stays on the existing Hume EVI receptionist with the locked opening line.
   Ellianna does outbound calls, SMS, and call follow-up only.
7. **Cron debriefs** — register the three jobs in `cron-jobs.md` with Hermes
   cron (`cron/` package; contract in `docs/chronos-managed-cron-contract.md`).
8. **Ruflo memory layer** — register the Ruflo MCP server
   (https://github.com/mvpbulliesllc-hash/ruflo) as an optional MCP,
   following the `optional-mcps/linear/` shape in the Hermes repo. Expose
   **only** `memory_store` / AgentDB persistence and agent-spawn. Do NOT wire
   Ruflo's full 314-tool surface into her — Hermes stays the narrow waist,
   capability lives in skills.
9. **Wire the web app's chat to the harness (optional, later)** — the in-app
   bubble already passes the signed-in user on every request via the auth
   cookie. To route it through Hermes instead of `src/assistant.js`, point
   the gateway at `/api/assistant` semantics and forward `req.user`.

## Env vars (all set manually — never via the Vercel API)

Vercel dashboard (web app):

| Var | What |
|---|---|
| `DATABASE_URL` | Neon Postgres (already set) |
| `AUTH_SECRET` | cookie/token HMAC secret (already set) |
| `ANTHROPIC_API_KEY` | turns on in-app Ellianna |
| `ENC_KEY` | at-rest encryption for TIN/bank data (already set) |

Hermes box (`~/.hermes/.env`):

| Var | What |
|---|---|
| `ANTHROPIC_API_KEY` | Fable 5 access |
| `PARAGON_PNL_URL` | e.g. `https://ctimbuild-v1.vercel.app` |
| `PARAGON_PNL_TOKEN` | admin bearer token minted in Dev Tools |
| email + Twilio creds | per the email / telephony skill docs |

## Hard rules (baked into the persona, enforce in review too)

- If anyone asks whether she is an AI: answer straight, never dodge.
- Never fabricate a price, warranty term, insurance outcome, or timeline —
  unknown = say so and escalate to Jarad or Joe.
- No secrets/keys/credentials read into any conversation, code, or log.
- Client-scoped: Paragon data only. No cross-pollination with other ventures.
