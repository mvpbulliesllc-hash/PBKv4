# Ellianna cron debriefs (Hermes cron — see docs/chronos-managed-cron-contract.md)

Register these three with the Hermes `cron/` package. She may also set
ad-hoc reminders for herself from conversation — that's built into Hermes;
nothing extra to configure.

## 1. Morning debrief → Joe

- Schedule: `0 7 * * 1-6` (7:00 AM, Mon–Sat, America/New_York)
- Prompt: "Morning debrief for Joe. Use the paragon-pnl skill: yesterday's
  new or changed jobs, this month's money summary in plain dollars, and
  today's reminders. Flag anything odd (job losing money, finished job still
  owed money) in one plain sentence each. Keep the whole thing under 10
  sentences. Deliver on Joe's paired channel."

## 2. End-of-day summary → Jarad

- Schedule: `0 19 * * *` (7:00 PM daily)
- Prompt: "EOD summary for Jarad, operator style: tracker deltas today
  (created/updated jobs, by whom), any API errors the paragon-pnl skill hit,
  emails/SMS sent today, anything queued for tomorrow. Terse bullets."

## 3. Monday money check → Joe

- Schedule: `0 8 * * 1` (8:00 AM Monday)
- Prompt: "Weekly money check for Joe: last week's jobs signed, revenue, and
  money made, vs the week before. Two or three plain sentences, dollars only."

Acceptance: the morning debrief must land on schedule two days in a row
before this item is called done.
