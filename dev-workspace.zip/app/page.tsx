import { Cockpit } from "@/components/cockpit/cockpit";

export default function Page() {
  return <Cockpit />;
}
