# Paragon CRM + Job P&L — Design Brief

Client: Joe Ballaccomo, Paragon Exteriors LLC (NJ HIC #13VH13814500)
Prepared: 2026-07-11
Sources: Joe's CRM Header Outline.xlsx, ABC Supply quote #2010133559 (Roof Material Breakout.pdf), Joe's notes email.
Status: Draft for Joe's sign-off. Open questions at bottom.

---

## 1. What this is

One system that tracks a job from first call to final dollar. Joe sketched two spreadsheets (a pipeline tracker and a P&L tracker) plus reference lists for contractors, dumpsters, suppliers, and expenses. Those are not four tools. They are one database with views. The core design rule: a job gets entered once, and pipeline, costing, and P&L all read from that same record.

Second design rule, straight from Joe's note: every list must let him keep adding rows and categories without calling a developer.

Third design rule: humans enter inputs, the system does math. Joe should never hand-calculate Balance Owed or Net Profit.

## 2. Core object: the Job

Joe's two header rows overlap heavily. Merged into one Job record:

**Identity and contact**
Customer Name, Phone, Email, Job Address, Notes.

**Pipeline (from CRM Outline)**
Scope of Work, Proposal Sent (date), Signed Contract (date), Sub Assigned (link to Contractor), Schedule Date, Completed Date.
Status is derived from these dates: Lead → Proposal Sent → Signed → Scheduled → In Progress → Completed → Paid.

**Scope quantities (from P&L Outline)**
Roof SQ, Siding LF, Deck SF, Windows Qty, Bathroom, Interior Repair. Stored as separate quantity fields so unit costing works later. This list must be extensible (Joe will add trade types).

**Money in**
Job Total (contract price), Deposit, Additional Payment, Final Payment.
Computed: Balance Owed = Job Total − (Deposit + Additional + Final).
Note: Joe's sheet has both "Job Cost" (CRM tab) and "Job Total" (P&L tab). Treat as one field, the contract price. Confirm with Joe.

**Money out (per job)**
Material Cost (rolls up from Material line items, section 3), Labor Cost (contractor payments), Dumpster Cost, plus any other direct job expense.
Computed: Net Profit = Job Total − (Material + Labor + Dumpster + other direct costs). Margin % alongside.

## 3. Material line items (modeled on the ABC Supply quote)

The ABC quote is the template for how material cost actually arrives: a quote/invoice header plus line items. Build it that way so Joe can enter or upload a supplier quote and the job's Material Cost updates itself.

**Material Document** (one per quote/invoice): Supplier (link), Document # (e.g. 2010133559), Type (Quote / Invoice), Job (link), Ship-to address, Dates (activation, close, delivery), Subtotal, Fuel Surcharge, Sales Tax, Total.

**Line item** (many per document): SKU (e.g. 02OCTDUON), Description (e.g. OC TruDef Duration Onyx Black), Quantity, UOM (BD/RL/BX/PC/PNL/SQ), Price per UOM, Amount.

Real example from the source doc: 30 SQ roof + soffit job, 17 line items, $9,127.02 subtotal, $75 fuel surcharge, $609.63 tax, $9,811.65 total. That one document also proves a single delivery can span trades (roofing and soffit), so line items should carry an optional trade tag if Joe wants cost split by trade later. V2, not launch.

Stretch goal: PDF upload → auto-extract line items. Manual entry ships first.

## 4. Reference tables (all user-extensible)

**Contractors**
Company/Name, Specialized In (multi-select: Roofing, Siding, Soffit, Windows, Decks, Interior, Bathroom...), HIC Insurance (doc upload + expiry date), W9 (doc upload), License (number + doc + expiry), Contact info, Payment history (from Expenses).
Expiry dates get a flag when a doc lapses. A sub with expired insurance on an active job is a liability Joe should see without looking for it.

**Dumpster Vendors**
Company Name, Contact Info, Cost 10 Yard, Cost 20 Yard, Cost 30 Yard. Extensible for other sizes.

**Suppliers**
Company Name, Branch/Address, Account #, Rep, Phone, Materials carried, Costs. ABC Supply Toms River (acct 2173114) is row one. Material price list per supplier grows over time from entered documents.

## 5. Expense tracking (feeds QuickBooks)

Categories from Joe, each a QB-mappable bucket:

Gas · Trucks · Equipment/Tools · Insurance · Contractor Payment · Supplier Payment · Promotional Payment · Marketing Expenses (subcategories per advertising channel: Google, Meta, direct mail, etc.) · Marketing Collateral incl. apparel · Travel · Food · Cell Phone · Petty Cash · CC Fees · Office Expenses · EZ Pass · Partner Capital Investment · Owner's Draw.

Category list is user-editable (add, rename, add subcategories).

Expense record: Date, Amount, Category, Vendor, Job (optional link — this is what separates direct job cost from overhead), Payment method, Receipt upload, Notes.

**Accounting flag for Joe's bookkeeper:** Owner's Draw and Partner Capital Investment are equity transactions, not expenses. They live in the same entry screen because that's how Joe thinks, but they map to equity accounts in QB, not the P&L. CC Fees and EZ Pass map to standard expense accounts.

**QuickBooks integration:** phase 2. Phase 1 is category parity so a clean export/import works. Direct QB sync only after the category structure survives a month of real use.

## 6. Views (what Joe actually sees)

1. **Pipeline board** — jobs by status, the CRM Outline columns.
2. **Job detail** — one page per job: contact, scope, payments, material docs, costs, computed profit.
3. **P&L table** — Joe's P&L Outline columns, filterable by date range, one row per completed job, totals at bottom.
4. **Expenses** — entry form plus monthly view by category.
5. **Reference lists** — contractors, dumpsters, suppliers, each with add-row.

## 7. Build notes

- MVP first. Single-tenant, live proof with Joe's real jobs before any generalizing.
- Every "list of things" (scope types, expense categories, dumpster sizes, contractor specialties) is data, not schema. Add-a-row is the contract.
- Money fields are currency-typed everywhere. No math on floats in views.
- Fits the existing Paragon thesis: the CRM closes the follow-up leak the same way Ellianna closes the missed-call leak. Lead capture from the site and the AI receptionist should eventually create Lead records here automatically. Design the Job record so a lead with only Name + Phone is a valid row.

## 8. Open questions for Joe (call list)

1. "Job Cost" on your CRM tab and "Job Total" on the P&L tab: same number (contract price) or two different numbers?
2. Payments: is Deposit / Additional / Final always the structure, or do some jobs have more than three payments?
3. Do you want material costs split by trade within one job (the ABC quote mixes roofing and soffit), or is one material total per job fine?
4. Marketing channels to break out on day one: which ones are you actually spending on now?
5. Who else touches this besides you? Determines logins and permissions.
6. QuickBooks: which version (Online or Desktop), and does your bookkeeper want export files or direct sync?
