# HANDOFF — Paragon Control Center + Site Scrape + Front End

Written 2026-07-12 at the end of the build session that created the Control
Center. Read this before touching anything.

## The three repos and what they are

| Repo | What it is | Deploys to |
|---|---|---|
| `mvpbulliesllc-hash/ctimbuild-v1` | **Paragon Control Center** — CRM/back office (this repo) | Vercel ONLY: https://ctimbuild-v1.vercel.app (branch `main`, serverless + Neon Postgres). Render is dead — delete the old paragon-crm service. |
| `mvpbulliesllc-hash/sitescrape` | Scrape/enrich/monitor tool, embedded as the "Site Scrape" tab | Vercel: https://sitescrape.vercel.app (app code on branch `claude/sitescrape-0iz0q3`; its `main` only has zips) |
| front-end repo (paragonexteriorsnj.com) | Public marketing site (Astro). Not part of this session's work | Vercel, production www.paragonexteriorsnj.com |

**Plan of record:** the public site gets an "Admin Panel" button linking to the
Control Center (ctimbuild-v1.vercel.app). One login at that door; no login
walls inside (Site Scrape opens via SSO, see below).

## Architecture of the Control Center (ctimbuild-v1)

- Plain Express + **Neon Postgres** + no-build vanilla JS. **No React, no
  bundler** — `public/` is served by Vercel's CDN; the whole Express app runs
  as ONE Vercel serverless function (`api/index.js`); `src/db.js` is
  schema+seed (pg Pool via DATABASE_URL/POSTGRES_URL in prod, embedded PGlite
  for local dev/tests); `src/storms.js` refreshes on request when stale
  (serverless has no background loops).
- Same-origin API (`API_BASE=''` in `public/app.js`); auth cookie is
  `SameSite=None; Secure`.
- **All money is integer cents.** Status/balance/profit are computed
  server-side, never entered. Every reference list is data rows, not schema.
- Tests: `npm test` (node:test, in-memory SQLite, covers job lifecycle math,
  role enforcement, and the full onboarding flow). Keep them green.

### Deploys

One branch: merge to `main`, Vercel deploys. Data lives in Neon Postgres —
**it survives deploys; no re-import cycle.** The LIVE database is the Neon
endpoint `ep-bold-tree` (it holds the 1,451 Keansburg leads and all admin
accounts; it was only suspended, never dead — `/api/health` reports the
connected host as proof). `ep-rapid-mountain` exists but is EMPTY — do not
switch `DATABASE_URL` to it unless you migrate the data first. Lead CSVs stay
out of git (homeowner PII). Uploads persist via Vercel Blob once
`BLOB_READ_WRITE_TOKEN` is set (falls back to ephemeral /tmp without it).
Render is decommissioned; delete the old paragon-crm service and its
env secrets in the Render dashboard.

## Auth & roles

- Login: `j@ecoaisolutions.com` (admin) with the universal admin password (set via `ADMIN_PASSWORD` in Vercel env — not written down here), same for
  `joe@paragonexteriorsnj.com`. Seeded defaults in `src/db.js` — **make J
  change them** via Team tab.
- Roles enforced server-side in `src/server.js`: `admin` (everything),
  `office` (no P&L/Expenses/Dev Tools/Team), `contractor` (read-only, only
  their assigned jobs, no money), `client` (only their job + balance).
- Cookie or `Authorization: Bearer` (mint at `/api/token`, admin).
  `/api/sso-token` mints 5-minute tokens for embedded-tool SSO.
- Secrets in Vercel env (Project → Settings → Environment Variables): `DATABASE_URL` (Neon; J pasted it in chat — rotate in Neon once stable), `AUTH_SECRET`, `ENC_KEY` (AES-256-GCM for TIN/bank
  data — **never rotate ENC_KEY casually**: existing ciphertexts become
  unreadable), `ADMIN_PASSWORD` (optional seed override), plus ~14 integration
  keys (Anthropic, OpenAI, Firecrawl, Exa, Parallel, Hume×4, Daily, cal.com,
  Cloudflare×2, Composio). Dev Tools tab shows configured/not (names only).

## What's built (tabs)

Command Center (KPIs+charts) · Leads (1,000 Keansburg 07734 properties with
year built/roof age/assessed value, search, mark-contacted) · Storm Watch
(NWS alerts every 15 min for South/Central NJ roof-damage events, matched to
leads by zip, `storm.alert` webhook) · CRM (searchable job list) · Pipeline
(8-stage board: Lead→Contacted→Inspection→Proposal→Signed→In Progress→
Completed→Paid, derived from dates) · P&L (per completed job + totals) ·
Expenses (QB CSV export, equity-flagged categories, 1099-NEC report ≥$600) ·
Reference (contractors/dumpsters/suppliers, lapse flags) · Onboarding
(tokenized public wizard at `/onboard/<uuid>`: W-9 e-sign, doc uploads,
encrypted direct deposit, 6 NJ agreements; admin approve→creates contractor +
portal login) · Site Scrape (iframe embed) · Dev Tools (API keys, webhooks,
REST reference, integration status) · Team (user invites/roles/deactivate).

## CRM sheet import/export + Ellian (added 2026-07-14)

**Sheet import/export** — the office's "CRM Outline" spreadsheet layout is
now first-class. Columns (exact order): Name, Phone Number, Email, Address,
Scope of Work, Proposal Sent (Date), Signed Contract, Sub Assigned, Job Cost,
Schedule Date, Completed Date, Deposit, Additional Payment, Final Payment,
Balance Owed, Notes — then the CRM-only extras (City, State, Zip, Contacted
Date, Inspection Date, Status) AFTER Notes.

- `GET /api/jobs/export.csv` (staff) — every job in that layout. Deposit /
  Additional / Final are the summed payment rows by label; Balance Owed and
  Status are computed and ignored on import.
- `GET /api/jobs/import-template.csv` — blank template with two EXAMPLE rows
  (rows whose Name starts with "EXAMPLE" are skipped on import).
- `POST /api/jobs/import` `{csv}` or `{rows}`, plus `{dry_run:true}` for a
  no-write preview. Forgiving parsing ($1,234.56, 6/1/2026, quoted fields,
  loose headers). Upserts by name+address (then name+phone); "Sub Assigned"
  creates missing contractors; a filled payment cell REPLACES that payment
  label on the job, blank cells never delete. Re-importing an export is
  idempotent (covered by `test/import-export.test.js`).
- Front end: CRM tab toolbar (Export / Import wizard / Template / Tutorial).
  The 3-step import wizard previews before saving; a first-visit pop-up
  tutorial lives behind localStorage `paragonTutorialSeen`.
- Code: `src/crm-sheet.js` + `src/csv-utils.js`.

**Ellian** — back-office AI secretary tab (`✨`), staff-only.
`POST /api/assistant` (multipart: `messages` JSON + optional `file`) in
`src/assistant.js`. Uses `@anthropic-ai/sdk` (model `claude-opus-4-8`) with a
tool loop: expense_report (date-range/category/vendor/free-text + grouping),
list_jobs, get_job, add_expense (uploaded photo auto-attaches as the
receipt), export_csv (returns downloadable CSVs in the chat). She knows who's
talking from the login email (Jarad vs Joe). **Requires `ANTHROPIC_API_KEY`
in Vercel env** — without it she answers with setup instructions instead of
erroring. Uploaded receipts share the same /tmp persistence gap as other
uploads (see Deploys above).

## P&L Job Tracker + Ellianna (follow-up build spec, 2026-07-14)

**Job Tracker** — first tab, replaces Joe's spreadsheet 1:1 (`pnl_jobs`
table, `src/tracker.js`, `public/tracker.js`). Schema mirrors his sheet
exactly, including the "Interior Repir" export header (UI spells it right).
Net Profit / Cost % / Profit % are computed, never entered.

- UI: 3 primary actions (Add a Job / See My Jobs / Money Summary), 18px+
  fonts, add-a-job is a one-question-per-screen wizard with live profit math,
  money summary is 3 stats + a 6-month bar chart.
- Import: "Upload My Spreadsheet" accepts .xlsx/.csv as-is ($, commas, any
  US date, blank rows, trailing header spaces); preview → one green confirm.
  Upserts by customer+date_signed; our own TOTALS row is skipped on
  re-import. **Reconcile the header map against Joe's actual file when he
  uploads it — his sheet is the source of truth.**
- Export: `GET /api/tracker/export.xlsx` — exact column order + totals row.
- Coach bubbles (`runCoach` in tracker.js): contextual tips per screen, keep
  showing until "Got it, stop showing me this" (per-user localStorage),
  "❓ Help me" replays, "💡 Turn all tips back on" resets.
- Auth: `POST /api/login-pin` — 4-digit PIN, rate-limited, 1-year cookie.
  Set PINs per user in Team tab. Audit: pnl_jobs.created_by/updated_by.

**Ellianna** (renamed from Ellian) — in-app assistant now on
`claude-fable-5`, effort low, with server-side fallback to
`claude-opus-4-8` (beta `server-side-fallback-2026-06-01`); knows Jarad vs
Joe from login and switches tone; tracker tools (tracker_jobs,
tracker_summary) added; floating "Ask Ellianna" bubble on every staff
screen. Hard rules in the persona: honest AI disclosure, never fabricate
price/warranty/insurance/timeline, never read out secrets.

**Full Hermes harness** — `/ellianna` folder is the install package for the
hermes-agent instance (persona yaml, paragon-pnl skill hitting this API with
a Dev Tools bearer token, cron debrief specs, telephony/email notes, Ruflo
MCP = memory + agent-spawn only). Needs an always-on box, not Vercel.
Inbound phone stays on the Hume EVI receptionist — do not build a second
inbound agent. All env vars set manually in dashboards; never call the
Vercel API from code.

## Ellianna drawer + knowledge base + /join portal (2026-07-14, second pass)

- **Left slide-in Ellianna drawer** on every back-office tab EXCEPT Site
  Scrape (bubble bottom-left, drawer slides out beside the sidebar). Mic
  input via browser SpeechRecognition (tap 🎤, talk, auto-sends); voice
  playback of replies via `POST /api/assistant/tts` (Hume TTS, **needs
  HUME_API_KEY in Vercel env**, graceful 503 without it; 🔊/🔇 toggle
  persists per device).
- **Knowledge base**: `ellianna/knowledge.md` (sanitized — NO credentials,
  ever) is loaded into the in-app assistant's system prompt: Paragon
  business facts, price ranges, warranty/financing/insurance postures,
  quarantined One Day claims, guardrails, who's-who. Update it there.
- **Filing tools**: Ellianna can now file things where they belong —
  add_tracker_job, add_crm_job, add_expense (receipt photos), and
  import_sheet (bulk CSV → CRM or tracker, dry-run preview first). Uploads
  now also accept .csv/.txt/.xlsx (converted to CSV text for her).
- **/join onboarding portal**: public self-serve door that exposes
  onboarding and NOTHING else. Email+password signup/login (Google
  Sign-In auto-appears when **GOOGLE_CLIENT_ID** is set in env; Apple not
  wired — needs paid Apple dev config). Everyone classifies as 1099
  **contractor** or **vendor** (only those two; any W-2 is manual back-end
  entry per Jarad). Signup creates a user with role `onboarding` — the API
  gate 403s that role everywhere except /api/me + /api/logout — plus an
  onboarding invite, then drops them into the existing /onboard/<token>
  wizard. Ellianna greets on the page (scripted). Classification shows as
  a pill in the admin review queue (`data.worker_type`).
- **SECURITY**: a credentials dump was pasted into chat on 2026-07-14 —
  those keys should be treated as exposed and rotated (GitHub PAT and
  Anthropic key first). Nothing from it is committed anywhere in this repo.

Env checklist (Vercel dashboard, manual only — never via API):
`ANTHROPIC_API_KEY` (Ellianna chat) · `HUME_API_KEY` (her voice) ·
`GOOGLE_CLIENT_ID` (optional, /join Google button) · existing
`DATABASE_URL`, `AUTH_SECRET`, `ENC_KEY`.

## Lead pipeline

**NEW (2026-07-12): staged lead pipeline.** Leads now live in their own
`leads` table (+ `lead_contacts`, `lead_activities`, `lead_stage_history`),
NOT in `jobs`. Stages: scraped → enriched → emailed → called → contacted →
appointment → estimate → installed, plus dead/dnc side-states. Import the
master enriched file with:

```
node scripts/import_leads.js <apiBase> data/leads/PARAGON-MASTER-LEADS-keansburg.csv
```

Idempotent upsert by normalized address+zip. Expected: 1,451 leads /
1,430 enriched. Contact-type gates (emailed needs email, called needs phone)
and DNC suppression are enforced in the API. Score weights live in
`src/lead-score.js`. The Middletown 07748 raw file
(`paragon-cellB-middletown.csv`, 13,027 rows) was never delivered to this
environment — import it with the same command when it surfaces (lands as
scraped/enriched=N). The Leads tab has the work queue (list), the pipeline
board (drag-to-move), and the full lead card. **Remember the Render free-tier
trap: re-run the import after every deploy.**

The older jobs-based importer `scripts/import-leads.js` merges CLAY (property
intel) + TRACERFY (skip-traced names) CSVs into one row per normalized
address+zip; validates full
address/city/state/zip; `--wipe` clears campaign rows; `--dry-run N` samples.
A real name always beats a blank. **Pending:** Tracerfy results file
`paragon-07734-TRACERFY-RESULTS-500.csv` (484 live phones) exists in another
agent's environment — never delivered here. Import it when it surfaces.
Batch 501–1000 not yet submitted to Tracerfy (~$20 credits needed).
Policy note: don't build scrapers that harvest homeowner PII; the licensed
Tracerfy/Clay pipeline is the ingestion path. Storm Watch tells you which
zips to pull next.

## Site Scrape SSO (in flight)

CRM side **live**: Site Scrape tab fetches `/api/sso-token` and loads
`https://sitescrape.vercel.app/?paragon_token=<t>`. Sitescrape side is
written but **unpushed** in the old session's clone; the changes (also
delivered as a brief): `POST /api/sso` validates the token against the CRM's
`/api/me` (Bearer) and issues its session; session cookie must be
`SameSite=None; Secure` in prod (Lax dies in iframes); front-end boot consumes
`?paragon_token` then strips it. Sitescrape's Vercel project needs
`SESSION_SECRET` set. Until that ships, the tab shows sitescrape's own login
(same CRM credentials work in it).

## Known warts / to-do

1. Uploads don't persist on Vercel (/tmp) — add Vercel Blob. Rotate the Neon DATABASE_URL J pasted into chat. Delete the old Render service.
2. Default admin passwords unchanged.
3. Leads have no names/phones until Tracerfy results import.
4. sitescrape repo has `scrape-search/API_KEYS_MASTER.md` committed on `main`
   with live keys — scrub it and rotate those keys. J also pasted the full
   key vault into chat twice; GitHub PAT + Cloudflare global key should rotate.
5. The six onboarding agreements need one NJ-attorney review before real subs
   sign (flagged in-app).
6. QuickBooks is CSV-parity only; direct sync is phase 2. PDF→line-item
   extraction for material docs not built. Per-trade cost split: tags stored,
   not reported.
7. Vercel deploy of the *preview* branches sits behind Vercel SSO — always
   embed/share production URLs.

## Hume EVI callback URL (2026-07-14)

`POST /api/callbacks/hume` — public webhook receiver for the phone agent.
HMAC-verified (`HMAC_SHA256(HUME_WEBHOOK_SIGNING_KEY, rawBody + '.' + ts)`,
headers `X-Hume-AI-Webhook-Signature` / `-Timestamp`, 180s staleness window);
503 until **HUME_WEBHOOK_SIGNING_KEY** is set in Vercel env. Events land in
`call_events`; staff feed at `GET /api/calls`; latest calls panel on the
Command Center; Ellianna `recent_calls` tool answers "who called today".
Configure in the Hume EVI config (webhooks: url + events chat_started,
chat_ended): https://ctimbuild-v1.vercel.app/api/callbacks/hume
