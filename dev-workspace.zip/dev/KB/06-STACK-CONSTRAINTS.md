# 06 · STACK CONSTRAINTS (enforced on every approval)
verified: 2026-07-14

Non-negotiable. Dev checks these before any approval. A request that violates
one is auto-denied, not discussed.

## Vercel
API returns 403 for coding agents. Domain and env-var changes are
**dashboard-only and operator-manual**.
- Never write a script that assumes API access to Vercel domains or env vars.
- A mission needing an env var produces an operator-action card: what to set,
  where, why. The card waits. The mission does not fake it.
- The portal shows Vercel state read-only. No write path in the UI because
  there is no write path in the API.

## PR boundary
Coding agents receive chat text only, never image bytes. Every visual spec
travels as text with numbers attached. If a PR references a visual, ask for
the text description. Do not infer.

## Credentials
Never in a prompt, a log, a config, or a committed file. Exposure means
immediate rotation plus an incident line.

## Client scope
Paragon only. Nothing from other ventures enters. Nothing here leaves.

## Engagement hard rules (verified before any external send)
- AI discloses honestly, no dodge.
- No agent fabricates a price, warranty term, insurance outcome, or timeline.
  Unknown escalates to a human.
- Ellianna's opening line is locked, verbatim:
  "Hi, you've reached Paragon Exteriors, this is Ellianna. What's going on
  with your home?"
- Voice stack is Hume EVI.

## Irreversible action classes (approval record required, every phase)
External sends. Spend. Deletes. Production deploys.

## The value thesis
Missed calls are the revenue leak. Every unanswered ring is a roof someone
else sells. A feature that does not close that leak is asking for budget from
the feature that does.
