# 01 · AGENT INTERFACE ARCHITECTURE
verified: 2026-07-14

## The 2026 protocol stack
- **MCP** · context. Tools and data into the model.
- **A2A** · agent to agent coordination.
- **AG-UI** · agent to user interaction. The event layer.
- **A2UI** · the UI the user actually touches.

## AG-UI
Open, event-based, bi-directional (CopilotKit). Runs over HTTP, SSE, or
WebSocket. Carries messages, tool calls, state deltas, UI events, and
human-in-the-loop approvals as first-class events. 2026 adoption: AWS Bedrock
AgentCore Runtime, Microsoft Agent Framework, Oracle and Google via Agent
Spec. HITL approvals ride the protocol, not bespoke websocket messages.

## Vercel AI SDK
Core (server/edge) + UI (client) + RSC. 2026 additions: Workflows (durable
long-running agents), Sandbox (secure execution), AI Elements (prebuilt
components). Missions outlive requests — Workflows is the durable primitive.

## AI Elements
Component registry on shadcn/ui modeling AI-native patterns: Reasoning, Tool,
Task, Plan, Checkpoint, Confirmation, ChainOfThought, Conversation, Message,
PromptInput, Attachments, Artifact, WebPreview, CodeBlock, InlineCitation,
Sources, Shimmer, Queue. Rule: fork into our registry on first commit —
Elements is a floor, not a ship state.

## Sandboxes
Vercel Sandbox and E2B both run Firecracker microVMs, own kernel each.

| | Vercel Sandbox | E2B |
|---|---|---|
| Model | Disposable | Persistent, resumable |
| Session cap | 45m Hobby / 5h Pro+ | 1h Hobby / 24h Pro |
| Secrets | Credential brokering (values stay outside) | Env vars inside |
| Network | Runtime outbound firewall | VM isolation only |

Default: Vercel Sandbox (credential brokering + outbound firewall matter for
a scrape stack). Fallback: E2B for long sessions, EU residency, self-host.

## v0's pattern
Take: split canvas (preview + code), every edit a diffable version, sandbox
runtime over browser preview, element selection resolving to source,
composite model routing. Leave: all of it as code — rebuild bespoke.
