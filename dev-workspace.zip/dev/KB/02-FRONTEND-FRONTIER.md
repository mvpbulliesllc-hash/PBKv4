# 02 · FRONTEND FRONTIER
verified: 2026-07-14

## Color: OKLCH or it is not a design system
Tailwind v4 and shadcn ship OKLCH. It is perceptually uniform: equal L steps
look equal, which HSL cannot deliver. Dark UI builds hierarchy from elevation
and elevation is L steps. Tokens under `:root` and `.dark`, exposed with
`@theme inline`.

## Dark-first is a workflow, not a toggle
Design dark first, derive light from it. Mature dark UI: subtle grey
variation plus elevation — not borders, not shadows.

## Type
Variable fonts. One file replaces six to eight static weights.

## Texture
CSS-generated grain / film grain / scanline: physical depth at near-zero
cost. Visual craft is a trust signal — grain, custom easing, and the empty
state nobody asked for say a human decided this.

## 3D and WebGPU
3D that chases wow is dead; 3D that solves comprehension or navigation is
live (configurators, data viz, spatial navigation).

## Motion
Motion for React covers ~90% of cases: gestures, layout, exit. Springs over
durations for anything spatial — a spring carries momentum, so interruption
decelerates instead of snapping.

## The template trap
A template is a starting vibe: the branch and direction, that is all. Filling
blanks and shipping is slop with a good wrapper. Every component earns its
place; every pixel is a decision.
