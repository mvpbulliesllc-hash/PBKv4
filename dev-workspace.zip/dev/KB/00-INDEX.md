# DEV-KB · INDEX

Dev reads this file, then pulls the one file the problem needs. Never more
than two. If nothing matches, the gap is real: route it to the operator to
research and add — the KB grows by mission, never by guess.

| Pull when | File |
|---|---|
| Choosing agent transport, streaming, sandbox, or agent-UI architecture | `01-AGENT-INTERFACE-ARCH.md` |
| Frontend decisions: framework, tokens, color, type, layout, dark UI | `02-FRONTEND-FRONTIER.md` |
| "Can we do X on Vercel / with PRs / with credentials" | `06-STACK-CONSTRAINTS.md` |

Every file carries a `verified:` date. Anything over 90 days old gets
re-verified before it drives a decision. A stale KB is worse than no KB
because it is confidently wrong.

What does not go in here: credentials, client data, anything from outside
this engagement.
