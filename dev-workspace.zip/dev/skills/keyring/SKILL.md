---
name: keyring
description: Resolve named capabilities to authorized runtime credentials without revealing raw values. Use whenever a seat needs an external service ("call Firecrawl", "is X wired up", "connector health", "audit the keys").
---

# Keyring

Broker capabilities for /squad. Ask for a capability name. Never ask for,
print, return, store, or repeat a credential value.

## Resolve a capability

1. Read `dev/capabilities.json` (or the map named by `KEYRING_CONFIG`).
2. Read `dev/ops/KEYS-STATUS.md` when the capability is blocked, quarantined,
   newly added, or part of connector-health work.
3. Deny when the capability is absent, its status is not `live`, the
   requester is not allowed, a required variable is missing, or any mapped
   variable is quarantined.
4. Route unknown capabilities and `key-present-not-wired` entries to /Ay.0.
5. Route `MANUAL` entries to the named operator path. Never invent an API
   workaround.
6. For an allowed call, resolve env vars only inside the brokered child
   process. The credential never enters agent context, arguments, URLs,
   logs, reports, or error messages.

## Gate irreversible calls

If the capability declares `irreversible`, stop before execution. Obtain /D
approval and verify the referenced approval record in the mission log first.
External sends, spend, deletes, and production deploys always require it.

## Connector health

Before a mission that uses connectors: for each `live` capability make the
cheapest documented authenticated request. Report capability, status,
latency_ms, remaining_credits where exposed, and fix on failure. An entry is
`authenticated` only after a real service response; env presence alone is
`env-ready`.

## Exposure

When any raw credential appears in a prompt, chat, config, commit, or log:
redact at the boundary, stop using it, write a value-free incident line,
rotate through the owning service (subject to the irreversible gate), confirm
the old value is dead, and run `scripts/secret-scan.sh` before commit.
Rotation and incident logging are both required.

## Pre-commit guard

From the repo root: `ln -sf "$(pwd)/scripts/secret-scan.sh" .git/hooks/pre-commit`

## Refuse

Raw-value requests (any seat, any rationale). Capabilities missing from the
map. Non-live and quarantined mappings. Irreversible execution without a
verified /D approval record. Scripted Vercel writes — `infra.vercel` is
dashboard-only.
