# KEYS STATUS
Compiled 2026-07-15. Companion to the env and `dev/capabilities.json`.
Names and status only. Values live in the Vercel env, never here.

## Resolved since the 2026-07-11 sweep

- **Nimble now has a key.** `NIMBLE_API_KEY` is live and mapped to
  `scrape.nimble`. Open item closed.
- **Parallel second key** captured as `PARALLEL_API_KEY_2`.
- **New arrivals:** Skylead, Cargo, AgentMail, Clay webhook pair, Attio
  webhook secret.

## Quarantined (commented out of the env, not loaded)

| Var | Blast radius | Do this |
|---|---|---|
| `GITHUB_TOKEN` | Repo write across every repo the account touches | Rotate. Re-add as a fine-grained PAT scoped to the Paragon repo, contents:write only. |
| `CF_GLOBAL_KEY` | Cloudflare account-wide, cannot be scoped | Delete. `CLOUDFLARE_API_TOKEN` already covers the use case. |
| `SLACK_APP_TOKEN` | Workspace-wide | Rotate. Only re-add when a capability actually needs it. Nothing does today. |

## BLOCKED: Twilio

`comms.twilio` cannot resolve. Two problems:

1. No auth token in the env. The Account SID is an identifier, not a
   credential. The token is absent.
2. Trust Hub Business Profile rejected 2026-07-14. Ticket 28171808.

**This is the critical path.** Missed-call text-back is skill #1 and it is
A2P SMS: it does not ship without an approved Trust Hub profile. Everything
else proceeds. See `TWILIO-FIX.md` and `TWILIO-REPLY-DRAFT.md`.

## Missing from the env entirely

- `TWILIO_AUTH_TOKEN` (blocked above)
- Composio is keyed but not wired. It is the specced auth spine.
