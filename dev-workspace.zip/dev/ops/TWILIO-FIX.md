# TWILIO TRUST HUB · REJECTION ANALYSIS AND FIX
Ticket 28171808 · Rejected 2026-07-14 by Onboarding & Compliance Operations.

## 1. What Twilio said

1. Cannot verify **jarad Derochey** as associated with **Eco Matrix Groups
   LLC** through public sources.
2. The email **contact@paragonhomeimprovementco.com** does not match the
   business website **ematrixgroup.com** or the company name.

## 2. The root cause

**Four names are on one profile**: Eco Matrix Groups LLC (entity),
ematrixgroup.com (website), paragonhomeimprovementco.com (email domain),
"Paragon Claims" (friendly name) — while the actual brand on the messages is
Paragon Exteriors. Trust Hub verification is a name-consistency check
against public record. Four names, one profile, automatic reject. Fixing the
email alone moves the rejection; it does not fix it. The structural problem:
the client's brand is registered inside the ISV's primary profile.

## 3. The fix (Twilio's own ISV architecture)

**Primary Customer Profile = Eco Matrix Groups LLC.**
- Business Identity: **ISV Reseller or Partner** (required to register
  secondaries at all).
- Email: an **@ematrixgroup.com** address.
- Authorized rep: Jarad, verified against Eco Matrix.

**Secondary Customer Profile = Paragon.**
- Created under the primary (Console or TrustHub API).
- Paragon's entity, Paragon's EIN, Paragon's authorized rep (Joe B).
- Notification email on a secondary should be an ISV-owned address.
- Brand and campaigns register under this.

## 4. Rejection #1 (authorized rep)

Give them one public link: Secretary of State record (strongest), an
ematrixgroup.com team/about page naming Jarad with title (publish it if it
does not exist), or LinkedIn with matching employer + title.
Case matters: "jarad Derochey" was submitted lowercase — match the legal
record exactly. Copy the entity name from the SoS record character for
character.

## 5. Rejection #2 (email domain)

Reply from **@ematrixgroup.com**. Not ecoaisolutions.com, not a Paragon
address, not Gmail. The domain has to match the website on the profile.

## 6. The flag

**Rename "Paragon Claims" before resubmitting.** Insurance-adjacent SMS is a
high-scrutiny carrier category and "Claims" puts the brand in it on sight.
If the campaign is homeowner lead capture and missed-call text-back, name it
**Paragon Exteriors** — the brand on the message, matching the client entity
and Ellianna's locked opening line. If it genuinely is a claims workflow,
that changes the use case and consent language and belongs in a separate
campaign under the same secondary profile.

## 7. Order of operations

1. Pull the SoS record. Copy the entity name exactly.
2. Publish or confirm a public page tying Jarad to Eco Matrix.
3. Edit the primary profile: legal name exact, Business Identity to ISV
   Reseller or Partner, rep name capitalized, email @ematrixgroup.com.
4. Reply to ticket 28171808 from @ematrixgroup.com with the public link
   (draft in `TWILIO-REPLY-DRAFT.md`).
5. Resubmit primary. Wait for approval.
6. Create the Paragon secondary customer profile under it.
7. Register the brand, then the campaign, under the secondary.
8. Only then does `comms.twilio` go live and missed-call text-back ship.

## 8. What this blocks

Missed-call text-back only. Everything else in the build proceeds. This is
the only thing on the board that gates the thesis, and it is gated on a
form.

## 9. Sources

- Direct customer vs ISV: https://help.twilio.com/articles/4402930862747
- ISV A2P 10DLC onboarding: https://www.twilio.com/docs/messaging/compliance/a2p-10dlc/onboarding-isv
- Create a Secondary Customer Profile: https://www.twilio.com/docs/trust-hub/trusthub-rest-api/api-create-secondary-customer-profile
- Error 18020 (authorized rep): https://www.twilio.com/docs/api/errors/18020
- Primary compliance profiles: https://www.twilio.com/docs/trust-hub/profiles/primary-compliance-profiles
