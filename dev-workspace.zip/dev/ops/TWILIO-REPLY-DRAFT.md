# REPLY DRAFT · Ticket 28171808

**Send from an @ematrixgroup.com address. That is half the fix.** Fill the
two brackets before sending.

---

**To:** Twilio Support (reply on ticket 28171808)
**Subject:** Re: Trust Hub Business Profile · Ticket 28171808

---

Ryan,

Thanks for the detail. Both items are addressed below, and I'm replying from
our company domain per your request.

**1. Authorized representative association**

Jarad Derochey is [TITLE] of Eco Matrix Group LLC. Public verification:

- [SECRETARY OF STATE LINK]
- https://www.ematrixgroup.com/[TEAM PAGE PATH]

The name on the original submission was entered lowercase. It should read
**Jarad Derochey**, matching the state registration exactly. That's corrected
in the profile.

**2. Email domain**

This reply comes from our company domain, ematrixgroup.com, which matches
the business website on the profile.

The paragonhomeimprovementco.com address was submitted in error. Paragon is
our client, not our entity, and their contact information should not have
been on our primary profile.

**3. Profile structure correction**

That error points at the real issue, so I've corrected it rather than just
swapping the email.

Eco Matrix Group LLC is an ISV. We build and operate messaging
infrastructure for client businesses. I've updated our Business Identity to
**ISV Reseller or Partner** so this profile is registered as what it
actually is.

Once the primary profile is approved, we'll create a Secondary Customer
Profile for our client under it, with their entity details and their
authorized representative, and register their brand and campaigns there.
That puts each business on its own profile and resolves the name mismatch at
the root.

The profile has been resubmitted. Let me know if you need anything further.

Jarad Derochey
[TITLE], Eco Matrix Group LLC
ematrixgroup.com
