// Mock data for the Communications Hub.
// Real wiring: per-provider OAuth (Zoom, Google, Microsoft) added later.
// UI is fully connect-aware so wiring only swaps the data source.

export type ConnState = "connected" | "available" | "error";

export interface Provider {
  id: string;
  name: string;
  category: "meet" | "workspace";
  connState: ConnState;
  detail: string;
  agent: string; // which agent operates this surface
}

export const MEET_PROVIDERS: Provider[] = [
  { id: "zoom", name: "Zoom", category: "meet", connState: "available", detail: "Not connected — grant to schedule + join", agent: "Concierge" },
  { id: "meet", name: "Google Meet", category: "meet", connState: "available", detail: "Bundled with Workspace grant", agent: "Concierge" },
  { id: "teams", name: "Microsoft Teams", category: "meet", connState: "available", detail: "Not connected", agent: "Concierge" },
];

export const WORKSPACE_PROVIDERS: Provider[] = [
  { id: "drive", name: "Drive", category: "workspace", connState: "available", detail: "File sync + vault ingest", agent: "Archivist" },
  { id: "gmail", name: "Gmail", category: "workspace", connState: "available", detail: "Thread triage + drafting", agent: "Correspondent" },
  { id: "sheets", name: "Sheets", category: "workspace", connState: "available", detail: "Financial models + exports", agent: "Analyst" },
  { id: "docs", name: "Docs", category: "workspace", connState: "available", detail: "Briefs + proposals", agent: "Scribe" },
  { id: "calendar", name: "Calendar", category: "workspace", connState: "available", detail: "Scheduling + reminders", agent: "Concierge" },
];

export interface Meeting {
  id: string;
  title: string;
  platform: "zoom" | "meet" | "teams";
  time: string;
  duration: string;
  attendees: number;
  status: "live" | "upcoming" | "done";
  agentJoined: boolean;
}

export const MEETINGS: Meeting[] = [
  { id: "m1", title: "Paragon Roofing — install sync", platform: "meet", time: "Now", duration: "30m", attendees: 4, status: "live", agentJoined: true },
  { id: "m2", title: "Exterior GC — proposal review", platform: "zoom", time: "2:30 PM", duration: "45m", attendees: 3, status: "upcoming", agentJoined: false },
  { id: "m3", title: "Ops standup", platform: "teams", time: "4:00 PM", duration: "15m", attendees: 6, status: "upcoming", agentJoined: false },
  { id: "m4", title: "Vendor onboarding", platform: "meet", time: "11:00 AM", duration: "30m", attendees: 2, status: "done", agentJoined: true },
];

export interface CommsThread {
  id: string;
  surface: "gmail" | "drive" | "sheets" | "docs";
  subject: string;
  preview: string;
  actor: string;
  time: string;
  unread: boolean;
  agentAction?: string;
}

export const THREADS: CommsThread[] = [
  { id: "c1", surface: "gmail", subject: "RE: Q3 roofing contract", preview: "Confirmed the revised scope — sending signed copy…", actor: "j.dechado@paragon", time: "12m", unread: true, agentAction: "draft ready" },
  { id: "c2", surface: "drive", subject: "paragon-financials-q3.xlsx", preview: "Shared with finance@ — ingesting to vault", actor: "Archivist", time: "18m", unread: false, agentAction: "syncing" },
  { id: "c3", surface: "sheets", subject: "Lead attribution model", preview: "Updated CAC formulas across 4 tabs", actor: "Analyst", time: "1h", unread: false },
  { id: "c4", surface: "gmail", subject: "New lead — exterior remodel", preview: "Website form submission routed to pipeline", actor: "leads@paragon", time: "2h", unread: true, agentAction: "triaged" },
  { id: "c5", surface: "docs", subject: "Exterior proposal — draft v3", preview: "Scribe generated pricing section from ledger", actor: "Scribe", time: "3h", unread: false },
];

export interface WorkflowStep {
  id: string;
  label: string;
  agent: string;
  status: "done" | "running" | "queued" | "blocked";
}

export interface Workflow {
  id: string;
  name: string;
  trigger: string;
  steps: WorkflowStep[];
}

export const WORKFLOWS: Workflow[] = [
  {
    id: "w1",
    name: "Inbound lead → booked call",
    trigger: "Gmail label: new-lead",
    steps: [
      { id: "s1", label: "Parse + enrich lead", agent: "Correspondent", status: "done" },
      { id: "s2", label: "Write to pipeline (NileDB)", agent: "Analyst", status: "done" },
      { id: "s3", label: "Draft intro email", agent: "Scribe", status: "running" },
      { id: "s4", label: "Propose calendar slots", agent: "Concierge", status: "queued" },
      { id: "s5", label: "Create Meet + send invite", agent: "Concierge", status: "queued" },
    ],
  },
  {
    id: "w2",
    name: "Meeting → follow-up + tasks",
    trigger: "Meeting ends",
    steps: [
      { id: "s1", label: "Pull Mux recording", agent: "Archivist", status: "done" },
      { id: "s2", label: "Summarize + extract actions", agent: "Analyst", status: "done" },
      { id: "s3", label: "Draft follow-up in Gmail", agent: "Scribe", status: "blocked" },
    ],
  },
];
