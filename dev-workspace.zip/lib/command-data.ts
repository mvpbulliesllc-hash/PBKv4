// Mock analytics for the Command Center tab.
// Real wiring pulls these from Neon/NileDB + Blob upload metadata later.

export interface Kpi {
  id: string;
  label: string;
  value: string;
  delta: number; // percent, signed
  spark: number[];
}

export const KPIS: Kpi[] = [
  { id: "rev", label: "Revenue MTD", value: "$482,900", delta: 12.4, spark: [30, 42, 38, 55, 61, 58, 72, 80] },
  { id: "margin", label: "Gross Margin", value: "61.2%", delta: 3.1, spark: [52, 54, 53, 57, 58, 59, 60, 61] },
  { id: "pipeline", label: "Pipeline", value: "$1.94M", delta: -4.8, spark: [70, 66, 68, 60, 58, 55, 52, 50] },
  { id: "cac", label: "Blended CAC", value: "$312", delta: -8.2, spark: [60, 58, 55, 50, 47, 44, 41, 38] },
];

export interface MonthPoint {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
}

export const PL_SERIES: MonthPoint[] = [
  { month: "Jan", revenue: 312, expenses: 198, profit: 114 },
  { month: "Feb", revenue: 348, expenses: 210, profit: 138 },
  { month: "Mar", revenue: 401, expenses: 226, profit: 175 },
  { month: "Apr", revenue: 388, expenses: 231, profit: 157 },
  { month: "May", revenue: 442, expenses: 248, profit: 194 },
  { month: "Jun", revenue: 468, expenses: 259, profit: 209 },
  { month: "Jul", revenue: 483, expenses: 264, profit: 219 },
];

export interface ExpenseSlice {
  name: string;
  value: number;
  tone: "green" | "blue" | "yellow" | "red" | "steel";
}

export const EXPENSE_BREAKDOWN: ExpenseSlice[] = [
  { name: "Payroll", value: 128, tone: "green" },
  { name: "Ad spend", value: 62, tone: "blue" },
  { name: "Tooling", value: 34, tone: "yellow" },
  { name: "Ops", value: 28, tone: "steel" },
  { name: "Other", value: 12, tone: "red" },
];

export interface LedgerRow {
  id: string;
  label: string;
  category: string;
  amount: number; // signed, thousands
  date: string;
  status: "cleared" | "pending" | "flagged";
}

export const LEDGER: LedgerRow[] = [
  { id: "l1", label: "Paragon Roofing — install draw 3", category: "Revenue", amount: 84.2, date: "Jul 14", status: "cleared" },
  { id: "l2", label: "Meta Ads — July flight", category: "Ad spend", amount: -18.4, date: "Jul 13", status: "cleared" },
  { id: "l3", label: "Payroll run — 07/12", category: "Payroll", amount: -64.0, date: "Jul 12", status: "cleared" },
  { id: "l4", label: "Exterior contract — deposit", category: "Revenue", amount: 42.5, date: "Jul 11", status: "pending" },
  { id: "l5", label: "Mux + Vercel — infra", category: "Tooling", amount: -3.9, date: "Jul 10", status: "cleared" },
  { id: "l6", label: "Refund — cancelled job", category: "Adjustment", amount: -6.2, date: "Jul 09", status: "flagged" },
];

export interface UploadItem {
  id: string;
  name: string;
  kind: "sheet" | "csv" | "pdf" | "video" | "image";
  size: string;
  status: "ready" | "processing" | "failed";
  progress?: number;
  rows?: string;
}

export const UPLOADS: UploadItem[] = [
  { id: "u1", name: "paragon-financials-q3.xlsx", kind: "sheet", size: "1.2 MB", status: "processing", progress: 64, rows: "4,210 rows" },
  { id: "u2", name: "roofing-leads.csv", kind: "csv", size: "820 KB", status: "ready", rows: "1,884 rows" },
  { id: "u3", name: "vendor-invoices-jul.pdf", kind: "pdf", size: "3.4 MB", status: "ready" },
  { id: "u4", name: "site-survey-mux.mp4", kind: "video", size: "88 MB", status: "failed" },
];

export const CASH = {
  onHand: 318400,
  receivable: 214800,
  payable: 96300,
  runwayDays: 142,
};
