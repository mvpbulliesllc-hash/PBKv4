// Mock mission state for the Paragon Dev Workspace cockpit.
// This is the single source of truth the UI renders. Real wiring
// (Neon/Nile/Mux/Blob/AI Gateway) replaces these readers later.

export type CapabilityStatus = "live" | "degraded" | "down" | "off";

export interface Capability {
  id: string;
  name: string;
  category: "storage" | "ai" | "media" | "comms" | "deploy" | "data";
  status: CapabilityStatus;
  detail: string;
  scoped: boolean; // explicitly granted to this session
}

export type FileStatus = "ready" | "ingesting" | "failed" | "indexed";

export interface ContextFile {
  id: string;
  name: string;
  path: string;
  kind: "file" | "folder" | "secret" | "env";
  size?: string;
  status: FileStatus;
  progress?: number; // 0..100 when ingesting
  note?: string;
}

export type VaultEntryKind = "secret" | "env" | "token" | "connection";

export interface VaultEntry {
  id: string;
  label: string;
  kind: VaultEntryKind;
  provider: string;
  status: "granted" | "available" | "revoked";
  lastUsed?: string;
  maskedHint: string; // NEVER the real value — masked hint only
}

export interface WorkbenchTab {
  id: "preview" | "browser" | "code" | "review" | "mux" | "comms" | "command";
  label: string;
}

export interface SessionScope {
  repository: string;
  branch: string;
  deployment: string;
  deploymentUrl: string;
  contextVersion: number;
  ready: boolean;
}

export const SESSION_SCOPE: SessionScope = {
  repository: "mvpbulliesllc-hash/ctimbuild-v1",
  branch: "dev-workspace",
  deployment: "paragon-crm · prod",
  deploymentUrl: "paragon-crm.vercel.app",
  contextVersion: 7,
  ready: true,
};

export const WORKBENCH_TABS: WorkbenchTab[] = [
  { id: "preview", label: "Preview" },
  { id: "browser", label: "Browser" },
  { id: "code", label: "Code" },
  { id: "review", label: "Review" },
  { id: "mux", label: "Mux" },
  { id: "command", label: "Command" },
  { id: "comms", label: "Comms" },
];

export const CAPABILITIES: Capability[] = [
  { id: "neon", name: "Neon Postgres", category: "storage", status: "live", detail: "ctimbuild-v1 · primary", scoped: true },
  { id: "nile", name: "NileDB", category: "data", status: "live", detail: "cobalt_engine · us-west-2", scoped: true },
  { id: "mux", name: "Mux Video", category: "media", status: "live", detail: "live preview builds", scoped: true },
  { id: "blob", name: "Vercel Blob", category: "storage", status: "live", detail: "uploads · vault", scoped: true },
  { id: "gateway", name: "AI Gateway", category: "ai", status: "live", detail: "agent inference", scoped: true },
  { id: "convex", name: "Convex", category: "data", status: "degraded", detail: "sync latency high", scoped: false },
  { id: "google", name: "Google Workspace", category: "comms", status: "off", detail: "not connected", scoped: false },
  { id: "zoom", name: "Zoom", category: "comms", status: "off", detail: "not connected", scoped: false },
];

export const CONTEXT_FILES: ContextFile[] = [
  { id: "f1", name: "DEV-DECHADO.md", path: "dev/", kind: "file", size: "18 KB", status: "indexed" },
  { id: "f2", name: "02-FRONTEND-FRONTIER.md", path: "dev/KB/", kind: "file", size: "24 KB", status: "indexed" },
  { id: "f3", name: "capabilities.json", path: "dev/", kind: "file", size: "3 KB", status: "indexed" },
  { id: "f4", name: "brand-assets/", path: "public/", kind: "folder", size: "42 files", status: "ready" },
  { id: "f5", name: "paragon-financials-q3.xlsx", path: "uploads/", kind: "file", size: "1.2 MB", status: "ingesting", progress: 64 },
  { id: "f6", name: "roofing-leads.csv", path: "uploads/", kind: "file", size: "820 KB", status: "ready" },
  { id: "f7", name: "site-survey-mux.mp4", path: "uploads/", kind: "file", size: "88 MB", status: "failed", note: "codec unsupported — reingest as h264" },
];

export const VAULT_ENTRIES: VaultEntry[] = [
  { id: "v1", label: "DATABASE_URL", kind: "connection", provider: "Neon", status: "granted", lastUsed: "2m ago", maskedHint: "postgres://…neon.tech" },
  { id: "v2", label: "NILEDB_URL", kind: "connection", provider: "NileDB", status: "granted", lastUsed: "just now", maskedHint: "postgres://…thenile.dev" },
  { id: "v3", label: "MUX_TOKEN_SECRET", kind: "secret", provider: "Mux", status: "granted", lastUsed: "5m ago", maskedHint: "••••••••••••" },
  { id: "v4", label: "BLOB_READ_WRITE_TOKEN", kind: "token", provider: "Vercel Blob", status: "granted", lastUsed: "1m ago", maskedHint: "vercel_blob_rw_••••" },
  { id: "v5", label: "AI_GATEWAY_API_KEY", kind: "secret", provider: "AI Gateway", status: "granted", lastUsed: "just now", maskedHint: "••••••••••••" },
  { id: "v6", label: "GOOGLE_OAUTH_CLIENT", kind: "secret", provider: "Google", status: "available", maskedHint: "not granted" },
  { id: "v7", label: "ZOOM_JWT", kind: "token", provider: "Zoom", status: "available", maskedHint: "not granted" },
];

export interface ThreadEvent {
  id: string;
  role: "agent" | "operator" | "system";
  kind: "message" | "tool" | "approval" | "diff";
  time: string;
  title: string;
  body?: string;
  meta?: string;
  tone?: "green" | "red" | "yellow" | "blue" | "neutral";
}

export const THREAD: ThreadEvent[] = [
  { id: "t1", role: "system", kind: "message", time: "04:31", title: "Session opened", body: "Scope v7 · 6 files ready · 5 capabilities live", tone: "neutral" },
  { id: "t2", role: "operator", kind: "message", time: "04:32", title: "Build the cockpit shell and resource dock", tone: "neutral" },
  { id: "t3", role: "agent", kind: "tool", time: "04:32", title: "inventory.check", body: "Resolved 6/7 context files. 1 failed (codec).", meta: "180ms", tone: "yellow" },
  { id: "t4", role: "agent", kind: "message", time: "04:33", title: "Rendering workbench + dock", body: "Preview target: paragon-crm.vercel.app", tone: "neutral" },
  { id: "t5", role: "agent", kind: "approval", time: "04:34", title: "Grant Google Workspace scope?", body: "Requested for Comms hub. Not yet granted.", tone: "blue" },
];
