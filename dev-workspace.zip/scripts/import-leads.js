// Merge campaign lead CSVs into ONE row per property and import as Leads.
//
// Usage:
//   node scripts/import-leads.js <apiBase> [--wipe] [--dry-run N] file1.csv file2.csv ...
//
// Merge rules (one property = one normalized street address + zip):
//   - Address / City / State / Zip come from the file's own columns
//     (CLAY: "Street Address"; TRACERFY: "Address"); OWNER_ZIP env wins if a
//     file lacks a Zip column.
//   - CLAY property intel (Year Built, Roof Age, Assessed Value) → notes.
//   - TRACERFY skip-traced First/Last Name (when present) → customer_name;
//     later files never overwrite a real name with a blank.
//   - Never duplicates: rows merge by key, and existing live rows are skipped.
//   - --wipe deletes campaign-imported leads (notes tag) before importing.
const fs = require('fs');

const args = process.argv.slice(2);
const apiBase = (args.find(a => /^https?:/.test(a)) || 'http://localhost:3000').replace(/\/$/, '');
const wipe = args.includes('--wipe');
const dryIx = args.indexOf('--dry-run');
const dryRun = dryIx >= 0 ? Number(args[dryIx + 1] || 5) : 0;
const files = args.filter(a => a.endsWith('.csv'));
if (!files.length) { console.error('No CSV files given.'); process.exit(1); }

const TAG = '07734 insurance non-renewal campaign';

function parseCsv(text) {
  const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter(l => l.trim());
  const split = (l) => {
    const out = []; let cur = '', inQ = false;
    for (const ch of l) {
      if (ch === '"') inQ = !inQ;
      else if (ch === ',' && !inQ) { out.push(cur); cur = ''; }
      else cur += ch;
    }
    out.push(cur);
    return out.map(s => s.trim());
  };
  const head = split(lines[0]);
  return lines.slice(1).map(l => Object.fromEntries(split(l).map((v, i) => [head[i], v])));
}

const title = (s) => s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
// Normalize for matching: uppercase, collapse spaces, standardize suffixes.
const normalize = (street) => street.toUpperCase().replace(/\s+/g, ' ').trim()
  .replace(/\bAVENUE\b/g, 'AVE').replace(/\bSTREET\b/g, 'ST').replace(/\bROAD\b/g, 'RD')
  .replace(/\bBOULEVARD\b/g, 'BLVD').replace(/\bDRIVE\b/g, 'DR').replace(/\bCOURT\b/g, 'CT')
  .replace(/\bPLACE\b/g, 'PL').replace(/\bLANE\b/g, 'LN').replace(/\bTERRACE\b/g, 'TER');

// ---------- merge all files into one map keyed by property ----------
const props = new Map();
for (const f of files) {
  for (const r of parseCsv(fs.readFileSync(f, 'utf8'))) {
    const street = r['Street Address'] || r['Address'] || '';
    if (!street) continue;
    const zip = r['Zip'] || process.env.OWNER_ZIP || '';
    const key = normalize(street) + '|' + zip;
    const p = props.get(key) || {
      street: title(street), city: '', state: '', zip: '',
      first: '', last: '', year_built: '', roof_age: '', assessed: '',
    };
    p.city = p.city || title(r['City'] || '');
    p.state = p.state || (r['State'] || '').toUpperCase();
    p.zip = p.zip || zip;
    p.first = p.first || (r['First Name'] || '').trim();
    p.last = p.last || (r['Last Name'] || '').trim();
    p.year_built = p.year_built || r['Year Built'] || '';
    p.roof_age = p.roof_age || r['Roof Age (min)'] || '';
    p.assessed = p.assessed || r['Assessed Value'] || '';
    props.set(key, p);
  }
}

const toLead = (p) => ({
  customer_name: [p.first, p.last].filter(Boolean).map(title).join(' ') || p.street,
  address: p.street,
  city: p.city, state: p.state, zip: p.zip,
  scope_of_work: 'Roof',
  notes: [TAG,
    p.year_built && `Built ${p.year_built}`,
    p.roof_age && `Roof age ≥${p.roof_age} yrs`,
    p.assessed && `Assessed $${Number(p.assessed).toLocaleString('en-US')}`,
  ].filter(Boolean).join(' · '),
});

async function main() {
  const leads = [...props.values()].map(toLead);
  const bad = leads.filter(l => !(l.address && l.city && l.state && l.zip));
  console.log(`${files.length} files → ${leads.length} unique properties; ${bad.length} missing address parts`);
  if (dryRun) {
    console.log(JSON.stringify(leads.slice(0, dryRun), null, 2));
    return;
  }
  if (bad.length) throw new Error('refusing to import rows with incomplete addresses');

  const login = await fetch(`${apiBase}/api/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: process.env.CRM_EMAIL || 'j@ecoaisolutions.com',
      password: process.env.CRM_PASSWORD,
    }),
  });
  if (!login.ok) throw new Error('login failed: ' + login.status);
  const headers = { 'Content-Type': 'application/json', Cookie: login.headers.get('set-cookie').split(';')[0] };

  let existing = await fetch(`${apiBase}/api/jobs`, { headers }).then(r => r.json());
  if (wipe) {
    const stale = existing.filter(j => (j.notes || '').startsWith(TAG));
    console.log(`wiping ${stale.length} previously imported campaign leads…`);
    for (const j of stale) await fetch(`${apiBase}/api/jobs/${j.id}`, { method: 'DELETE', headers });
    existing = existing.filter(j => !(j.notes || '').startsWith(TAG));
  }
  const seen = new Set(existing.map(j => normalize(j.address || '') + '|' + (j.zip || '')));

  let created = 0, skipped = 0, failed = 0;
  for (const lead of leads) {
    const key = normalize(lead.address) + '|' + lead.zip;
    if (seen.has(key)) { skipped++; continue; }
    const res = await fetch(`${apiBase}/api/jobs`, { method: 'POST', headers, body: JSON.stringify(lead) });
    if (res.ok) { created++; seen.add(key); } else { failed++; }
    if ((created + skipped + failed) % 200 === 0) console.log(`…${created + skipped + failed}`);
  }
  console.log(`Done: ${created} created, ${skipped} already present, ${failed} failed.`);
}

main().catch((e) => { console.error(e.message); process.exit(1); });
