#!/usr/bin/env bash
# Pre-commit secret scan: fail the commit if any credential literal appears
# in a staged file. Install:  ln -sf ../../scripts/secret-scan.sh .git/hooks/pre-commit
set -uo pipefail

PATTERNS='sk-ant-api03-|sk-svcacct-|sk-or-v1-|sk-nous-|nvapi-[A-Za-z0-9_-]{20}|fc-[0-9a-f]{32}|ghp_[A-Za-z0-9]{36}|github_pat_|xapp-[0-9]-|xoxb-|vercel_blob_rw_|bb_live_|cal_live_|whsec_[0-9a-f]{32}|am_us_[0-9a-f]{32}|cfut_[A-Za-z0-9]{40}|cfk_[A-Za-z0-9]{40}|ak_c-[A-Za-z0-9_-]{18}|oak_[A-Za-z0-9]{20}|zc_live_|AC[0-9a-f]{32}:|SK[0-9a-f]{32}'

FOUND=0

# Rule 1 (structural): any committed .env* template must have ZERO values.
# Pattern matching cannot catch opaque keys with no prefix (Parallel, Exa,
# Nimble, Cargo, Brightdata are bare alphanumeric). The only reliable rule
# for a template file is that the right side of every assignment is empty.
for f in $(git diff --cached --name-only --diff-filter=ACM 2>/dev/null | grep -E '\.env' || true); do
  case "$f" in
    .env|.env.local|.env.production) echo "BLOCKED: $f is staged. Env files with values are gitignored for a reason."; FOUND=1; continue ;;
  esac
  if git show ":$f" 2>/dev/null | grep -qE '^[A-Za-z0-9_]+=.+$'; then
    echo "BLOCKED: $f contains assignments with values. A template holds names only."
    git show ":$f" | grep -nE '^[A-Za-z0-9_]+=.+$' | sed -E 's/=.*/=[REDACTED]/' | head -5
    FOUND=1
  fi
done

# Rule 2 (pattern): known credential prefixes in source files. The scanner
# itself is excluded — its PATTERNS line matches its own regex.
FILES=$(git diff --cached --name-only --diff-filter=ACM 2>/dev/null | grep -vE '(\.env|\.md)$|scripts/secret-scan\.sh' || true)
for f in $FILES; do
  [ -f "$f" ] || continue
  if git show ":$f" 2>/dev/null | grep -nEq "$PATTERNS"; then
    echo "BLOCKED: credential literal in $f"
    git show ":$f" | grep -nE "$PATTERNS" | sed -E 's/(.{12}).*/\1[REDACTED]/' | head -3
    FOUND=1
  fi
done

if [ "$FOUND" -eq 1 ]; then
  echo ""
  echo "Commit blocked. Move the value to the env and reference it by name."
  exit 1
fi
exit 0
