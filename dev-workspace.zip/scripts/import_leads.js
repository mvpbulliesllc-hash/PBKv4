// Import staged pipeline leads (brief: PARAGON lead pipeline) into /api/leads.
//
// Usage:
//   node scripts/import_leads.js <apiBase> file1.csv [file2.csv ...] [--dry-run N]
//
// Master enriched files (24-col PARAGON-MASTER-LEADS layout) map 1:1.
// Raw assessor files with no contact columns land as scraped/enriched=N.
// Upsert key is normalized address + zip (server side) — re-running never
// duplicates. Auth via CRM_EMAIL/CRM_PASSWORD env (defaults to seeded admin).
const fs = require('fs');

const args = process.argv.slice(2);
const apiBase = (args.find(a => /^https?:/.test(a)) || 'http://localhost:3000').replace(/\/$/, '');
const files = args.filter(a => a.toLowerCase().endsWith('.csv'));
const dryIx = args.indexOf('--dry-run');
const dryRun = dryIx >= 0 ? Number(args[dryIx + 1] || 3) : 0;
if (!files.length) { console.error('No CSV files given.'); process.exit(1); }

function parseCsv(text) {
  // Header-aware, quote-aware, POSITIONAL — the master file has two "zip"
  // columns (property zip + mailing zip); position disambiguates them.
  const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter(l => l.trim());
  const split = (l) => {
    const out = []; let cur = '', inQ = false;
    for (const ch of l) {
      if (ch === '"') inQ = !inQ;
      else if (ch === ',' && !inQ) { out.push(cur); cur = ''; }
      else cur += ch;
    }
    out.push(cur);
    return out.map(s => s.trim());
  };
  const head = split(lines[0]).map(h => h.toLowerCase());
  return { head, rows: lines.slice(1).map(split) };
}

// Map one CSV row → the API's lead shape. col(name, nth) picks the nth
// occurrence of a duplicated header (zip appears at both positions).
function toLead(head, cells) {
  const col = (name, nth = 0) => {
    let seen = 0;
    for (let i = 0; i < head.length; i++) {
      if (head[i] === name && seen++ === nth) return cells[i] || '';
    }
    return '';
  };
  return {
    external_id: col('record_id'),
    source: col('source'),
    property_address: col('property_address') || col('street address') || col('address'),
    city: col('city'),
    state: col('state'),
    zip: col('zip', 0),
    owner_first: col('owner_first') || col('first name'),
    owner_last: col('owner_last') || col('last name'),
    primary_phone: col('primary_phone'),
    phone_type: col('phone_type'),
    mobiles: col('mobiles'),
    landlines: col('landlines'),
    emails: col('emails'),
    mail_address: col('mail_address'),
    mail_city: col('mail_city'),
    mail_state: col('mail_state'),
    mail_zip: col('zip', 1) || col('mail_zip'),
    absentee: col('absentee'),
    year_built: col('year_built') || col('year built'),
    roof_age_min: col('roof_age_min') || col('roof age (min)'),
    assessed_value: (col('assessed_value') || col('assessed value')).replace(/[$,]/g, ''),
    bldg_desc: col('bldg_desc'),
  };
}

async function main() {
  const leads = [];
  for (const f of files) {
    const { head, rows } = parseCsv(fs.readFileSync(f, 'utf8'));
    rows.forEach(cells => leads.push(toLead(head, cells)));
    console.log(`${f}: ${rows.length} rows`);
  }
  if (dryRun) return console.log(JSON.stringify(leads.slice(0, dryRun), null, 2));

  const login = await fetch(`${apiBase}/api/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: process.env.CRM_EMAIL || 'j@ecoaisolutions.com',
      password: process.env.CRM_PASSWORD,
    }),
  });
  if (!login.ok) throw new Error('login failed: ' + login.status);
  const headers = { 'Content-Type': 'application/json', Cookie: login.headers.get('set-cookie').split(';')[0] };

  let created = 0, updated = 0, skipped = 0;
  for (let i = 0; i < leads.length; i += 500) {
    const r = await fetch(`${apiBase}/api/leads/import`, {
      method: 'POST', headers, body: JSON.stringify({ rows: leads.slice(i, i + 500) }),
    });
    if (!r.ok) throw new Error(`import batch at ${i} failed: ${r.status} ${await r.text()}`);
    const out = await r.json();
    created += out.created; updated += out.updated; skipped += out.skipped;
    console.log(`…${Math.min(i + 500, leads.length)}/${leads.length}`);
  }
  const counts = await fetch(`${apiBase}/api/leads/counts`, { headers }).then(r => r.json());
  console.log(`\nDone: ${created} created, ${updated} updated, ${skipped} skipped (missing address/zip).`);
  console.log(`DB totals: ${counts.total} leads, ${counts.enriched_total} enriched.`);
  console.log('Per-stage:', counts.stages);
}

main().catch((e) => { console.error(e.message); process.exit(1); });
