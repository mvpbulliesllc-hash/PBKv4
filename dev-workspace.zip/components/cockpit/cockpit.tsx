"use client";

import { useRef, useState } from "react";
import {
  Panel,
  PanelGroup,
  PanelResizeHandle,
  type ImperativePanelHandle,
} from "react-resizable-panels";
import { MissionRail } from "./mission-rail";
import { DevPanel } from "./dev-panel";
import { Workbench } from "./workbench";
import type { WorkbenchTab } from "@/lib/mission-state";
import { PanelLeftOpen } from "lucide-react";

export function Cockpit() {
  const [railExpanded, setRailExpanded] = useState(false);
  const [railActive, setRailActive] = useState("sessions");
  const [tab, setTab] = useState<WorkbenchTab["id"]>("preview");
  const [fullscreen, setFullscreen] = useState(false);
  const [devCollapsed, setDevCollapsed] = useState(false);

  const devPanelRef = useRef<ImperativePanelHandle>(null);

  const toggleDev = () => {
    const panel = devPanelRef.current;
    if (!panel) return;
    if (panel.isCollapsed()) {
      panel.expand();
    } else {
      panel.collapse();
    }
  };

  return (
    <main className="flex h-dvh w-screen overflow-hidden bg-background">
      {!fullscreen && (
        <MissionRail
          expanded={railExpanded}
          onToggle={() => setRailExpanded((v) => !v)}
          active={railActive}
          onSelect={setRailActive}
        />
      )}

      <div className="min-w-0 flex-1">
        <PanelGroup
          direction="horizontal"
          autoSaveId="paragon-root"
          className="h-full"
        >
          {!fullscreen && (
            <>
              <Panel
                ref={devPanelRef}
                defaultSize={30}
                minSize={22}
                maxSize={40}
                collapsible
                collapsedSize={0}
                onCollapse={() => setDevCollapsed(true)}
                onExpand={() => setDevCollapsed(false)}
              >
                <DevPanel />
              </Panel>
              <PanelResizeHandle className="w-px bg-hairline transition-colors data-[resize-handle-state=hover]:bg-signal-blue" />
            </>
          )}

          <Panel minSize={60}>
            <div className="relative h-full">
              {!fullscreen && devCollapsed && (
                <button
                  type="button"
                  onClick={toggleDev}
                  aria-label="Reopen Dev panel"
                  className="absolute left-2 top-2 z-10 grid h-7 w-7 place-items-center rounded-xs border border-hairline bg-surface-1 text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground"
                >
                  <PanelLeftOpen className="h-4 w-4" strokeWidth={1.75} />
                </button>
              )}
              <Workbench
                active={tab}
                onActiveChange={setTab}
                fullscreen={fullscreen}
                onToggleFullscreen={() => setFullscreen((v) => !v)}
              />
            </div>
          </Panel>
        </PanelGroup>
      </div>
    </main>
  );
}
