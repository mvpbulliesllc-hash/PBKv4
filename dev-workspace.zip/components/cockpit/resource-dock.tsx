"use client";

import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import { cn } from "@/lib/cn";
import {
  CONTEXT_FILES,
  VAULT_ENTRIES,
  type ContextFile,
  type VaultEntry,
} from "@/lib/mission-state";
import { SignalDot, Pill, type Tone } from "./primitives";
import {
  File,
  Folder,
  UploadCloud,
  KeyRound,
  Lock,
  Plug,
  RotateCw,
  AlertTriangle,
  Eye,
} from "lucide-react";

function fileTone(status: ContextFile["status"]): Tone {
  if (status === "failed") return "red";
  if (status === "ingesting") return "yellow";
  if (status === "indexed") return "green";
  return "blue";
}

function ContextRow({ file }: { file: ContextFile }) {
  const tone = fileTone(file.status);
  const Icon = file.kind === "folder" ? Folder : File;
  return (
    <li className="group flex items-center gap-2.5 rounded-sm px-2 py-1.5 hover:bg-surface-1">
      <SignalDot tone={tone} pulse={file.status === "ingesting"} />
      <Icon
        className="h-3.5 w-3.5 shrink-0 text-muted-foreground"
        strokeWidth={1.75}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <span className="truncate font-mono text-xs text-foreground">
            {file.name}
          </span>
          <span className="shrink-0 truncate font-mono text-[10px] text-subtle">
            {file.path}
          </span>
        </div>
        {file.status === "ingesting" && (
          <div className="mt-1 h-0.5 w-full overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full bg-signal-yellow transition-all"
              style={{ width: `${file.progress ?? 0}%` }}
            />
          </div>
        )}
        {file.note && (
          <p className="mt-0.5 flex items-center gap-1 text-[10px] text-signal-red">
            <AlertTriangle className="h-3 w-3" strokeWidth={2} />
            {file.note}
          </p>
        )}
      </div>
      <span className="shrink-0 font-mono text-[10px] text-subtle">
        {file.size}
      </span>
      {file.status === "failed" && (
        <button
          type="button"
          aria-label="Reingest file"
          className="shrink-0 rounded-xs p-1 text-muted-foreground opacity-0 transition hover:bg-surface-2 hover:text-foreground group-hover:opacity-100"
        >
          <RotateCw className="h-3.5 w-3.5" strokeWidth={1.75} />
        </button>
      )}
    </li>
  );
}

function ContextFolder() {
  const ready = CONTEXT_FILES.filter(
    (f) => f.status === "ready" || f.status === "indexed",
  ).length;
  return (
    <div className="flex h-full min-w-[280px] flex-col">
      <header className="flex h-9 shrink-0 items-center justify-between border-b border-hairline px-3">
        <div className="flex items-center gap-2">
          <Folder className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
          <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
            Context Folder
          </span>
          <Pill tone="green">{ready} ready</Pill>
        </div>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-xs border border-hairline px-2 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground"
        >
          <UploadCloud className="h-3.5 w-3.5" strokeWidth={1.75} />
          Ingest
        </button>
      </header>
      <ul className="flex-1 overflow-y-auto p-1.5">
        {CONTEXT_FILES.map((file) => (
          <ContextRow key={file.id} file={file} />
        ))}
      </ul>
    </div>
  );
}

function vaultIcon(kind: VaultEntry["kind"]) {
  if (kind === "connection") return Plug;
  if (kind === "token") return KeyRound;
  return Lock;
}

function VaultRow({ entry }: { entry: VaultEntry }) {
  const Icon = vaultIcon(entry.kind);
  const granted = entry.status === "granted";
  const tone: Tone = granted ? "green" : entry.status === "revoked" ? "red" : "neutral";
  return (
    <li className="group flex items-center gap-2.5 rounded-sm px-2 py-1.5 hover:bg-surface-1">
      <SignalDot tone={tone} />
      <Icon className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={1.75} />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <span className="truncate font-mono text-xs text-foreground">
            {entry.label}
          </span>
          <span className="shrink-0 font-mono text-[10px] text-subtle">
            {entry.provider}
          </span>
        </div>
        <span className="font-mono text-[10px] text-subtle">
          {/* masked hint only — the real value never renders */}
          {entry.maskedHint}
        </span>
      </div>
      {granted ? (
        <span className="shrink-0 font-mono text-[10px] text-subtle">
          {entry.lastUsed}
        </span>
      ) : (
        <button
          type="button"
          className="shrink-0 rounded-xs border border-signal-blue/40 px-2 py-0.5 text-[10px] font-medium text-signal-blue transition-colors hover:bg-signal-blue/10"
        >
          Grant
        </button>
      )}
    </li>
  );
}

function SessionVault() {
  const live = VAULT_ENTRIES.filter((v) => v.status === "granted").length;
  return (
    <div className="flex h-full min-w-[280px] flex-col">
      <header className="flex h-9 shrink-0 items-center justify-between border-b border-hairline px-3">
        <div className="flex items-center gap-2">
          <Lock className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
          <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
            Session Vault
          </span>
          <Pill tone="green">{live} live</Pill>
        </div>
        <span className="inline-flex items-center gap-1 font-mono text-[10px] text-subtle">
          <Eye className="h-3 w-3" strokeWidth={1.75} />
          gated · logged
        </span>
      </header>
      <ul className="flex-1 overflow-y-auto p-1.5">
        {VAULT_ENTRIES.map((entry) => (
          <VaultRow key={entry.id} entry={entry} />
        ))}
      </ul>
      <div className="shrink-0 border-t border-hairline px-3 py-1.5">
        <p className="font-mono text-[10px] leading-relaxed text-subtle">
          Values never reach chat, model context, logs, or source control.
          Access is capability-based.
        </p>
      </div>
    </div>
  );
}

export function ResourceDock() {
  return (
    <div className="flex h-full flex-col bg-surface-0">
      <PanelGroup
        direction="horizontal"
        autoSaveId="paragon-dock"
        className="flex-1"
      >
        <Panel defaultSize={55} minSize={30}>
          <ContextFolder />
        </Panel>
        <PanelResizeHandle
          className={cn(
            "w-px bg-hairline transition-colors data-[resize-handle-state=hover]:bg-signal-blue",
          )}
        />
        <Panel defaultSize={45} minSize={30}>
          <SessionVault />
        </Panel>
      </PanelGroup>
    </div>
  );
}
