"use client";

import { SESSION_SCOPE } from "@/lib/mission-state";
import { SignalDot, Pill } from "./primitives";
import {
  RotateCw,
  ExternalLink,
  Monitor,
  Smartphone,
  Globe,
  FileCode2,
  GitCompare,
  Clapperboard,
  Lock,
} from "lucide-react";

function Chrome({
  children,
  actions,
}: {
  children: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-hairline px-3">
        {children}
        <div className="ml-auto flex items-center gap-1">{actions}</div>
      </div>
    </div>
  );
}

export function PreviewPanel() {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-hairline px-3">
        <SignalDot tone="green" pulse />
        <span className="font-mono text-xs text-muted-foreground">
          {SESSION_SCOPE.deploymentUrl}
        </span>
        <Pill tone="green">live build</Pill>
        <div className="ml-auto flex items-center gap-1">
          <button className="grid h-7 w-7 place-items-center rounded-xs text-muted-foreground hover:bg-surface-2 hover:text-foreground">
            <Smartphone className="h-4 w-4" strokeWidth={1.75} />
          </button>
          <button className="grid h-7 w-7 place-items-center rounded-xs bg-surface-2 text-foreground">
            <Monitor className="h-4 w-4" strokeWidth={1.75} />
          </button>
          <button className="grid h-7 w-7 place-items-center rounded-xs text-muted-foreground hover:bg-surface-2 hover:text-foreground">
            <RotateCw className="h-4 w-4" strokeWidth={1.75} />
          </button>
          <button className="grid h-7 w-7 place-items-center rounded-xs text-muted-foreground hover:bg-surface-2 hover:text-foreground">
            <ExternalLink className="h-4 w-4" strokeWidth={1.75} />
          </button>
        </div>
      </div>
      <div className="grid flex-1 place-items-center bg-surface-0 p-6">
        <div className="w-full max-w-3xl rounded-lg border border-hairline bg-background p-8">
          <div className="mx-auto max-w-md text-center">
            <div className="mx-auto mb-4 grid h-10 w-10 place-items-center rounded-md bg-steel font-mono text-sm font-bold text-steel-foreground">
              P
            </div>
            <p className="font-mono text-xs uppercase tracking-widest text-signal-green">
              Deployment ready
            </p>
            <h2 className="mt-2 text-balance text-xl font-semibold">
              Live preview streaming from {SESSION_SCOPE.deployment}
            </h2>
            <p className="mt-2 text-pretty text-sm text-muted-foreground">
              Build output renders here in real time. Every change to the
              selected deployment reflects instantly in this workbench.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function BrowserPanel() {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-hairline px-3">
        <Globe className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
        <div className="flex flex-1 items-center rounded-xs border border-hairline bg-surface-1 px-2 py-1">
          <span className="font-mono text-xs text-muted-foreground">
            https://{SESSION_SCOPE.deploymentUrl}/dashboard
          </span>
        </div>
        <Pill tone="blue">agent-driven</Pill>
      </div>
      <div className="grid flex-1 place-items-center bg-surface-0">
        <div className="text-center">
          <Globe className="mx-auto h-8 w-8 text-subtle" strokeWidth={1.25} />
          <p className="mt-3 text-sm text-muted-foreground">
            Agent browser session idle
          </p>
          <p className="mt-1 font-mono text-xs text-subtle">
            Tool calls to the headless browser render here.
          </p>
        </div>
      </div>
    </div>
  );
}

export function CodePanel() {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-hairline px-3">
        <FileCode2 className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
        <span className="font-mono text-xs text-muted-foreground">
          app/page.tsx
        </span>
        <Pill>read-only</Pill>
      </div>
      <div className="flex-1 overflow-auto bg-surface-0 p-4">
        <pre className="font-mono text-xs leading-relaxed text-muted-foreground">
          <code>{`export default function Page() {
  return (
    <Cockpit
      scope={sessionScope}
      workbench="preview"
    />
  );
}`}</code>
        </pre>
      </div>
    </div>
  );
}

export function ReviewPanel() {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-hairline px-3">
        <GitCompare className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
        <span className="font-mono text-xs text-muted-foreground">
          8 files changed
        </span>
        <Pill tone="green">+1,158</Pill>
        <Pill tone="red">-0</Pill>
      </div>
      <div className="flex-1 overflow-auto bg-surface-0 p-4 font-mono text-xs leading-relaxed">
        <p className="text-signal-green">+ app/globals.css</p>
        <p className="text-signal-green">+ app/layout.tsx</p>
        <p className="text-signal-green">+ components/cockpit/mission-rail.tsx</p>
        <p className="text-signal-green">+ components/cockpit/resource-dock.tsx</p>
      </div>
    </div>
  );
}

export function MuxPanel() {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-hairline px-3">
        <Clapperboard className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
        <span className="font-mono text-xs text-muted-foreground">
          Mux · live build stream
        </span>
        <Pill tone="green">encoding</Pill>
      </div>
      <div className="grid flex-1 place-items-center bg-black p-6">
        <div className="aspect-video w-full max-w-2xl rounded-md border border-hairline bg-surface-0">
          <div className="grid h-full place-items-center">
            <div className="text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full border border-signal-green/40">
                <span className="ml-0.5 h-0 w-0 border-y-[7px] border-l-[11px] border-y-transparent border-l-signal-green" />
              </div>
              <p className="mt-3 font-mono text-xs text-muted-foreground">
                Mux playback of the current build session
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function GenericPanel({
  label,
  hint,
}: {
  label: string;
  hint: string;
}) {
  return (
    <div className="grid h-full place-items-center bg-surface-0">
      <div className="text-center">
        <Lock className="mx-auto h-7 w-7 text-subtle" strokeWidth={1.25} />
        <p className="mt-3 text-sm text-muted-foreground">{label}</p>
        <p className="mt-1 font-mono text-xs text-subtle">{hint}</p>
      </div>
    </div>
  );
}
