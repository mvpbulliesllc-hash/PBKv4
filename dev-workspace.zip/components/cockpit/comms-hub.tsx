"use client";

import { cn } from "@/lib/cn";
import {
  MEET_PROVIDERS,
  WORKSPACE_PROVIDERS,
  MEETINGS,
  THREADS,
  WORKFLOWS,
  type Provider,
  type Meeting,
  type CommsThread,
  type WorkflowStep,
} from "@/lib/comms-data";
import { SignalDot, Pill, type Tone } from "./primitives";
import {
  Video,
  Mail,
  HardDrive,
  Sheet,
  FileText,
  Calendar,
  Users,
  ArrowRight,
  Plug,
  Check,
  Play,
  Bot,
} from "lucide-react";

const PROVIDER_ICON: Record<string, typeof Video> = {
  zoom: Video,
  meet: Video,
  teams: Video,
  drive: HardDrive,
  gmail: Mail,
  sheets: Sheet,
  docs: FileText,
  calendar: Calendar,
};

function connTone(state: Provider["connState"]): Tone {
  if (state === "connected") return "green";
  if (state === "error") return "red";
  return "neutral";
}

function ProviderCard({ provider }: { provider: Provider }) {
  const Icon = PROVIDER_ICON[provider.id] ?? Plug;
  const connected = provider.connState === "connected";
  return (
    <div className="flex items-center gap-3 rounded-md border border-hairline bg-surface-1 p-3">
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-sm border border-hairline bg-surface-2">
        <Icon className="h-4 w-4 text-foreground" strokeWidth={1.75} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-sm font-medium">{provider.name}</span>
          <SignalDot tone={connTone(provider.connState)} pulse={connected} />
        </div>
        <p className="truncate text-[11px] text-muted-foreground">
          {provider.detail}
        </p>
        <p className="mt-0.5 font-mono text-[10px] text-subtle">
          agent · {provider.agent}
        </p>
      </div>
      <button
        type="button"
        className={cn(
          "shrink-0 rounded-xs border px-2 py-1 text-[11px] font-medium transition-colors",
          connected
            ? "border-signal-green/40 text-signal-green"
            : "border-signal-blue/40 text-signal-blue hover:bg-signal-blue/10",
        )}
      >
        {connected ? (
          <span className="inline-flex items-center gap-1">
            <Check className="h-3 w-3" strokeWidth={2.5} /> Live
          </span>
        ) : (
          "Connect"
        )}
      </button>
    </div>
  );
}

function meetingTone(status: Meeting["status"]): Tone {
  if (status === "live") return "green";
  if (status === "upcoming") return "blue";
  return "neutral";
}

function MeetingRow({ meeting }: { meeting: Meeting }) {
  return (
    <li className="flex items-center gap-3 rounded-sm border border-hairline bg-surface-0 p-2.5">
      <div className="flex flex-col items-center">
        <SignalDot tone={meetingTone(meeting.status)} pulse={meeting.status === "live"} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm text-foreground">{meeting.title}</p>
        <div className="mt-0.5 flex items-center gap-2 font-mono text-[10px] text-subtle">
          <span className="uppercase">{meeting.platform}</span>
          <span>·</span>
          <span>{meeting.time}</span>
          <span>·</span>
          <span className="inline-flex items-center gap-0.5">
            <Users className="h-3 w-3" strokeWidth={1.75} />
            {meeting.attendees}
          </span>
          {meeting.agentJoined && (
            <>
              <span>·</span>
              <span className="inline-flex items-center gap-0.5 text-signal-green">
                <Bot className="h-3 w-3" strokeWidth={1.75} />
                agent
              </span>
            </>
          )}
        </div>
      </div>
      {meeting.status === "live" ? (
        <button className="shrink-0 rounded-xs bg-signal-green/15 px-2.5 py-1 text-[11px] font-medium text-signal-green hover:bg-signal-green/25">
          Join
        </button>
      ) : meeting.status === "upcoming" ? (
        <button className="shrink-0 rounded-xs border border-hairline px-2.5 py-1 text-[11px] text-muted-foreground hover:bg-surface-2 hover:text-foreground">
          Prep
        </button>
      ) : (
        <span className="shrink-0 font-mono text-[10px] text-subtle">ended</span>
      )}
    </li>
  );
}

const SURFACE_ICON: Record<string, typeof Mail> = {
  gmail: Mail,
  drive: HardDrive,
  sheets: Sheet,
  docs: FileText,
};

function ThreadRow({ thread }: { thread: CommsThread }) {
  const Icon = SURFACE_ICON[thread.surface] ?? Mail;
  return (
    <li className="flex items-start gap-3 border-b border-hairline px-1 py-2.5 last:border-0">
      <div className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-xs border border-hairline bg-surface-1">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          {thread.unread && <SignalDot tone="blue" />}
          <span
            className={cn(
              "truncate text-sm",
              thread.unread ? "font-medium text-foreground" : "text-muted-foreground",
            )}
          >
            {thread.subject}
          </span>
          <span className="ml-auto shrink-0 font-mono text-[10px] text-subtle">
            {thread.time}
          </span>
        </div>
        <p className="mt-0.5 truncate text-xs text-muted-foreground">
          {thread.preview}
        </p>
        <div className="mt-1 flex items-center gap-2">
          <span className="font-mono text-[10px] text-subtle">{thread.actor}</span>
          {thread.agentAction && (
            <Pill tone="green">{thread.agentAction}</Pill>
          )}
        </div>
      </div>
    </li>
  );
}

function stepTone(status: WorkflowStep["status"]): Tone {
  if (status === "done") return "green";
  if (status === "running") return "yellow";
  if (status === "blocked") return "red";
  return "neutral";
}

function WorkflowCard({
  workflow,
}: {
  workflow: (typeof WORKFLOWS)[number];
}) {
  return (
    <div className="rounded-md border border-hairline bg-surface-1 p-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">{workflow.name}</span>
        <Pill>
          <Play className="h-2.5 w-2.5" strokeWidth={2.5} />
          {workflow.trigger}
        </Pill>
      </div>
      <ol className="mt-3 space-y-0">
        {workflow.steps.map((step, i) => (
          <li key={step.id} className="flex items-center gap-2.5">
            <div className="flex flex-col items-center self-stretch">
              <SignalDot
                tone={stepTone(step.status)}
                pulse={step.status === "running"}
              />
              {i < workflow.steps.length - 1 && (
                <span className="my-0.5 w-px flex-1 bg-hairline" />
              )}
            </div>
            <div className="flex min-w-0 flex-1 items-center justify-between pb-2.5">
              <div className="min-w-0">
                <p
                  className={cn(
                    "truncate text-xs",
                    step.status === "queued"
                      ? "text-subtle"
                      : "text-foreground",
                  )}
                >
                  {step.label}
                </p>
                <p className="font-mono text-[10px] text-subtle">{step.agent}</p>
              </div>
              {step.status === "running" && (
                <span className="ml-2 shrink-0 font-mono text-[10px] text-signal-yellow">
                  running
                </span>
              )}
              {step.status === "blocked" && (
                <span className="ml-2 shrink-0 font-mono text-[10px] text-signal-red">
                  needs grant
                </span>
              )}
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-2 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
      {children}
    </h2>
  );
}

export function CommsHub() {
  return (
    <div className="h-full overflow-y-auto bg-surface-0">
      {/* header */}
      <div className="flex items-center justify-between border-b border-hairline px-4 py-2.5">
        <div className="flex items-center gap-2">
          <SignalDot tone="green" pulse />
          <h1 className="text-sm font-semibold">Communications Hub</h1>
          <Pill tone="yellow">1 workflow blocked</Pill>
        </div>
        <button className="inline-flex items-center gap-1.5 rounded-sm border border-signal-blue/40 px-3 py-1.5 text-xs font-medium text-signal-blue transition-colors hover:bg-signal-blue/10">
          <Plug className="h-3.5 w-3.5" strokeWidth={1.75} />
          Connect Google Workspace
        </button>
      </div>

      <div className="space-y-5 p-4">
        {/* providers */}
        <section>
          <SectionTitle>Meetings</SectionTitle>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            {MEET_PROVIDERS.map((p) => (
              <ProviderCard key={p.id} provider={p} />
            ))}
          </div>
        </section>

        <section>
          <SectionTitle>Google Workspace</SectionTitle>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
            {WORKSPACE_PROVIDERS.map((p) => (
              <ProviderCard key={p.id} provider={p} />
            ))}
          </div>
        </section>

        {/* activity + meetings + workflows */}
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
          <section className="xl:col-span-1">
            <SectionTitle>Today&apos;s meetings</SectionTitle>
            <ul className="space-y-2">
              {MEETINGS.map((m) => (
                <MeetingRow key={m.id} meeting={m} />
              ))}
            </ul>
          </section>

          <section className="xl:col-span-1">
            <SectionTitle>Cross-surface activity</SectionTitle>
            <div className="rounded-md border border-hairline bg-surface-1 px-3">
              <ul>
                {THREADS.map((t) => (
                  <ThreadRow key={t.id} thread={t} />
                ))}
              </ul>
            </div>
          </section>

          <section className="xl:col-span-1">
            <SectionTitle>Agent workflows</SectionTitle>
            <div className="space-y-3">
              {WORKFLOWS.map((w) => (
                <WorkflowCard key={w.id} workflow={w} />
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
