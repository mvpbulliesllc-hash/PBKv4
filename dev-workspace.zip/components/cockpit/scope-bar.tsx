"use client";

import {
  CONTEXT_FILES,
  VAULT_ENTRIES,
  SESSION_SCOPE,
} from "@/lib/mission-state";
import { SignalDot } from "./primitives";

// Collapsed resource dock for fullscreen — the scope is NEVER discarded.
export function ScopeBar() {
  const filesReady = CONTEXT_FILES.filter(
    (f) => f.status === "ready" || f.status === "indexed",
  ).length;
  const capsLive = VAULT_ENTRIES.filter((v) => v.status === "granted").length;

  return (
    <div className="flex h-9 shrink-0 items-center gap-4 border-t border-hairline bg-surface-0 px-4">
      <div className="flex items-center gap-2">
        <SignalDot tone="green" />
        <span className="font-mono text-[11px] text-muted-foreground">
          {filesReady} files ready
        </span>
      </div>
      <span className="text-subtle">·</span>
      <div className="flex items-center gap-2">
        <SignalDot tone="green" pulse />
        <span className="font-mono text-[11px] text-muted-foreground">
          {capsLive} capabilities live
        </span>
      </div>
      <span className="text-subtle">·</span>
      <span className="font-mono text-[11px] text-muted-foreground">
        scope v{SESSION_SCOPE.contextVersion}
      </span>
      <span className="ml-auto font-mono text-[11px] text-subtle">
        {SESSION_SCOPE.repository}
      </span>
    </div>
  );
}
