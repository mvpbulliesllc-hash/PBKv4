"use client";

import { cn } from "@/lib/cn";
import {
  Boxes,
  Terminal,
  GitPullRequest,
  Radio,
  Database,
  BarChart3,
  Settings,
  PanelLeftClose,
  PanelLeft,
} from "lucide-react";

const NAV = [
  { id: "sessions", label: "Sessions", icon: Terminal },
  { id: "projects", label: "Projects", icon: Boxes },
  { id: "prs", label: "Pull Requests", icon: GitPullRequest },
  { id: "comms", label: "Comms", icon: Radio },
  { id: "data", label: "Data", icon: Database },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
];

export function MissionRail({
  expanded,
  onToggle,
  active,
  onSelect,
}: {
  expanded: boolean;
  onToggle: () => void;
  active: string;
  onSelect: (id: string) => void;
}) {
  return (
    <nav
      aria-label="Mission rail"
      className={cn(
        "flex h-full shrink-0 flex-col border-r border-hairline bg-surface-0 transition-[width] duration-150 ease-out",
        expanded ? "w-[196px]" : "w-12",
      )}
    >
      <div
        className={cn(
          "flex h-11 items-center border-b border-hairline",
          expanded ? "px-3" : "justify-center",
        )}
      >
        <div className="flex items-center gap-2">
          <div className="grid h-6 w-6 place-items-center rounded-xs bg-steel font-mono text-[11px] font-bold text-steel-foreground">
            P
          </div>
          {expanded && (
            <span className="font-mono text-xs font-semibold tracking-wide">
              PARAGON
            </span>
          )}
        </div>
      </div>

      <ul className="flex flex-1 flex-col gap-0.5 p-2">
        {NAV.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onSelect(item.id)}
                aria-current={isActive ? "page" : undefined}
                title={!expanded ? item.label : undefined}
                className={cn(
                  "flex w-full items-center gap-3 rounded-sm px-2.5 py-2 text-sm transition-colors",
                  !expanded && "justify-center px-0",
                  isActive
                    ? "bg-surface-2 text-foreground"
                    : "text-muted-foreground hover:bg-surface-1 hover:text-foreground",
                )}
              >
                <Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
                {expanded && <span className="truncate">{item.label}</span>}
              </button>
            </li>
          );
        })}
      </ul>

      <div className="border-t border-hairline p-2">
        <button
          type="button"
          title="Settings"
          className={cn(
            "flex w-full items-center gap-3 rounded-sm px-2.5 py-2 text-sm text-muted-foreground transition-colors hover:bg-surface-1 hover:text-foreground",
            !expanded && "justify-center px-0",
          )}
        >
          <Settings className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
          {expanded && <span>Settings</span>}
        </button>
        <button
          type="button"
          onClick={onToggle}
          aria-label={expanded ? "Collapse rail" : "Expand rail"}
          className={cn(
            "mt-0.5 flex w-full items-center gap-3 rounded-sm px-2.5 py-2 text-sm text-muted-foreground transition-colors hover:bg-surface-1 hover:text-foreground",
            !expanded && "justify-center px-0",
          )}
        >
          {expanded ? (
            <PanelLeftClose className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
          ) : (
            <PanelLeft className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
          )}
          {expanded && <span>Collapse</span>}
        </button>
      </div>
    </nav>
  );
}
