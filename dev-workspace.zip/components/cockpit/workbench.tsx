"use client";

import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import { cn } from "@/lib/cn";
import { WORKBENCH_TABS, type WorkbenchTab } from "@/lib/mission-state";
import { ResourceDock } from "./resource-dock";
import { ScopeBar } from "./scope-bar";
import { CommandCenter } from "./command-center";
import { CommsHub } from "./comms-hub";
import {
  PreviewPanel,
  BrowserPanel,
  CodePanel,
  ReviewPanel,
  MuxPanel,
  GenericPanel,
} from "./workbench-panels";
import { Maximize2, Minimize2 } from "lucide-react";

function ActivePanel({ tab }: { tab: WorkbenchTab["id"] }) {
  switch (tab) {
    case "preview":
      return <PreviewPanel />;
    case "browser":
      return <BrowserPanel />;
    case "code":
      return <CodePanel />;
    case "review":
      return <ReviewPanel />;
    case "mux":
      return <MuxPanel />;
    case "command":
      return <CommandCenter />;
    case "comms":
      return <CommsHub />;
    default:
      return null;
  }
}

export function Workbench({
  active,
  onActiveChange,
  fullscreen,
  onToggleFullscreen,
}: {
  active: WorkbenchTab["id"];
  onActiveChange: (id: WorkbenchTab["id"]) => void;
  fullscreen: boolean;
  onToggleFullscreen: () => void;
}) {
  return (
    <section
      aria-label="Workbench"
      className="flex h-full min-w-0 flex-col bg-surface-0"
    >
      {/* header · 44px */}
      <header className="flex h-11 shrink-0 items-center gap-1 border-b border-hairline px-2">
        <div
          role="tablist"
          aria-label="Workbench surfaces"
          className="flex items-center gap-0.5 overflow-x-auto"
        >
          {WORKBENCH_TABS.map((tab) => {
            const isActive = active === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                aria-selected={isActive}
                onClick={() => onActiveChange(tab.id)}
                className={cn(
                  "shrink-0 rounded-sm px-3 py-1.5 text-[13px] font-medium transition-colors",
                  isActive
                    ? "bg-surface-2 text-foreground"
                    : "text-muted-foreground hover:bg-surface-1 hover:text-foreground",
                )}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
        <button
          type="button"
          onClick={onToggleFullscreen}
          aria-label={fullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          className="ml-auto grid h-7 w-7 shrink-0 place-items-center rounded-xs text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground"
        >
          {fullscreen ? (
            <Minimize2 className="h-4 w-4" strokeWidth={1.75} />
          ) : (
            <Maximize2 className="h-4 w-4" strokeWidth={1.75} />
          )}
        </button>
      </header>

      {/* canvas + resource dock */}
      <div className="min-h-0 flex-1">
        <PanelGroup
          direction="vertical"
          autoSaveId="paragon-workbench"
          className="h-full"
        >
          <Panel defaultSize={72} minSize={58} maxSize={82}>
            <div className="h-full" role="tabpanel">
              <ActivePanel tab={active} />
            </div>
          </Panel>

          {fullscreen ? (
            <ScopeBar />
          ) : (
            <>
              <PanelResizeHandle className="h-px bg-hairline transition-colors data-[resize-handle-state=hover]:bg-signal-blue" />
              <Panel defaultSize={28} minSize={14} maxSize={38}>
                <ResourceDock />
              </Panel>
            </>
          )}
        </PanelGroup>
      </div>
    </section>
  );
}
