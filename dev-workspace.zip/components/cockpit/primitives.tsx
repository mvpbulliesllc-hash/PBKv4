import { cn } from "@/lib/cn";
import type { CapabilityStatus } from "@/lib/mission-state";

const TONE_MAP = {
  green: "bg-signal-green",
  red: "bg-signal-red",
  yellow: "bg-signal-yellow",
  blue: "bg-signal-blue",
  neutral: "bg-subtle",
} as const;

export type Tone = keyof typeof TONE_MAP;

export function SignalDot({
  tone,
  pulse = false,
  className,
}: {
  tone: Tone;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "relative inline-flex h-1.5 w-1.5 shrink-0 rounded-full",
        TONE_MAP[tone],
        className,
      )}
    >
      {pulse && tone !== "neutral" && (
        <span
          className={cn(
            "absolute inset-0 rounded-full opacity-60",
            TONE_MAP[tone],
            "motion-safe:animate-ping",
          )}
        />
      )}
    </span>
  );
}

export function statusToTone(status: CapabilityStatus): Tone {
  switch (status) {
    case "live":
      return "green";
    case "degraded":
      return "yellow";
    case "down":
      return "red";
    default:
      return "neutral";
  }
}

export function Pill({
  children,
  tone = "neutral",
  className,
}: {
  children: React.ReactNode;
  tone?: Tone;
  className?: string;
}) {
  const border =
    tone === "green"
      ? "border-signal-green/40 text-signal-green"
      : tone === "red"
        ? "border-signal-red/40 text-signal-red"
        : tone === "yellow"
          ? "border-signal-yellow/40 text-signal-yellow"
          : tone === "blue"
            ? "border-signal-blue/40 text-signal-blue"
            : "border-hairline text-muted-foreground";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-xs border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider",
        border,
        className,
      )}
    >
      {children}
    </span>
  );
}
