"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  Line,
  LineChart,
} from "recharts";
import { cn } from "@/lib/cn";
import {
  KPIS,
  PL_SERIES,
  EXPENSE_BREAKDOWN,
  LEDGER,
  UPLOADS,
  CASH,
  type Kpi,
  type LedgerRow,
  type UploadItem,
} from "@/lib/command-data";
import { SignalDot, Pill, type Tone } from "./primitives";
import {
  TrendingUp,
  TrendingDown,
  UploadCloud,
  FileSpreadsheet,
  FileText,
  FileVideo,
  Table as TableIcon,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";

const TONE_VAR: Record<string, string> = {
  green: "var(--signal-green)",
  blue: "var(--signal-blue)",
  yellow: "var(--signal-yellow)",
  red: "var(--signal-red)",
  steel: "var(--surface-3)",
};

function money(thousands: number) {
  const sign = thousands < 0 ? "-" : "";
  return `${sign}$${Math.abs(thousands).toLocaleString()}K`;
}

function Card({
  title,
  children,
  className,
  action,
}: {
  title: string;
  children: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex flex-col rounded-md border border-hairline bg-surface-1",
        className,
      )}
    >
      <div className="flex h-8 shrink-0 items-center justify-between border-b border-hairline px-3">
        <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
          {title}
        </span>
        {action}
      </div>
      <div className="min-h-0 flex-1 p-3">{children}</div>
    </div>
  );
}

function KpiCard({ kpi }: { kpi: Kpi }) {
  const up = kpi.delta >= 0;
  const data = kpi.spark.map((v, i) => ({ i, v }));
  return (
    <div className="flex flex-col justify-between rounded-md border border-hairline bg-surface-1 p-3">
      <div className="flex items-start justify-between">
        <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          {kpi.label}
        </span>
        <span
          className={cn(
            "inline-flex items-center gap-0.5 font-mono text-[11px]",
            up ? "text-signal-green" : "text-signal-red",
          )}
        >
          {up ? (
            <TrendingUp className="h-3 w-3" strokeWidth={2} />
          ) : (
            <TrendingDown className="h-3 w-3" strokeWidth={2} />
          )}
          {up ? "+" : ""}
          {kpi.delta}%
        </span>
      </div>
      <div className="mt-1 text-xl font-semibold tracking-tight">
        {kpi.value}
      </div>
      <div className="mt-2 h-8">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <Line
              type="monotone"
              dataKey="v"
              stroke={up ? "var(--signal-green)" : "var(--signal-red)"}
              strokeWidth={1.5}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-sm border border-hairline-strong bg-surface-2 px-2.5 py-1.5 shadow-lg">
      {label && (
        <p className="mb-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
      )}
      {payload.map((p: any) => (
        <p key={p.dataKey} className="font-mono text-[11px] text-foreground">
          <span style={{ color: p.color }}>■</span> {p.name}: {money(p.value)}
        </p>
      ))}
    </div>
  );
}

function ledgerTone(status: LedgerRow["status"]): Tone {
  if (status === "cleared") return "green";
  if (status === "pending") return "yellow";
  return "red";
}

function uploadIcon(kind: UploadItem["kind"]) {
  if (kind === "sheet") return FileSpreadsheet;
  if (kind === "csv") return TableIcon;
  if (kind === "video") return FileVideo;
  return FileText;
}

function uploadTone(status: UploadItem["status"]): Tone {
  if (status === "ready") return "green";
  if (status === "processing") return "yellow";
  return "red";
}

export function CommandCenter() {
  const totalExpense = EXPENSE_BREAKDOWN.reduce((s, e) => s + e.value, 0);

  return (
    <div className="h-full overflow-y-auto bg-surface-0">
      <div className="flex items-center justify-between border-b border-hairline px-4 py-2.5">
        <div className="flex items-center gap-2">
          <SignalDot tone="green" pulse />
          <h1 className="text-sm font-semibold">Command Center</h1>
          <Pill>paragon · consolidated</Pill>
        </div>
        <span className="font-mono text-[11px] text-subtle">
          synced 2m ago · Neon + NileDB
        </span>
      </div>

      <div className="space-y-3 p-4">
        {/* KPI row */}
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {KPIS.map((k) => (
            <KpiCard key={k.id} kpi={k} />
          ))}
        </div>

        {/* P&L + expense breakdown */}
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
          <Card
            title="Profit & Loss · trailing 7mo"
            className="lg:col-span-2"
            action={
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1 font-mono text-[10px] text-muted-foreground">
                  <span className="h-1.5 w-1.5 rounded-full bg-signal-green" />
                  Revenue
                </span>
                <span className="inline-flex items-center gap-1 font-mono text-[10px] text-muted-foreground">
                  <span className="h-1.5 w-1.5 rounded-full bg-signal-blue" />
                  Profit
                </span>
              </div>
            }
          >
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={PL_SERIES} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}>
                  <defs>
                    <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--signal-green)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--signal-green)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="prof" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--signal-blue)" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="var(--signal-blue)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 10, fill: "var(--subtle)", fontFamily: "var(--font-mono)" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip content={<ChartTooltip />} cursor={{ stroke: "var(--hairline-strong)" }} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    name="Revenue"
                    stroke="var(--signal-green)"
                    strokeWidth={1.75}
                    fill="url(#rev)"
                  />
                  <Area
                    type="monotone"
                    dataKey="profit"
                    name="Profit"
                    stroke="var(--signal-blue)"
                    strokeWidth={1.75}
                    fill="url(#prof)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card title={`Expenses · ${money(totalExpense)}/mo`}>
            <div className="flex h-56 flex-col">
              <div className="h-28">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={EXPENSE_BREAKDOWN} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 9, fill: "var(--subtle)", fontFamily: "var(--font-mono)" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip content={<ChartTooltip />} cursor={{ fill: "var(--surface-2)" }} />
                    <Bar dataKey="value" name="Spend" radius={[2, 2, 0, 0]}>
                      {EXPENSE_BREAKDOWN.map((e) => (
                        <Cell key={e.name} fill={TONE_VAR[e.tone]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <ul className="mt-3 space-y-1.5">
                {EXPENSE_BREAKDOWN.map((e) => (
                  <li key={e.name} className="flex items-center gap-2 text-xs">
                    <span
                      className="h-2 w-2 rounded-xs"
                      style={{ background: TONE_VAR[e.tone] }}
                    />
                    <span className="text-muted-foreground">{e.name}</span>
                    <span className="ml-auto font-mono text-subtle">
                      {Math.round((e.value / totalExpense) * 100)}%
                    </span>
                    <span className="w-14 text-right font-mono text-foreground">
                      {money(e.value)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </Card>
        </div>

        {/* Cash position strip */}
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            { label: "Cash on hand", value: CASH.onHand, tone: "green" as Tone },
            { label: "Receivable", value: CASH.receivable, tone: "blue" as Tone },
            { label: "Payable", value: CASH.payable, tone: "yellow" as Tone },
          ].map((c) => (
            <div key={c.label} className="rounded-md border border-hairline bg-surface-1 p-3">
              <div className="flex items-center gap-1.5">
                <SignalDot tone={c.tone} />
                <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  {c.label}
                </span>
              </div>
              <p className="mt-1.5 text-lg font-semibold tracking-tight">
                ${c.value.toLocaleString()}
              </p>
            </div>
          ))}
          <div className="rounded-md border border-signal-green/30 bg-signal-green/5 p-3">
            <span className="font-mono text-[10px] uppercase tracking-wider text-signal-green">
              Runway
            </span>
            <p className="mt-1.5 text-lg font-semibold tracking-tight text-signal-green">
              {CASH.runwayDays} days
            </p>
          </div>
        </div>

        {/* Ledger + uploads */}
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
          <Card title="Recent ledger" className="lg:col-span-2">
            <table className="w-full">
              <tbody className="divide-y divide-hairline">
                {LEDGER.map((row) => (
                  <tr key={row.id} className="text-sm">
                    <td className="py-2 pr-2">
                      <div className="flex items-center gap-2">
                        <SignalDot tone={ledgerTone(row.status)} />
                        <span className="text-foreground">{row.label}</span>
                      </div>
                    </td>
                    <td className="py-2 px-2">
                      <span className="font-mono text-[11px] text-subtle">
                        {row.category}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right font-mono text-[11px] text-subtle">
                      {row.date}
                    </td>
                    <td className="py-2 pl-2 text-right">
                      <span
                        className={cn(
                          "inline-flex items-center gap-0.5 font-mono text-xs",
                          row.amount >= 0 ? "text-signal-green" : "text-foreground",
                        )}
                      >
                        {row.amount >= 0 ? (
                          <ArrowUpRight className="h-3 w-3" strokeWidth={2} />
                        ) : (
                          <ArrowDownRight className="h-3 w-3 text-signal-red" strokeWidth={2} />
                        )}
                        {money(row.amount)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          <Card
            title="Uploads · vault ingest"
            action={
              <button className="inline-flex items-center gap-1 rounded-xs border border-hairline px-1.5 py-0.5 text-[10px] text-muted-foreground hover:bg-surface-2 hover:text-foreground">
                <UploadCloud className="h-3 w-3" strokeWidth={1.75} />
                Add
              </button>
            }
          >
            <ul className="space-y-2">
              {UPLOADS.map((u) => {
                const Icon = uploadIcon(u.kind);
                return (
                  <li
                    key={u.id}
                    className="rounded-sm border border-hairline bg-surface-0 p-2"
                  >
                    <div className="flex items-center gap-2">
                      <SignalDot tone={uploadTone(u.status)} pulse={u.status === "processing"} />
                      <Icon className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={1.75} />
                      <span className="min-w-0 flex-1 truncate font-mono text-xs">
                        {u.name}
                      </span>
                      <span className="shrink-0 font-mono text-[10px] text-subtle">
                        {u.size}
                      </span>
                    </div>
                    {u.status === "processing" && (
                      <div className="mt-1.5 h-0.5 w-full overflow-hidden rounded-full bg-surface-2">
                        <div
                          className="h-full bg-signal-yellow"
                          style={{ width: `${u.progress ?? 0}%` }}
                        />
                      </div>
                    )}
                    {u.rows && (
                      <p className="mt-1 font-mono text-[10px] text-subtle">{u.rows}</p>
                    )}
                    {u.status === "failed" && (
                      <p className="mt-1 font-mono text-[10px] text-signal-red">
                        ingest failed — reingest as h264
                      </p>
                    )}
                  </li>
                );
              })}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
