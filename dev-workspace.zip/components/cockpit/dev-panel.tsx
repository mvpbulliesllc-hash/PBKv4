"use client";

import { useState } from "react";
import { cn } from "@/lib/cn";
import { THREAD, SESSION_SCOPE, type ThreadEvent } from "@/lib/mission-state";
import { SignalDot, Pill, type Tone } from "./primitives";
import {
  ArrowUp,
  Paperclip,
  Check,
  X,
  Wrench,
  GitCompare,
  Cpu,
} from "lucide-react";

function EventIcon({ event }: { event: ThreadEvent }) {
  const base = "h-3.5 w-3.5";
  if (event.kind === "tool")
    return <Wrench className={base} strokeWidth={1.75} />;
  if (event.kind === "diff")
    return <GitCompare className={base} strokeWidth={1.75} />;
  if (event.role === "agent")
    return <Cpu className={base} strokeWidth={1.75} />;
  return null;
}

function ThreadRow({ event }: { event: ThreadEvent }) {
  const tone = (event.tone ?? "neutral") as Tone;

  if (event.kind === "approval") {
    return (
      <div className="rounded-sm border border-signal-blue/30 bg-signal-blue/5 p-3">
        <div className="flex items-center gap-2">
          <SignalDot tone="blue" pulse />
          <span className="text-sm font-medium">{event.title}</span>
        </div>
        {event.body && (
          <p className="mt-1 text-xs text-muted-foreground">{event.body}</p>
        )}
        <div className="mt-2.5 flex gap-2">
          <button
            type="button"
            className="inline-flex items-center gap-1.5 rounded-xs border border-signal-green/40 bg-signal-green/10 px-2.5 py-1 text-xs font-medium text-signal-green transition-colors hover:bg-signal-green/20"
          >
            <Check className="h-3.5 w-3.5" strokeWidth={2} /> Grant
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-1.5 rounded-xs border border-hairline px-2.5 py-1 text-xs font-medium text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground"
          >
            <X className="h-3.5 w-3.5" strokeWidth={2} /> Deny
          </button>
        </div>
      </div>
    );
  }

  const isOperator = event.role === "operator";

  return (
    <div className="flex gap-2.5">
      <div className="flex w-8 shrink-0 flex-col items-center gap-1 pt-0.5">
        <span className="font-mono text-[10px] text-subtle">{event.time}</span>
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          {event.kind !== "message" && (
            <span className="text-muted-foreground">
              <EventIcon event={event} />
            </span>
          )}
          <span
            className={cn(
              "text-sm",
              isOperator ? "font-medium text-foreground" : "text-foreground",
              event.kind === "tool" && "font-mono text-[13px]",
            )}
          >
            {event.title}
          </span>
          {event.meta && (
            <span className="ml-auto shrink-0 font-mono text-[10px] text-subtle">
              {event.meta}
            </span>
          )}
        </div>
        {event.body && (
          <p
            className={cn(
              "mt-0.5 text-xs leading-relaxed text-muted-foreground",
              event.kind === "tool" && "font-mono",
            )}
          >
            {event.body}
          </p>
        )}
        {tone !== "neutral" && event.kind === "tool" && (
          <div className="mt-1">
            <Pill tone={tone}>
              <SignalDot tone={tone} /> {tone === "yellow" ? "partial" : tone}
            </Pill>
          </div>
        )}
      </div>
    </div>
  );
}

export function DevPanel() {
  const [value, setValue] = useState("");

  return (
    <section
      aria-label="Dev control channel"
      className="flex h-full min-w-0 flex-col bg-surface-0"
    >
      {/* header */}
      <header className="flex h-11 shrink-0 items-center justify-between border-b border-hairline px-3">
        <div className="flex items-center gap-2 min-w-0">
          <SignalDot tone="green" pulse />
          <span className="truncate font-mono text-xs">
            {SESSION_SCOPE.branch}
          </span>
        </div>
        <Pill>scope v{SESSION_SCOPE.contextVersion}</Pill>
      </header>

      {/* thread */}
      <div className="flex-1 space-y-4 overflow-y-auto p-3">
        {THREAD.map((event) => (
          <ThreadRow key={event.id} event={event} />
        ))}
        {/* streaming indicator */}
        <div className="flex items-center gap-2 pl-10 text-xs text-muted-foreground">
          <SignalDot tone="green" pulse />
          <span className="font-mono">agent working…</span>
        </div>
      </div>

      {/* composer */}
      <div className="shrink-0 border-t border-hairline p-3">
        <div className="rounded-md border border-hairline bg-surface-1 focus-within:border-hairline-strong">
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (
                e.key === "Enter" &&
                !e.shiftKey &&
                !e.nativeEvent.isComposing &&
                e.keyCode !== 229
              ) {
                e.preventDefault();
                setValue("");
              }
            }}
            rows={2}
            placeholder="Direct the agent. Enter to send, Shift+Enter for newline."
            className="w-full resize-none bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-subtle focus:outline-none"
          />
          <div className="flex items-center justify-between border-t border-hairline px-2 py-1.5">
            <button
              type="button"
              aria-label="Attach to context folder"
              className="grid h-7 w-7 place-items-center rounded-xs text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground"
            >
              <Paperclip className="h-4 w-4" strokeWidth={1.75} />
            </button>
            <button
              type="button"
              disabled={!value.trim()}
              onClick={() => setValue("")}
              aria-label="Send"
              className="grid h-7 w-7 place-items-center rounded-xs bg-foreground text-background transition-opacity disabled:opacity-30"
            >
              <ArrowUp className="h-4 w-4" strokeWidth={2.25} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
