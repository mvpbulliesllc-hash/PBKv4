// Vercel serverless entry point: the whole Express app runs as one function.
// vercel.json rewrites /api/*, /join, /onboard/* and /uploads/* here; static
// files in public/ are served by Vercel's CDN directly.
// Any startup failure must return a readable JSON error, never an opaque
// FUNCTION_INVOCATION_FAILED.
let handler;
try {
  const { createApp } = require('../src/server');
  handler = createApp();
} catch (e) {
  console.error('[boot]', e);
  handler = (req, res) => {
    res.statusCode = 500;
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ error: 'Server failed to start: ' + e.message }));
  };
}
module.exports = handler;
