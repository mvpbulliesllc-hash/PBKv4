/* P&L Job Tracker — built for a fifth grader. Big buttons, one question per
   screen, live math, coach bubbles on every screen. Loaded after app.js and
   shares its globals ($view, api, esc, fmt$, toCents, me, openModal). */

let tScreen = 'home';

async function tracker(arg) {
  tScreen = arg || tScreen || 'home';
  await ({ home: tHome, jobs: tJobs, money: tMoney, add: tWizard }[tScreen] || tHome)();
}
const tGo = (s) => { tScreen = s; tracker(s); };

const T_HELP = (screen) => `<div style="text-align:right">
  <button class="chip" data-thelp="${screen}">❓ Help me</button></div>`;
const wireHelp = () => $view.querySelectorAll('[data-thelp]').forEach(b =>
  b.onclick = () => runCoach(b.dataset.thelp, true));

/* ---------- home: max 3 primary actions ---------- */
async function tHome() {
  $view.innerHTML = `<div class="tracker">
    ${T_HELP('home')}
    <h2 style="font-size:28px">What do you want to do?</h2>
    <div class="t-actions">
      <button class="t-big green" id="tAdd">➕<br>Add a Job</button>
      <button class="t-big" id="tJobs">📋<br>See My Jobs</button>
      <button class="t-big" id="tMoney">💰<br>Money Summary</button>
    </div>
    <div class="sheet-toolbar" style="margin-top:26px">
      <button class="bigbtn" id="tUpload">⬆️ Upload My Spreadsheet</button>
      <a class="bigbtn" href="${API_BASE}/api/tracker/export.xlsx" id="tDownload" download>⬇️ Download Spreadsheet</a>
      <button class="bigbtn" id="tTips">💡 Turn all tips back on</button>
    </div>
  </div>`;
  document.getElementById('tAdd').onclick = () => tGo('add');
  document.getElementById('tJobs').onclick = () => tGo('jobs');
  document.getElementById('tMoney').onclick = () => tGo('money');
  document.getElementById('tUpload').onclick = openTrackerImport;
  document.getElementById('tTips').onclick = () => {
    Object.keys(localStorage).filter(k => k.startsWith(coachPrefix())).forEach(k => localStorage.removeItem(k));
    alert('All tips are back on. They\'ll pop up again as you use each screen.');
    runCoach('home');
  };
  wireHelp();
  runCoach('home');
}

/* ---------- add-a-job wizard: one question per screen ---------- */
const TODAY = () => new Date().toISOString().slice(0, 10);
const WIZ = [
  { f: 'customer_name', q: "Who's the customer?", type: 'text', req: true, ph: 'Type their name' },
  { f: 'job_total', q: 'What did the job sell for?', type: 'money', hint: 'The full contract price. You can skip this and add it later.' },
  { f: 'date_signed', q: 'When did they sign?', type: 'date' },
  { f: 'date_completed', q: 'Is the job finished? If yes, when?', type: 'date', hint: 'Skip this if the job is still going.' },
  { f: 'roof_sq_size', q: 'Roof work? How many squares?', type: 'num' },
  { f: 'siding_feet', q: 'Siding? How many feet?', type: 'num' },
  { f: 'deck_feet', q: 'Deck? How many feet?', type: 'num' },
  { f: 'windows_quantity', q: 'Windows? How many?', type: 'num' },
  { f: 'interior_repair', q: 'Interior repair work? How much? ($)', type: 'money' },
  { f: 'bathroom', q: 'Bathroom work? How much? ($)', type: 'money' },
  { f: 'material_cost', q: 'What did materials cost you?', type: 'money' },
  { f: 'labor_cost', q: 'What did labor cost you?', type: 'money' },
  { f: 'dumpster_cost', q: 'What did the dumpster cost you?', type: 'money' },
  { f: 'notes', q: 'Anything to remember about this job?', type: 'text', ph: 'Like "gate code 4411" — or skip it' },
];
const MONEY_F = ['job_total', 'interior_repair', 'bathroom', 'material_cost', 'labor_cost', 'dumpster_cost'];

async function tWizard() {
  const a = { date_signed: TODAY() };
  let i = 0;
  const draw = () => {
    if (i >= WIZ.length) return review();
    const s = WIZ[i];
    $view.innerHTML = `<div class="tracker t-wiz">
      ${T_HELP('wizard')}
      <div class="steps">Question ${i + 1} of ${WIZ.length}</div>
      <h2 style="font-size:26px">${esc(s.q)}</h2>
      ${s.hint ? `<p class="t-hint">${esc(s.hint)}</p>` : ''}
      <input id="wIn" style="font-size:24px;padding:14px;width:100%;max-width:420px"
        type="${s.type === 'date' ? 'date' : 'text'}"
        ${s.type === 'money' || s.type === 'num' ? 'inputmode="decimal"' : ''}
        placeholder="${esc(s.ph || (s.type === 'money' ? '$0.00' : ''))}"
        value="${esc(a[s.f] ?? '')}">
      <div class="t-actions" style="margin-top:22px">
        ${i > 0 ? '<button class="bigbtn" id="wBack">← Back</button>' : ''}
        ${s.req ? '' : '<button class="bigbtn" id="wSkip">Skip this one →</button>'}
        <button class="btn" id="wNext" style="font-size:18px;padding:12px 26px">Next →</button>
      </div>
      <p><a class="link" id="wQuit">Never mind — quit without saving</a></p>
    </div>`;
    const input = document.getElementById('wIn');
    input.focus();
    const advance = (skip) => {
      const v = input.value.trim();
      if (!skip) {
        if (s.req && !v) { input.style.borderColor = '#e53935'; input.placeholder = 'I need this one!'; return; }
        if (v) a[s.f] = v;
      } else delete a[s.f];
      i++; draw();
    };
    document.getElementById('wNext').onclick = () => advance(false);
    input.onkeydown = (e) => { if (e.key === 'Enter') advance(false); };
    const sk = document.getElementById('wSkip');
    if (sk) sk.onclick = () => advance(true);
    const bk = document.getElementById('wBack');
    if (bk) bk.onclick = () => { i--; draw(); };
    document.getElementById('wQuit').onclick = () => tGo('home');
    if (i === 0) runCoach('wizard');
  };
  const review = () => {
    const cents = (f) => toCents(a[f] || 0);
    const costs = cents('material_cost') + cents('labor_cost') + cents('dumpster_cost');
    const net = cents('job_total') - costs;
    $view.innerHTML = `<div class="tracker">
      <h2 style="font-size:26px">Here's the job — look right?</h2>
      <div class="panel" style="font-size:18px;max-width:560px">
        <table>
          <tr><td>Customer</td><td><b>${esc(a.customer_name)}</b></td></tr>
          <tr><td>Sold for</td><td>${fmt$(cents('job_total'))}</td></tr>
          <tr><td>Signed</td><td>${esc(a.date_signed || '—')}</td></tr>
          <tr><td>Finished</td><td>${esc(a.date_completed || 'not yet')}</td></tr>
          ${a.roof_sq_size ? `<tr><td>Roof</td><td>${esc(a.roof_sq_size)} squares</td></tr>` : ''}
          ${a.siding_feet ? `<tr><td>Siding</td><td>${esc(a.siding_feet)} ft</td></tr>` : ''}
          ${a.deck_feet ? `<tr><td>Deck</td><td>${esc(a.deck_feet)} ft</td></tr>` : ''}
          ${a.windows_quantity ? `<tr><td>Windows</td><td>${esc(a.windows_quantity)}</td></tr>` : ''}
          ${a.interior_repair ? `<tr><td>Interior repair</td><td>${fmt$(cents('interior_repair'))}</td></tr>` : ''}
          ${a.bathroom ? `<tr><td>Bathroom</td><td>${fmt$(cents('bathroom'))}</td></tr>` : ''}
          <tr><td>Materials cost</td><td>${fmt$(cents('material_cost'))}</td></tr>
          <tr><td>Labor cost</td><td>${fmt$(cents('labor_cost'))}</td></tr>
          <tr><td>Dumpster cost</td><td>${fmt$(cents('dumpster_cost'))}</td></tr>
          <tr class="totals"><td>💵 Money you made on this job</td>
            <td class="${net < 0 ? 'neg' : 'pos'}"><b>${fmt$(net)}</b></td></tr>
        </table>
        <p><small>I did that math for you: what it sold for, minus materials, labor and dumpster.</small></p>
      </div>
      <div class="t-actions">
        <button class="bigbtn" id="rBack">← Go back and change something</button>
        <button class="btn" id="rSave" style="font-size:20px;padding:14px 30px">✓ Save this job</button>
      </div>
    </div>`;
    document.getElementById('rBack').onclick = () => { i = 0; draw(); };
    document.getElementById('rSave').onclick = async (e) => {
      e.target.disabled = true;
      const body = { customer_name: a.customer_name, notes: a.notes || '',
        date_signed: a.date_signed || '', date_completed: a.date_completed || '',
        windows_quantity: Number(a.windows_quantity) || 0, deck_feet: Number(a.deck_feet) || 0,
        siding_feet: Number(a.siding_feet) || 0, roof_sq_size: Number(a.roof_sq_size) || 0 };
      for (const f of MONEY_F) body[f + '_cents'] = toCents(a[f] || 0);
      await api.send('POST', '/api/tracker/jobs', body);
      $view.innerHTML = `<div class="tracker" style="text-align:center;padding-top:60px">
        <div style="font-size:60px">🎉</div><h2 style="font-size:28px">Saved!</h2>
        <div class="t-actions" style="justify-content:center">
          <button class="t-big green" id="dAgain">➕<br>Add another job</button>
          <button class="t-big" id="dJobs">📋<br>See My Jobs</button>
        </div></div>`;
      document.getElementById('dAgain').onclick = () => tGo('add');
      document.getElementById('dJobs').onclick = () => tGo('jobs');
    };
  };
  draw();
}

/* ---------- job list + one-screen edit with live math ---------- */
async function tJobs(editId) {
  const list = await api.get('/api/tracker/jobs');
  if (editId) return tEdit(list.find(j => j.id === +editId));
  $view.innerHTML = `<div class="tracker">
    ${T_HELP('jobs')}
    <h2 style="font-size:26px">My Jobs (${list.length})</h2>
    <div class="t-actions" style="margin-bottom:14px">
      <button class="t-big green" id="tAdd2" style="min-height:70px;font-size:18px">➕ Add a Job</button>
      <button class="bigbtn" id="tHome2">← Back</button>
    </div>
    <div class="panel">
    <table id="tJobTable" style="font-size:17px">
      <tr><th>Customer</th><th>Signed</th><th class="num">Sold for</th><th class="num">Money made</th><th></th></tr>
      ${list.map(j => `<tr>
        <td><b>${esc(j.customer_name)}</b></td>
        <td>${esc(j.date_signed || '—')}${j.date_completed ? ' ✓' : ''}</td>
        <td class="num">${fmt$(j.job_total_cents)}</td>
        <td class="num ${j.net_profit_cents < 0 ? 'neg' : 'pos'}"><b>${fmt$(j.net_profit_cents)}</b></td>
        <td><button class="bigbtn" data-edit="${j.id}" style="padding:8px 14px">Open</button></td></tr>`).join('')
      || '<tr><td colspan="5">No jobs yet — tap "Add a Job" to put in your first one!</td></tr>'}
    </table></div></div>`;
  document.getElementById('tAdd2').onclick = () => tGo('add');
  document.getElementById('tHome2').onclick = () => tGo('home');
  $view.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => tJobs(b.dataset.edit));
  wireHelp();
  runCoach('jobs');
}

function tEdit(j) {
  if (!j) return tGo('jobs');
  const $in = (f, v, type = 'text') => `<input name="${f}" value="${esc(v)}" type="${type}"
    style="font-size:18px;padding:10px" ${type === 'text' ? '' : 'inputmode="decimal"'}>`;
  const d = (c) => (c / 100).toFixed(2);
  $view.innerHTML = `<div class="tracker">
    <h2 style="font-size:26px">${esc(j.customer_name)}</h2>
    <form id="eForm" class="panel" style="max-width:620px;font-size:17px"><table>
      <tr><td>Customer name</td><td>${$in('customer_name', j.customer_name)}</td></tr>
      <tr><td>Date signed</td><td>${$in('date_signed', j.date_signed, 'date')}</td></tr>
      <tr><td>Date finished</td><td>${$in('date_completed', j.date_completed, 'date')}</td></tr>
      <tr><td>Sold for ($)</td><td>${$in('job_total', d(j.job_total_cents))}</td></tr>
      <tr><td>Interior repair ($)</td><td>${$in('interior_repair', d(j.interior_repair_cents))}</td></tr>
      <tr><td>Bathroom ($)</td><td>${$in('bathroom', d(j.bathroom_cents))}</td></tr>
      <tr><td>Windows (how many)</td><td>${$in('windows_quantity', j.windows_quantity)}</td></tr>
      <tr><td>Deck (feet)</td><td>${$in('deck_feet', j.deck_feet)}</td></tr>
      <tr><td>Siding (feet)</td><td>${$in('siding_feet', j.siding_feet)}</td></tr>
      <tr><td>Roof (squares)</td><td>${$in('roof_sq_size', j.roof_sq_size)}</td></tr>
      <tr><td>Materials cost ($)</td><td>${$in('material_cost', d(j.material_cost_cents))}</td></tr>
      <tr><td>Labor cost ($)</td><td>${$in('labor_cost', d(j.labor_cost_cents))}</td></tr>
      <tr><td>Dumpster cost ($)</td><td>${$in('dumpster_cost', d(j.dumpster_cost_cents))}</td></tr>
      <tr><td>Notes</td><td><textarea name="notes" style="font-size:17px">${esc(j.notes)}</textarea></td></tr>
      <tr class="totals"><td>💵 Money you made</td><td id="liveNet" style="font-size:20px"></td></tr>
    </table>
    <div class="t-actions">
      <button type="button" class="bigbtn" id="eBack">← Back to my jobs</button>
      <button class="btn" style="font-size:18px;padding:12px 26px">✓ Save changes</button>
      <button type="button" class="bigbtn" id="eDel" style="color:#b3261e">🗑 Delete this job</button>
    </div></form></div>`;
  const form = document.getElementById('eForm');
  const live = () => {
    const v = (f) => toCents(new FormData(form).get(f) || 0);
    const net = v('job_total') - v('material_cost') - v('labor_cost') - v('dumpster_cost');
    const el = document.getElementById('liveNet');
    el.innerHTML = `<b class="${net < 0 ? 'neg' : 'pos'}">${fmt$(net)}</b> <small>(I do this math live as you type)</small>`;
  };
  form.oninput = live; live();
  form.onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(form));
    const body = { customer_name: f.customer_name, notes: f.notes,
      date_signed: f.date_signed, date_completed: f.date_completed,
      windows_quantity: Number(f.windows_quantity) || 0, deck_feet: Number(f.deck_feet) || 0,
      siding_feet: Number(f.siding_feet) || 0, roof_sq_size: Number(f.roof_sq_size) || 0 };
    for (const m of MONEY_F) body[m + '_cents'] = toCents(f[m] || 0);
    await api.send('PUT', '/api/tracker/jobs/' + j.id, body);
    tGo('jobs');
  };
  document.getElementById('eBack').onclick = () => tGo('jobs');
  document.getElementById('eDel').onclick = async () => {
    if (!confirm(`Delete ${j.customer_name}? This can't be undone.`)) return;
    await api.send('DELETE', '/api/tracker/jobs/' + j.id);
    tGo('jobs');
  };
}

/* ---------- money summary: 3 numbers + one bar chart ---------- */
async function tMoney() {
  const s = await api.get('/api/tracker/summary');
  const maxP = Math.max(1, ...s.months.map(m => Math.abs(m.profit_cents)));
  const monthName = (k) => new Date(k + '-15').toLocaleString('en-US', { month: 'short' });
  $view.innerHTML = `<div class="tracker">
    ${T_HELP('money')}
    <h2 style="font-size:26px">Money Summary</h2>
    <div class="stats" id="mStats">
      <div class="stat"><div class="icon">№</div><div class="label">Jobs this month</div>
        <div class="value" style="font-size:32px">${s.jobs_this_month}</div><div class="foot">signed in ${s.month}</div></div>
      <div class="stat"><div class="icon">$</div><div class="label">Money coming in</div>
        <div class="value" style="font-size:32px">${fmt$(s.revenue_this_month_cents)}</div><div class="foot">this month's jobs sold for</div></div>
      <div class="stat ${s.profit_this_month_cents < 0 ? 'red' : ''}"><div class="icon">💵</div><div class="label">Money you made</div>
        <div class="value" style="font-size:32px">${fmt$(s.profit_this_month_cents)}</div><div class="foot">after materials, labor, dumpsters</div></div>
    </div>
    <div class="panel" id="mChart"><h3 style="font-size:18px">Money made, last 6 months</h3>
      ${s.months.map(m => `<div class="hbar-row" style="font-size:16px"><span>${monthName(m.month)}</span>
        <div class="hbar"><div style="width:${Math.abs(m.profit_cents) / maxP * 100}%;
          ${m.profit_cents < 0 ? 'background:#c0463f' : ''}"></div></div>
        <b>${fmt$(m.profit_cents)}</b></div>`).join('')}
    </div>
    <div class="t-actions"><button class="bigbtn" id="mBack">← Back</button></div>
  </div>`;
  document.getElementById('mBack').onclick = () => tGo('home');
  wireHelp();
  runCoach('money');
}

/* ---------- upload my spreadsheet ---------- */
function openTrackerImport() {
  const back = openModal(`
    <h2 style="font-size:24px">⬆️ Upload My Spreadsheet</h2>
    <p style="font-size:16px">Pick the Excel file you already keep your jobs in — the one with
    Date Signed, Customer Name, Job Total and so on. I'll read it just the way it is.
    Dollar signs, blank rows, any date style — all fine.</p>
    <div class="dropzone" id="tdz">📄 Click here to pick the file<br><small>Excel (.xlsx) or CSV — or drag it into this box</small></div>
    <input type="file" id="tFile" accept=".xlsx,.xls,.csv" style="display:none">
    <div id="tMsg"></div>`);
  const body = back.querySelector('.modal');
  const dz = body.querySelector('#tdz'), input = body.querySelector('#tFile');
  dz.onclick = () => input.click();
  dz.ondragover = (e) => { e.preventDefault(); dz.classList.add('drag'); };
  dz.ondragleave = () => dz.classList.remove('drag');
  dz.ondrop = (e) => { e.preventDefault(); dz.classList.remove('drag'); handle(e.dataTransfer.files[0]); };
  input.onchange = () => handle(input.files[0]);
  let theFile = null;
  async function handle(file) {
    if (!file) return;
    theFile = file;
    body.querySelector('#tMsg').innerHTML = '<p style="font-size:16px">Reading your spreadsheet…</p>';
    const fd = new FormData();
    fd.append('dry_run', 'true');
    fd.append('file', file);
    const r = await api.form('/api/tracker/import', fd);
    const p = await r.json();
    if (!r.ok) { body.querySelector('#tMsg').innerHTML = `<p class="flag" style="font-size:16px">${esc(p.error)}</p>`; return; }
    body.querySelector('#tMsg').innerHTML = `
      <h3 style="font-size:20px">Here's what I found: <b>${p.count} job${p.count === 1 ? '' : 's'}</b>. Does this look right?</h3>
      ${p.headers_ignored.length ? `<p><small>Columns I didn't recognize (they'll be left out): ${p.headers_ignored.map(esc).join(', ')}</small></p>` : ''}
      <div class="import-preview"><table>
        <tr><th>Customer</th><th>Signed</th><th class="num">Sold for</th><th class="num">Money made</th></tr>
        ${p.jobs.slice(0, 15).map(j => `<tr><td>${esc(j.customer_name)}</td><td>${esc(j.date_signed)}</td>
          <td class="num">${fmt$(j.job_total_cents)}</td><td class="num">${fmt$(j.net_profit_cents)}</td></tr>`).join('')}
      </table></div>
      ${p.count > 15 ? `<p><small>…and ${p.count - 15} more.</small></p>` : ''}
      <div class="actions">
        <button class="btn" id="tConfirm" style="font-size:18px;padding:12px 28px;background:linear-gradient(135deg,#4caf50,#2e7d32);color:#fff">
          ✓ Yes — bring them all in</button>
      </div>`;
    body.querySelector('#tConfirm').onclick = async (e) => {
      e.target.disabled = true; e.target.textContent = 'Working…';
      const fd2 = new FormData();
      fd2.append('file', theFile);
      const res = await (await api.form('/api/tracker/import', fd2)).json();
      body.querySelector('#tMsg').innerHTML = `
        <div class="big-emoji">🎉</div><h3 style="font-size:22px">Done! ${res.created} added${res.updated ? `, ${res.updated} updated` : ''}.</h3>
        <p style="font-size:16px">Your jobs are in. Tap "See My Jobs" to look at them.</p>
        <div class="actions"><button class="btn" id="tDone2">Show my jobs</button></div>`;
      body.querySelector('#tDone2').onclick = () => { back.close(); tGo('jobs'); };
    };
  }
}

/* ---------- coach bubbles: contextual, persistent dismissal per user ---------- */
const COACH = {
  home: [
    ['home-add', '#tAdd', 'This green button adds a new job. Tap it to try — I ask one easy question at a time.'],
    ['home-jobs', '#tJobs', 'This shows every job you\'ve put in, with the money you made on each.'],
    ['home-money', '#tMoney', 'This shows your month: how many jobs, money in, money made.'],
    ['home-upload', '#tUpload', 'Got your old spreadsheet? Tap here once and I\'ll bring every job in for you.'],
    ['home-download', '#tDownload', 'This gives you your whole job list back as a normal Excel file — same columns you\'re used to.'],
    ['home-ellianna', '#ellBubble', 'Stuck? Tap "Ask Ellianna" any time, on any screen, and just ask in plain English.'],
  ],
  jobs: [
    ['jobs-open', '[data-edit]', 'Tap "Open" on any job to see or change its numbers. The profit math updates itself.'],
    ['jobs-add', '#tAdd2', 'Add your next job from here too.'],
  ],
  money: [
    ['money-stats', '#mStats', '"Money you made" is after materials, labor and dumpsters come out. No calculator needed.'],
    ['money-chart', '#mChart', 'Each bar is a month. Longer bar = better month.'],
  ],
  wizard: [
    ['wiz-skip', '#wSkip', 'Don\'t know an answer yet? Tap "Skip" — you can fill it in later.'],
  ],
};
const coachPrefix = () => `coach:${me ? me.id : 'x'}:`;

function runCoach(screen, force) {
  document.querySelectorAll('.coach').forEach(el => el.remove());
  const items = (COACH[screen] || []).filter(([id, sel]) =>
    (force || !localStorage.getItem(coachPrefix() + id)) && document.querySelector(sel));
  if (!items.length) return;
  let i = 0;
  const show = () => {
    document.querySelectorAll('.coach').forEach(el => el.remove());
    if (i >= items.length) return;
    const [id, sel, text] = items[i];
    const target = document.querySelector(sel);
    if (!target) { i++; return show(); }
    target.scrollIntoView({ block: 'center', behavior: 'instant' });
    const r = target.getBoundingClientRect();
    const el = document.createElement('div');
    el.className = 'coach';
    el.innerHTML = `<div class="coach-arrow"></div><p>${esc(text)}</p>
      <div class="coach-actions">
        <button class="chip" data-c="later">OK (${i + 1}/${items.length})</button>
        <button class="chip" data-c="stop">Got it, stop showing me this</button>
      </div>`;
    document.body.appendChild(el);
    const top = r.bottom + 10;
    el.style.top = Math.min(top, innerHeight - el.offsetHeight - 12) + 'px';
    el.style.left = Math.max(12, Math.min(r.left, innerWidth - el.offsetWidth - 12)) + 'px';
    el.querySelector('[data-c=later]').onclick = () => { i++; show(); };
    el.querySelector('[data-c=stop]').onclick = () => {
      localStorage.setItem(coachPrefix() + id, '1'); i++; show();
    };
  };
  show();
}
