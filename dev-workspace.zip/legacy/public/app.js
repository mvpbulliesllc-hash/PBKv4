/* Paragon CRM + Job P&L front end. Plain JS, no build step.
   Money is cents on the wire; $ formatting happens only here in the view. */
const $view = document.getElementById('view');
// The API runs on the same host as the UI (Vercel serverless locally at /api).
const API_BASE = '';
async function toJson(r) {
  if (!r.ok || !(r.headers.get('content-type') || '').includes('json')) {
    throw new Error(`API request failed: ${r.status} ${r.url}`);
  }
  return r.json();
}
const api = {
  get: (u) => fetch(API_BASE + u, { credentials: 'include' }).then(toJson),
  send: (m, u, body) => fetch(API_BASE + u, { method: m, credentials: 'include',
    headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(toJson),
  form: (u, formData) => fetch(API_BASE + u, { method: 'POST', credentials: 'include', body: formData }),
};
const fmt$ = (c) => (c / 100).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
const toCents = (v) => Math.round(parseFloat(v || '0') * 100);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

const STATUSES = ['Lead', 'Contacted', 'Inspection', 'Proposal', 'Signed', 'In Progress', 'Completed', 'Paid'];
let currentView = 'dashboard';
let me = null;

const NAV = [
  ['tracker', 'Job Tracker', ['admin', 'office']],
  ['dashboard', 'Command Center', ['admin', 'office']],
  ['leads', 'Leads', ['admin', 'office']],
  ['storms', 'Storm Watch', ['admin', 'office']],
  ['crm', 'CRM', ['admin', 'office']],
  ['ellianna', 'Ellianna ✨', ['admin', 'office']],
  ['pipeline', 'Pipeline', ['admin', 'office']],
  ['pnl', 'P&L', ['admin']],
  ['expenses', 'Expenses', ['admin']],
  ['reference', 'Reference', ['admin', 'office']],
  ['onboarding', 'Onboarding', ['admin', 'office']],
  ['videos', 'Videos 🎥', ['admin', 'office']],
  ['sitescrape', 'Site Scrape', ['admin', 'office']],
  ['devtools', 'Dev Tools', ['admin']],
  ['team', 'Team', ['admin']],
  ['myjobs', 'My Jobs', ['contractor', 'client']],
];

function buildNav() {
  const tabs = NAV.filter(([, , roles]) => roles.includes(me.role));
  document.getElementById('tabs').innerHTML = tabs.map(([v, label], i) =>
    `<button data-view="${v}" class="${i === 0 ? 'active' : ''}">${label}</button>`).join('');
  currentView = tabs[0][0];
  document.getElementById('crumb').textContent = tabs[0][1];
  document.getElementById('whoami').textContent = `${me.name || me.email} · ${me.role}`;
  document.getElementById('logoutBtn').style.display = '';
}

document.getElementById('tabs').addEventListener('click', (e) => {
  if (!e.target.dataset.view) return;
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('active', b === e.target));
  currentView = e.target.dataset.view;
  document.getElementById('crumb').textContent = e.target.textContent.trim();
  render();
});
document.getElementById('logoutBtn').onclick = async () => {
  await api.send('POST', '/api/logout', {});
  location.reload();
};

/* ---------- login ---------- */
function showLogin(msg) {
  document.querySelector('.sidebar').style.display = 'none';
  document.querySelector('.topbar').style.display = 'none';
  $view.innerHTML = `
    <div class="login-bg"><div class="login-card">
      <img src="logo.png" alt="Paragon Exteriors">
      <h2>Control Center</h2>
      ${msg ? `<p class="flag">${esc(msg)}</p>` : ''}
      <form id="pinForm">
        <input name="pin" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="4-digit PIN"
          style="font-size:26px;text-align:center;letter-spacing:.4em" autocomplete="one-time-code">
        <button class="btn">Login with my PIN</button>
      </form>
      <p><small>— or with email &amp; password —</small></p>
      <form id="loginForm">
        <input name="email" type="email" placeholder="Email" required autocomplete="username">
        <input name="password" type="password" placeholder="Password" required autocomplete="current-password">
        <button class="btn">Login</button>
      </form>
      <p><small>Paragon Exteriors LLC · NJ HIC #13VH13814500</small></p>
    </div></div>`;
  document.getElementById('pinForm').onsubmit = async (e) => {
    e.preventDefault();
    const pin = new FormData(e.target).get('pin');
    const r = await fetch(API_BASE + '/api/login-pin', {
      method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin }),
    });
    if (!r.ok) return showLogin("That PIN doesn't match — try again, or use email & password");
    location.reload();
  };
  document.getElementById('loginForm').onsubmit = async (e) => {
    e.preventDefault();
    const r = await fetch(API_BASE + '/api/login', {
      method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.fromEntries(new FormData(e.target))),
    });
    if (!r.ok) return showLogin('Invalid email or password');
    // First password login: offer a 4-digit PIN so next time is PIN-only.
    try {
      const u = await r.json();
      if (!u.has_pin) {
        const pin = prompt('Set a 4-digit PIN for quick login on this device next time (Cancel to skip):');
        if (pin && /^\d{4,6}$/.test(pin.trim())) {
          await fetch(API_BASE + '/api/me/pin', {
            method: 'POST', credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pin: pin.trim() }),
          });
        }
      }
    } catch { /* PIN offer is a nicety — never block login over it */ }
    location.reload();
  };
}

async function boot() {
  // /api/session answers 200 with {user:null} pre-login — no 401 console
  // noise on every fresh visit.
  try {
    me = (await api.get('/api/session')).user;
  } catch {
    return showLogin();
  }
  if (!me) return showLogin();
  document.querySelector('.sidebar').style.display = '';
  document.querySelector('.topbar').style.display = '';
  buildNav();
  if (['admin', 'office'].includes(me.role)) mountAgentDock();
  render();
}

/* ---------- Agent dock — the middle pane of the three-pane workspace ----------
   Left rail: manual tools. This dock (resizable 20–35% of the viewport):
   the agent — chat, progress, uploads for import/data entry. Right: the
   content, edge to edge. Ellianna rides here on every tab; on Dev Tools the
   dock hands over to Dev Dechado. */
let dockAgent = '';
function mountAgentDock() {
  const dock = document.getElementById('agentDock');
  const reopen = document.getElementById('dockReopen');
  const grip = document.getElementById('dockGrip');
  const saved = Number(localStorage.getItem('dockW') || 0);
  const clampW = (w) => Math.max(innerWidth * 0.20, Math.min(innerWidth * 0.35, w));
  dock.style.width = (saved ? clampW(saved) : Math.round(innerWidth * 0.24)) + 'px';
  dock.style.display = localStorage.getItem('dockOpen') === 'no' ? 'none' : '';
  reopen.style.display = dock.style.display === 'none' ? '' : 'none';

  document.getElementById('dockCollapse').onclick = () => {
    dock.style.display = 'none';
    reopen.style.display = '';
    localStorage.setItem('dockOpen', 'no');
  };
  reopen.onclick = () => {
    dock.style.display = '';
    reopen.style.display = 'none';
    localStorage.setItem('dockOpen', 'yes');
    syncAgentDock(true);
  };
  // Drag-to-resize, clamped to the spec's 20%–35% band.
  grip.onmousedown = (e) => {
    e.preventDefault();
    const startX = e.clientX, startW = dock.getBoundingClientRect().width;
    const move = (ev) => {
      const w = clampW(startW + (ev.clientX - startX));
      dock.style.width = w + 'px';
      localStorage.setItem('dockW', String(Math.round(w)));
    };
    const up = () => { removeEventListener('mousemove', move); removeEventListener('mouseup', up); };
    addEventListener('mousemove', move);
    addEventListener('mouseup', up);
  };
  syncAgentDock(true);
}

// Re-render the dock's agent when the tab changes: Dev owns Dev Tools, his
// sister owns everything else.
function syncAgentDock(force) {
  const dock = document.getElementById('agentDock');
  if (!dock || dock.style.display === 'none') return;
  const want = currentView === 'devtools' && me.role === 'admin' ? 'dev' : 'ellianna';
  if (!force && want === dockAgent) return;
  dockAgent = want;
  const body = document.getElementById('dockBody');
  document.getElementById('dockTitle').textContent = want === 'dev' ? '🛠️ Dev Dechado' : 'Ellianna ✨';
  dock.classList.toggle('dock-dev', want === 'dev');
  if (want === 'dev') renderDevChat(body);
  else renderElliannaChat(body);
}

/* Floating "Ask Ellianna" bubble — the escape hatch on every screen. */
// Dev Dechado's chat — rendered into the agent dock on the Dev Tools tab.
function renderDevChat(root) {
  root.innerHTML = `
    <div class="chat-wrap dev-chat">
      <div class="chat-log dev-log" id="devLog"></div>
      <div class="chat-input">
        <textarea id="devText" placeholder="System state, integrations, architecture — ask Dev"></textarea>
        <button class="gbtn default" id="devSend">Send</button>
      </div>
    </div>`;
  const devLog = root.querySelector('#devLog');
  const devText = root.querySelector('#devText');
  const drawDev = () => {
    devLog.innerHTML = devLogState.length ? devLogState.map(m =>
      `<div class="msg ${m.role === 'user' ? 'user' : 'ellianna dev-msg'}">${esc(m.content)}</div>`).join('')
      : '<div class="msg ellianna dev-msg">Dev. What\'s the problem.</div>';
    devLog.scrollTop = devLog.scrollHeight;
  };
  const devSend = async () => {
    const content = devText.value.trim();
    if (!content) return;
    devText.value = '';
    devLogState.push({ role: 'user', content });
    drawDev();
    devLog.insertAdjacentHTML('beforeend', '<div class="msg ellianna dev-msg thinking">…</div>');
    try {
      const data = await api.send('POST', '/api/dev-agent',
        { messages: JSON.stringify(devLogState) });
      devLogState.push({ role: 'assistant', content: data.reply || '(no answer)' });
    } catch (err) {
      devLogState.push({ role: 'assistant', content: '😕 ' + err.message });
    }
    drawDev();
  };
  root.querySelector('#devSend').onclick = devSend;
  devText.onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); devSend(); } };
  drawDev();
}

/* ---------- My Jobs (contractor & client portal) ---------- */
async function myjobs() {
  const list = await api.get('/api/jobs');
  const isClient = me.role === 'client';
  $view.innerHTML = `
    ${list.length ? '' : '<div class="panel"><p>No jobs assigned to you yet.</p></div>'}
    ${list.map(j => `<div class="panel">
      <h3>${esc(j.customer_name)} <span class="pill">${j.status}</span></h3>
      <table>
        <tr><td>Address</td><td>${esc(j.address)}</td></tr>
        <tr><td>Scope</td><td>${esc(j.scope_of_work)}</td></tr>
        <tr><td>Scheduled</td><td>${j.schedule_date || 'TBD'}</td></tr>
        <tr><td>Completed</td><td>${j.completed_date || '—'}</td></tr>
        ${isClient ? `
        <tr><td>Contract total</td><td class="num">${fmt$(j.job_total_cents)}</td></tr>
        <tr><td>Paid so far</td><td class="num">${fmt$(j.payments_cents)}</td></tr>
        <tr class="totals"><td>Balance</td><td class="num">${fmt$(j.balance_owed_cents)}</td></tr>` : ''}
      </table></div>`).join('')}`;
}

async function render(arg) {
  if (me && ['admin', 'office'].includes(me.role)) syncAgentDock();
  try {
    await ({ dashboard, leads, crm: jobs, jobs, pipeline, pnl, expenses, reference,
      onboarding, team, devtools, myjobs, sitescrape, storms, ellianna, tracker, videos }[currentView])(arg);
  } catch (err) {
    if (/ 401 /.test(err.message)) return showLogin();
    $view.innerHTML = `<div class="panel"><h2>Can't reach the server</h2>
      <p>The app's API isn't responding, so nothing can load. If you're on a
      serverless host (like Vercel) the backend isn't running there — use the
      real deployment URL. Otherwise the server may be starting up; wait a few
      seconds and <a class="link" onclick="location.reload()">reload</a>.</p>
      <p><small>${esc(err.message)}</small></p></div>`;
  }
}

/* ---------- Storm Watch (NWS roof-damage alerts vs the lead book) ---------- */
async function storms() {
  const [data, jobsList] = await Promise.all([api.get('/api/storms'), api.get('/api/jobs')]);
  const leadZips = {};
  jobsList.forEach(j => { if (j.zip) leadZips[j.zip] = (leadZips[j.zip] || 0) + 1; });
  $view.innerHTML = `
    <div class="panel"><h3>Active roof-damage alerts — South & Central Jersey</h3>
      <p><small>Live from the National Weather Service. Checked ${new Date(data.checked).toLocaleTimeString()}
        · auto-refreshes every 15 min · <a class="link" id="stormRefresh">check now</a></small></p>
      ${data.alerts.length ? data.alerts.map(a => `
        <div style="border-left:4px solid ${a.severity === 'Extreme' ? '#b3261e' : a.severity === 'Severe' ? '#e07020' : '#d4af37'};
             padding:10px 14px; margin:10px 0; background:#fafbfd; border-radius:0 8px 8px 0">
          <b>${esc(a.event)}</b> <span class="pill">${esc(a.severity)}</span>
          <br><small>${esc(a.headline || a.area)}</small>
          <br><small>Counties: <b>${a.counties.join(', ')}</b>
          ${a.ends ? ` · until ${new Date(a.ends).toLocaleString()}` : ''}</small>
          <br>${a.affected_leads
            ? `<b class="flag">${a.affected_leads} leads in the strike zone</b>
               <button class="btn small" data-zips="${a.zips.join(',')}">Open outreach queue</button>`
            : '<small>No CRM leads in the affected zips yet.</small>'}
        </div>`).join('')
      : `<p class="pos"><b>All clear.</b> No active roof-damage weather alerts for the market counties right now.
         When one fires, it shows here, the affected leads are queued automatically, and any
         <b>storm.alert</b> webhook (Dev Tools) is notified so outbound sequences can launch.</p>`}
    </div>
    <div class="panel"><h3>Lead coverage by zip</h3>
      <table><tr><th>Zip</th><th class="num">Leads ready</th></tr>
        ${Object.entries(leadZips).sort((a, b) => b[1] - a[1]).map(([z, n]) =>
          `<tr><td>${esc(z)}</td><td class="num">${n}</td></tr>`).join('')}</table>
      <p><small>When a storm hits a zip with no coverage, pull that zip's list through the
      Tracerfy/Clay pipeline and import it — the importer files everything by zip
      automatically. More coverage = more leads queued per storm.</small></p></div>`;
  document.getElementById('stormRefresh').onclick = async () => {
    await api.send('POST', '/api/storms/refresh', {}); storms();
  };
  $view.querySelectorAll('button[data-zips]').forEach(b => b.onclick = () => {
    currentView = 'leads';
    document.querySelectorAll('nav button').forEach(x => x.classList.toggle('active', x.dataset.view === 'leads'));
    document.getElementById('crumb').textContent = 'Leads';
    leads(b.dataset.zips.split(','));
  });
}

/* ---------- Site Scrape (embedded external tool) ---------- */
const SITESCRAPE_URL = 'https://sitescrape.vercel.app/';
async function sitescrape() {
  // SSO: hand the iframe a 5-minute token; sitescrape swaps it for its own
  // session against this CRM — no second login inside the back office.
  let src = SITESCRAPE_URL;
  try {
    const t = await api.get('/api/sso-token');
    src += '?paragon_token=' + encodeURIComponent(t.token);
  } catch { /* falls back to sitescrape's own login card */ }
  $view.innerHTML = `
    <div class="ss-head">
      <a class="link" href="${SITESCRAPE_URL}" target="_blank" rel="noopener">Open full screen ↗</a>
    </div>
    <div class="ss-crop">
      <iframe id="ssFrame" src="${src}" title="Site Scrape"></iframe>
    </div>`;
}

/* ---------- Dashboard (control center) ---------- */
async function dashboard() {
  const month = new Date().toISOString().slice(0, 7);
  const [jobsList, exp, leadCounts, calls] = await Promise.all([
    api.get('/api/jobs'), api.get('/api/expenses?month=' + month),
    api.get('/api/leads/counts').catch(() => null),
    api.get('/api/calls').catch(() => [])]);
  const active = jobsList.filter(j => !['Completed', 'Paid'].includes(j.status));
  const owed = jobsList.reduce((a, j) => a + Math.max(0, j.balance_owed_cents), 0);
  const booked = jobsList.filter(j => j.signed_contract).reduce((a, j) => a + j.job_total_cents, 0);
  const profit = jobsList.filter(j => j.completed_date).reduce((a, j) => a + j.net_profit_cents, 0);
  const monthSpend = exp.filter(e => e.qb_type === 'expense').reduce((a, e) => a + e.amount_cents, 0);

  const byStatus = STATUSES.map(s => ({ s, n: jobsList.filter(j => j.status === s).length }));
  const maxN = Math.max(1, ...byStatus.map(r => r.n));
  const byCat = {};
  exp.filter(e => e.qb_type === 'expense').forEach(e => { byCat[e.category] = (byCat[e.category] || 0) + e.amount_cents; });
  const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 8);
  const maxC = Math.max(1, ...cats.map(c => c[1]));
  const recent = jobsList.slice(0, 8);

  $view.innerHTML = `
    <div class="stats">
      <div class="stat"><div class="icon">№</div><div class="label">Active Jobs</div>
        <div class="value">${active.length}</div><div class="foot">lead through in-progress</div></div>
      <div class="stat"><div class="icon">$</div><div class="label">Booked Revenue</div>
        <div class="value">${fmt$(booked)}</div><div class="foot">signed contracts</div></div>
      <div class="stat"><div class="icon">$</div><div class="label">Balance Owed</div>
        <div class="value">${fmt$(owed)}</div><div class="foot">across all jobs</div></div>
      <div class="stat ${profit < 0 ? 'red' : ''}"><div class="icon">%</div><div class="label">Net Profit</div>
        <div class="value">${fmt$(profit)}</div><div class="foot">completed jobs</div></div>
      <div class="stat"><div class="icon">$</div><div class="label">Spend — ${month}</div>
        <div class="value">${fmt$(monthSpend)}</div><div class="foot">this month's expenses</div></div>
    </div>
    ${leadCounts && leadCounts.total ? `<div class="stats">
      <div class="stat"><div class="icon">№</div><div class="label">Lead Book</div>
        <div class="value">${leadCounts.total.toLocaleString()}</div><div class="foot">properties on file</div></div>
      <div class="stat"><div class="icon">№</div><div class="label">Ready to Work</div>
        <div class="value">${leadCounts.stages.enriched.toLocaleString()}</div><div class="foot">enriched, untouched</div></div>
      <div class="stat"><div class="icon">№</div><div class="label">In Outreach</div>
        <div class="value">${(leadCounts.stages.emailed + leadCounts.stages.called + leadCounts.stages.contacted).toLocaleString()}</div>
        <div class="foot">emailed · called · contacted</div></div>
      <div class="stat"><div class="icon">№</div><div class="label">Appointments +</div>
        <div class="value">${(leadCounts.stages.appointment + leadCounts.stages.estimate).toLocaleString()}</div>
        <div class="foot">appointment · estimate</div></div>
      <div class="stat"><div class="icon">№</div><div class="label">Installed</div>
        <div class="value">${leadCounts.stages.installed.toLocaleString()}</div><div class="foot">pipeline wins</div></div>
    </div>` : ''}
    <div class="grid2">
      <div class="panel"><h3>Pipeline by stage</h3>
        ${byStatus.map(r => `<div class="hbar-row"><span>${r.s}</span>
          <div class="hbar"><div style="width:${r.n / maxN * 100}%"></div></div><b>${r.n}</b></div>`).join('')}
      </div>
      <div class="panel"><h3>Expenses this month by category</h3>
        ${cats.length ? cats.map(([c, s]) => `<div class="hbar-row"><span>${esc(c)}</span>
          <div class="hbar"><div style="width:${s / maxC * 100}%"></div></div><b>${fmt$(s)}</b></div>`).join('')
          : '<p><small>No expenses recorded this month.</small></p>'}
      </div>
    </div>
    ${calls.length ? `<div class="panel"><h3>📞 Ellianna's phone line — latest calls</h3>
      <table><tr><th>When</th><th>Caller</th><th>What</th><th class="num">Length</th></tr>
      ${calls.slice(0, 8).map(c => `<tr><td><small>${esc(c.created_at)}</small></td>
        <td>${esc(c.caller_number || 'unknown')}</td>
        <td><span class="pill">${esc(c.event_name === 'chat_ended' ? 'call ended' : c.event_name === 'chat_started' ? 'call started' : c.event_name)}</span>
          ${c.end_reason ? `<small>${esc(c.end_reason)}</small>` : ''}</td>
        <td class="num">${c.duration_seconds != null ? Math.round(c.duration_seconds / 60) + 'm ' + (c.duration_seconds % 60) + 's' : ''}</td></tr>`).join('')}
      </table></div>` : ''}
    <div class="panel"><h3>Latest leads</h3>
      <table><tr><th>Customer</th><th>Status</th><th>Address</th><th>Notes</th></tr>
      ${recent.map(j => `<tr><td><a class="link" data-id="${j.id}">${esc(j.customer_name)}</a></td>
        <td><span class="pill">${j.status}</span></td><td>${esc(j.address)}</td>
        <td><small>${esc(j.notes)}</small></td></tr>`).join('')}</table></div>`;
  $view.querySelectorAll('a.link').forEach(a => a.onclick = () => openJob(a.dataset.id));
}

/* ---------- Leads (staged pipeline: scraped → … → installed) ---------- */
const LEAD_STAGES = ['scraped', 'enriched', 'emailed', 'called', 'contacted',
  'appointment', 'estimate', 'installed'];
const LEAD_SIDE = ['dead', 'dnc'];
const STAGE_LABEL = { scraped: 'Scraped', enriched: 'Enriched', emailed: 'Emailed',
  called: 'Called', contacted: 'Contacted', appointment: 'Appointment',
  estimate: 'Estimate', installed: 'Installed', dead: 'Dead', dnc: 'DNC' };
const dash = (v) => (v === null || v === undefined || v === '') ? '—' : esc(v);
const fmtVal = (v) => v ? '$' + Number(v).toLocaleString('en-US') : '—';
// Persisted filter state so re-renders keep the operator's view.
const leadF = { mode: 'list', stage: '', zip: '', source: '', q: '', enriched: 'Y', minRoof: '' };

async function leads(zipFilter) {
  if (Array.isArray(zipFilter) && zipFilter.length) {
    leadF.zip = zipFilter[0]; leadF.enriched = ''; leadF.stage = '';
  }
  // If a stale API build without the pipeline endpoints is still serving,
  // show the legacy jobs-based lead book instead of an error.
  try { await api.get('/api/leads/counts'); }
  catch (e) { if (/ 404 /.test(e.message)) return legacyLeads(zipFilter); throw e; }
  const params = new URLSearchParams();
  if (leadF.stage) params.set('stage', leadF.stage);
  if (leadF.zip) params.set('zip', leadF.zip);
  if (leadF.source) params.set('source', leadF.source);
  if (leadF.q) params.set('q', leadF.q);
  if (leadF.enriched) params.set('enriched', leadF.enriched);
  if (leadF.minRoof) params.set('min_roof_age', leadF.minRoof);
  params.set('limit', leadF.mode === 'board' ? 2000 : 500);
  const [counts, list] = await Promise.all([
    api.get('/api/leads/counts'), api.get('/api/leads?' + params)]);

  const filters = `
    <form class="inline" onsubmit="return false">
      <label>View<select id="lMode">
        <option value="list" ${leadF.mode === 'list' ? 'selected' : ''}>Work queue</option>
        <option value="board" ${leadF.mode === 'board' ? 'selected' : ''}>Pipeline board</option></select></label>
      <label>Search<input id="lQ" value="${esc(leadF.q)}" placeholder="owner, street, phone…"></label>
      <label>Stage<select id="lStage"><option value="">All</option>
        ${[...LEAD_STAGES, ...LEAD_SIDE].map(s => `<option value="${s}" ${leadF.stage === s ? 'selected' : ''}>${STAGE_LABEL[s]}</option>`).join('')}</select></label>
      <label>Zip<select id="lZip"><option value="">All</option>
        ${counts.zips.map(z => `<option value="${esc(z.zip)}" ${leadF.zip === z.zip ? 'selected' : ''}>${esc(z.zip)} (${z.n})</option>`).join('')}</select></label>
      <label>Source<select id="lSource"><option value="">All</option>
        ${counts.sources.map(s => `<option value="${esc(s.source)}" ${leadF.source === s.source ? 'selected' : ''}>${esc(s.source)}</option>`).join('')}</select></label>
      <label>Contactable<select id="lEnriched">
        <option value="" ${leadF.enriched === '' ? 'selected' : ''}>All</option>
        <option value="Y" ${leadF.enriched === 'Y' ? 'selected' : ''}>Enriched only</option>
        <option value="N" ${leadF.enriched === 'N' ? 'selected' : ''}>Scraped only</option></select></label>
      <label>Roof age ≥<input id="lRoof" value="${esc(leadF.minRoof)}" style="width:60px" placeholder="20"></label>
      <span>${list.length} shown of ${counts.total}</span>
    </form>`;

  const statCards = `<div class="stats">
    ${LEAD_STAGES.map(s => `<div class="stat"><div class="icon">№</div>
      <div class="label">${STAGE_LABEL[s]}</div><div class="value">${counts.stages[s]}</div>
      <div class="foot">&nbsp;</div></div>`).join('')}</div>`;

  const badge = (l) => `<span class="pill">${STAGE_LABEL[l.pipeline_stage] || l.pipeline_stage}</span>
    ${l.dnc ? '<span class="flag">DNC</span>' : ''}
    ${l.absentee ? '<span class="pill pending">ABSENTEE</span>' : ''}`;

  if (leadF.mode === 'board') {
    const cols = [...LEAD_STAGES, ...LEAD_SIDE];
    $view.innerHTML = statCards + filters + `
      <div class="board">${cols.map(s => {
        const inCol = list.filter(l => l.pipeline_stage === s);
        const shown = inCol.slice(0, 40);
        return `<div class="col" data-stage="${s}"><h3>${STAGE_LABEL[s]} (${counts.stages[s]})</h3>
          ${shown.map(l => `<div class="card" draggable="true" data-id="${l.id}">
            <b>${esc([l.owner_first, l.owner_last].filter(Boolean).join(' ') || l.property_address)}</b>
            <small>${esc([l.property_address, l.zip].filter(Boolean).join(', '))}</small>
            <small>${l.roof_age_min ? `roof ≥${l.roof_age_min}y · ` : ''}score ${l.score}${l.dnc ? ' · DNC' : ''}</small>
          </div>`).join('')}
          ${inCol.length > shown.length ? `<small>+${inCol.length - shown.length} more — filter to see all</small>` : ''}
        </div>`;
      }).join('')}</div>
      <p><small>Drag a card to move its stage. Emailed needs an email on file;
      Called needs a phone; DNC leads can't enter outbound stages.</small></p>`;
    let dragId = null;
    $view.querySelectorAll('.card').forEach(c => {
      c.onclick = () => leadDetail(c.dataset.id);
      c.ondragstart = () => { dragId = c.dataset.id; };
    });
    $view.querySelectorAll('.col').forEach(col => {
      col.ondragover = (e) => e.preventDefault();
      col.ondrop = async (e) => {
        e.preventDefault();
        if (!dragId) return;
        try { await api.send('POST', `/api/leads/${dragId}/stage`, { stage: col.dataset.stage }); }
        catch (err) { alert('Move blocked: ' + err.message); }
        leads();
      };
    });
  } else {
    $view.innerHTML = statCards + filters + `
      <div class="panel"><table>
        <tr><th class="num">Score</th><th>Owner</th><th>Property</th><th>Phone</th>
          <th class="num">Roof age</th><th class="num">Assessed</th><th>Stage</th></tr>
        ${list.map(l => `<tr>
          <td class="num"><b>${l.score}</b></td>
          <td><a class="link" data-id="${l.id}">${esc([l.owner_first, l.owner_last].filter(Boolean).join(' ') || '—')}</a></td>
          <td><small>${esc([l.property_address, l.city, l.zip].filter(Boolean).join(', '))}</small></td>
          <td>${dash(l.primary_phone)}</td>
          <td class="num ${Number(l.roof_age_min) >= 20 ? 'neg' : ''}">${l.roof_age_min ? l.roof_age_min + 'y' : '—'}</td>
          <td class="num">${fmtVal(l.assessed_value)}</td>
          <td>${badge(l)}</td></tr>`).join('')}
      </table>${list.length >= 500 ? '<p><small>Showing first 500 by score — narrow with filters.</small></p>' : ''}</div>`;
    $view.querySelectorAll('a.link').forEach(a => a.onclick = () => leadDetail(a.dataset.id));
  }

  const bind = (id, key, delay) => {
    const el = document.getElementById(id);
    if (!el) return;
    let t;
    el[delay ? 'oninput' : 'onchange'] = () => {
      clearTimeout(t);
      t = setTimeout(() => { leadF[key] = el.value; leads(); }, delay || 0);
    };
  };
  bind('lMode', 'mode'); bind('lStage', 'stage'); bind('lZip', 'zip');
  bind('lSource', 'source'); bind('lEnriched', 'enriched');
  bind('lQ', 'q', 300); bind('lRoof', 'minRoof', 400);
  if (leadF.q) { const b = document.getElementById('lQ'); b.focus(); b.setSelectionRange(leadF.q.length, leadF.q.length); }
}

/* Legacy lead book (jobs-based) — shown only while the API host still runs
   the pre-pipeline build. Same rows the importer creates via /api/jobs. */
async function legacyLeads(zipFilter) {
  const q = (document.getElementById('leadSearch')?.value || '').toLowerCase();
  const stage = document.getElementById('leadStage')?.value || '';
  const all = await api.get('/api/jobs');
  const EARLY = ['Lead', 'Contacted', 'Inspection', 'Proposal'];
  let list = all.filter(j => EARLY.includes(j.status));
  if (Array.isArray(zipFilter) && zipFilter.length) list = list.filter(j => zipFilter.includes(j.zip));
  const counts = Object.fromEntries(EARLY.map(s => [s, list.filter(j => j.status === s).length]));
  if (stage) list = list.filter(j => j.status === stage);
  if (q) list = list.filter(j =>
    [j.customer_name, j.address, j.city, j.zip, j.phone, j.notes].join(' ').toLowerCase().includes(q));
  const intel = (notes) => ({
    built: (notes.match(/Built (\d{4})/) || [])[1] || '',
    roof: (notes.match(/Roof age ≥(\d+)/) || [])[1] || '',
    assessed: (notes.match(/Assessed (\$[\d,]+)/) || [])[1] || '',
  });
  $view.innerHTML = `
    <div class="stats">
      ${EARLY.map(s => `<div class="stat"><div class="icon">№</div>
        <div class="label">${s}</div><div class="value">${counts[s]}</div>
        <div class="foot">&nbsp;</div></div>`).join('')}
    </div>
    <form class="inline" onsubmit="return false">
      <label>Search<input id="leadSearch" value="${esc(q)}" placeholder="name, street, zip, phone…"></label>
      <label>Stage<select id="leadStage">
        <option value="">All (${Object.values(counts).reduce((a, b) => a + b, 0)})</option>
        ${EARLY.map(s => `<option ${stage === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
      <span>${list.length} shown</span>
    </form>
    <div class="panel"><table>
      <tr><th>Name</th><th>Address</th><th>Phone</th><th>Built</th><th>Roof Age</th>
        <th>Assessed</th><th>Stage</th><th></th></tr>
      ${list.slice(0, 500).map(j => {
        const t = intel(j.notes || '');
        return `<tr><td><a class="link" data-id="${j.id}">${esc(j.customer_name)}</a></td>
        <td><small>${esc([j.address, j.city, j.zip].filter(Boolean).join(', '))}</small></td>
        <td>${esc(j.phone)}</td><td>${t.built}</td>
        <td>${t.roof ? t.roof + ' yrs' : ''}</td><td>${t.assessed}</td>
        <td><span class="pill">${j.status}</span></td>
        <td>${j.status === 'Lead' ? `<button class="btn small" data-contact="${j.id}">Mark contacted</button>` : ''}</td>
        </tr>`;
      }).join('')}
    </table>${list.length > 500 ? `<p><small>Showing first 500 of ${list.length} — narrow with search.</small></p>` : ''}</div>`;
  $view.querySelectorAll('a.link').forEach(a => a.onclick = () => openJob(a.dataset.id));
  $view.querySelectorAll('button[data-contact]').forEach(b => b.onclick = async () => {
    await api.send('PUT', '/api/jobs/' + b.dataset.contact,
      { contacted_date: new Date().toISOString().slice(0, 10) });
    leads();
  });
  const box = document.getElementById('leadSearch');
  let t;
  box.oninput = () => { clearTimeout(t); t = setTimeout(() => leads(), 300); };
  document.getElementById('leadStage').onchange = () => leads();
  if (q) { box.focus(); box.setSelectionRange(q.length, q.length); }
}

/* ---------- Lead card (the expansive record view) ---------- */
async function leadDetail(id) {
  const l = await api.get('/api/leads/' + id);
  let users = null;
  try { users = await api.get('/api/users'); } catch { /* office role: no user list */ }
  const owner = [l.owner_first, l.owner_last].filter(Boolean).join(' ') || '(owner unknown)';
  const phones = l.contacts.filter(c => c.type !== 'email');
  const emails = l.contacts.filter(c => c.type === 'email');
  const tel = (v) => `<a class="link" href="tel:${esc(v)}">${esc(v)}</a>`;
  const oldRoof = Number(l.roof_age_min) >= 20;

  $view.innerHTML = `
    <p><a class="link" id="backToLeads">← Leads</a></p>
    <h2>${esc(owner)}
      <span class="pill">${STAGE_LABEL[l.pipeline_stage] || l.pipeline_stage}</span>
      <span class="pill ${l.enriched ? '' : 'pending'}">${l.enriched ? 'ENRICHED' : 'SCRAPED'}</span>
      <span class="pill">score ${l.score}</span>
      ${l.dnc ? '<span class="flag">DO NOT CONTACT</span>' : ''}</h2>
    <p>${esc([l.property_address, l.city, l.state, l.zip].filter(Boolean).join(', '))}</p>
    <p>
      ${l.primary_phone && !l.dnc ? `<a class="btn small" href="tel:${esc(l.primary_phone)}">📞 Call ${esc(l.primary_phone)}</a>` : ''}
      ${emails.length && !l.dnc ? `<a class="btn small" href="mailto:${esc(emails[0].value)}">✉ Email</a>` : ''}
      <label style="display:inline-block">Move stage <select id="stageSel">
        <option value="">—</option>
        ${[...LEAD_STAGES, ...LEAD_SIDE].filter(s => s !== l.pipeline_stage)
          .map(s => `<option value="${s}">${STAGE_LABEL[s]}</option>`).join('')}</select></label>
      <button class="btn small ${l.dnc ? '' : 'danger'}" id="dncBtn">${l.dnc ? 'Clear DNC' : 'Mark DNC'}</button>
    </p>

    <div class="grid2">
    <div class="panel"><h3>Contact</h3>
      ${l.dnc ? '<p class="flag"><b>DO NOT CONTACT</b> — outbound actions disabled.</p>' : ''}
      <table>
        <tr><td>Primary phone</td><td>${l.primary_phone ? tel(l.primary_phone) + ` <small>(${dash(l.phone_type)})</small>` : '—'}</td></tr>
        <tr><td>Mobiles</td><td>${phones.filter(c => c.type === 'mobile').map(c => tel(c.value)).join('<br>') || '—'}</td></tr>
        <tr><td>Landlines</td><td>${phones.filter(c => c.type === 'landline').map(c => tel(c.value)).join('<br>') || '—'}</td></tr>
        <tr><td>Emails</td><td>${emails.map(c => `<a class="link" href="mailto:${esc(c.value)}">${esc(c.value)}</a>`).join('<br>') || '—'}</td></tr>
        <tr><td>Mailing address</td><td>${dash([l.mail_address, l.mail_city, l.mail_state, l.mail_zip].filter(Boolean).join(', '))}
          ${l.absentee ? '<br><b class="flag">ABSENTEE OWNER</b> — owner lives elsewhere' : ''}</td></tr>
      </table></div>

    <div class="panel"><h3>Property</h3>
      <table>
        <tr><td>Roof age (min)</td><td class="${oldRoof ? 'neg' : ''}">
          ${l.roof_age_min ? `<b style="font-size:1.2em">≥ ${l.roof_age_min} years</b>${oldRoof ? ' <span class="flag">REPLACEMENT WINDOW</span>' : ''}` : '—'}</td></tr>
        <tr><td>Year built</td><td>${dash(l.year_built)}</td></tr>
        <tr><td>Assessed value</td><td>${fmtVal(l.assessed_value)}</td></tr>
        <tr><td>Building</td><td>${dash(l.bldg_desc)}</td></tr>
        <tr><td>Source</td><td>${dash(l.source)} · zip ${dash(l.zip)}${l.external_id ? ` · ${esc(l.external_id)}` : ''}</td></tr>
      </table></div>
    </div>

    <div class="grid2">
    <div class="panel"><h3>Workflow</h3>
      <form id="wfForm"><table>
        <tr><td>Assigned rep</td><td>${users
          ? `<select name="assigned_to"><option value="">—</option>
             ${users.filter(u => u.active && ['admin', 'office'].includes(u.role))
               .map(u => `<option value="${u.id}" ${u.id === l.assigned_to ? 'selected' : ''}>${esc(u.name || u.email)}</option>`).join('')}</select>`
          : dash(l.assigned_to)}</td></tr>
        <tr><td>Next action</td><td><input type="date" name="next_action_at" value="${esc((l.next_action_at || '').slice(0, 10))}"></td></tr>
        <tr><td>Last touch</td><td>${dash(l.last_touch_at)}</td></tr>
        <tr><td>Notes</td><td><textarea name="notes">${esc(l.notes)}</textarea></td></tr>
      </table><button class="btn small">Save</button></form>
      <h3>Stage history</h3>
      <table>${l.stage_history.map(h => `<tr><td><small>${h.created_at}</small></td>
        <td>${h.from_stage ? esc(STAGE_LABEL[h.from_stage] || h.from_stage) + ' → ' : ''}<b>${esc(STAGE_LABEL[h.to_stage] || h.to_stage)}</b></td>
        <td><small>${esc(h.user_name || 'import')}</small></td></tr>`).join('') || '<tr><td>—</td></tr>'}</table></div>

    <div class="panel"><h3>Activity log</h3>
      <form class="inline" id="actForm">
        <label>Type<select name="kind"><option value="note">Note</option>
          ${l.dnc ? '' : '<option value="call">Call</option><option value="email">Email</option>'}
          <option value="appointment">Appointment</option></select></label>
        <label>Detail<input name="detail" required placeholder="what happened"></label>
        <button class="btn small">Log</button>
      </form>
      <table>${l.activities.map(a => `<tr><td><small>${a.created_at}</small></td>
        <td><span class="pill">${esc(a.kind)}</span></td><td>${esc(a.detail)}</td>
        <td><small>${esc(a.user_name || '')}</small></td></tr>`).join('') || '<tr><td>No activity yet.</td></tr>'}</table></div>
    </div>
    <p><small>Provenance: property facts = county assessor record · contact data =
    Tracerfy skip trace · roof age &amp; value = CLAY enrichment. Blank fields are
    shown as “—”, never guessed.</small></p>`;

  document.getElementById('backToLeads').onclick = () => leads();
  document.getElementById('stageSel').onchange = async (e) => {
    if (!e.target.value) return;
    try { await api.send('POST', `/api/leads/${id}/stage`, { stage: e.target.value }); }
    catch (err) { alert('Move blocked: ' + err.message); }
    leadDetail(id);
  };
  document.getElementById('dncBtn').onclick = async () => {
    await api.send('PUT', '/api/leads/' + id, { dnc: l.dnc ? 0 : 1 });
    leadDetail(id);
  };
  document.getElementById('wfForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    if (f.assigned_to !== undefined) f.assigned_to = f.assigned_to || null;
    await api.send('PUT', '/api/leads/' + id, f);
    leadDetail(id);
  };
  document.getElementById('actForm').onsubmit = async (e) => {
    e.preventDefault();
    try { await api.send('POST', `/api/leads/${id}/activities`, Object.fromEntries(new FormData(e.target))); }
    catch (err) { alert('Blocked: ' + err.message); }
    leadDetail(id);
  };
}

/* ---------- Pipeline board ---------- */
async function pipeline() {
  const jobsList = await api.get('/api/jobs');
  $view.innerHTML = `
    <form class="inline" id="newJob">
      <label>Customer name*<input name="customer_name" required></label>
      <label>Phone<input name="phone"></label>
      <label>Job address<input name="address"></label>
      <label>Scope of work<input name="scope_of_work"></label>
      <button class="btn">Add Lead</button>
    </form>
    <div class="board">${STATUSES.map(s => {
      const inCol = jobsList.filter(j => j.status === s);
      const shown = inCol.slice(0, 30);
      return `
      <div class="col"><h3>${s} (${inCol.length})</h3>
        ${shown.map(j => `
          <div class="card" data-id="${j.id}">
            <b>${esc(j.customer_name)}</b>
            <small>${esc(j.scope_of_work || j.address || '')}</small>
            ${j.job_total_cents ? `<small>${fmt$(j.job_total_cents)} · owed ${fmt$(j.balance_owed_cents)}</small>` : ''}
          </div>`).join('')}
        ${inCol.length > shown.length ? `<small>+${inCol.length - shown.length} more — see the Jobs tab</small>` : ''}
      </div>`;
    }).join('')}
    </div>`;
  document.getElementById('newJob').onsubmit = async (e) => {
    e.preventDefault();
    await api.send('POST', '/api/jobs', Object.fromEntries(new FormData(e.target)));
    render();
  };
  $view.querySelectorAll('.card').forEach(c => c.onclick = () => openJob(c.dataset.id));
}

/* ---------- Jobs list + detail ---------- */
async function jobs(id) {
  if (id) return jobDetail(id);
  const q = (document.getElementById('jobSearch')?.value || '').toLowerCase();
  let list = await api.get('/api/jobs');
  if (q) list = list.filter(j =>
    [j.customer_name, j.address, j.city, j.zip, j.phone, j.notes].join(' ').toLowerCase().includes(q));
  $view.innerHTML = `<h2>Jobs</h2>
    <div class="sheet-toolbar">
      <a class="bigbtn" href="${API_BASE}/api/jobs/export.csv" download>📤 Export to Excel / Google Sheets</a>
      <button class="bigbtn" id="importBtn">📥 Import from Excel / Google Sheets</button>
      <a class="bigbtn" href="${API_BASE}/api/jobs/import-template.csv" download>📄 Get a blank template</a>
      <button class="bigbtn" id="helpBtn">❓ Show me how this works</button>
    </div>
    <form class="inline" onsubmit="return false">
      <label>Search<input id="jobSearch" value="${esc(q)}" placeholder="name, address, phone…"></label>
      <span>${list.length} shown</span>
    </form>
    <table><tr>
      <th>Customer</th><th>Address</th><th>Status</th><th>Scope</th><th class="num">Job Total</th>
      <th class="num">Balance Owed</th><th class="num">Net Profit</th></tr>
    ${list.map(j => `<tr>
      <td><a class="link" data-id="${j.id}">${esc(j.customer_name)}</a></td>
      <td><small>${esc([j.address, j.city, j.state, j.zip].filter(Boolean).join(', '))}</small></td>
      <td><span class="pill">${j.status}</span></td><td>${esc(j.scope_of_work)}</td>
      <td class="num">${fmt$(j.job_total_cents)}</td>
      <td class="num">${fmt$(j.balance_owed_cents)}</td>
      <td class="num ${j.net_profit_cents < 0 ? 'neg' : 'pos'}">${fmt$(j.net_profit_cents)}</td></tr>`).join('')}
    </table>`;
  $view.querySelectorAll('a.link').forEach(a => a.onclick = () => openJob(a.dataset.id));
  document.getElementById('importBtn').onclick = () => openImportWizard();
  document.getElementById('helpBtn').onclick = () => showTutorial(true);
  // The tour never auto-opens (it blocks the whole UI mid-demo on any fresh
  // browser) — it lives behind the ❓ Tutorial button in the toolbar.
  const box = document.getElementById('jobSearch');
  let t;
  box.oninput = () => { clearTimeout(t); t = setTimeout(() => jobs(), 300); };
  if (q) { box.focus(); box.setSelectionRange(q.length, q.length); }
}

function openJob(id) {
  currentView = 'jobs';
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('active', b.dataset.view === 'jobs'));
  jobDetail(id);
}

async function jobDetail(id) {
  const [j, scopeTypes, contractors, suppliers, cats] = await Promise.all([
    api.get('/api/jobs/' + id), api.get('/api/scope-types'), api.get('/api/contractors'),
    api.get('/api/suppliers'), api.get('/api/expense-categories')]);
  const sub = contractors.find(c => c.id === j.contractor_id);
  $view.innerHTML = `
    <h2>${esc(j.customer_name)} <span class="pill">${j.status}</span></h2>
    <div class="grid2">
    <div class="panel"><h3>Contact & Pipeline</h3>
      <form id="jobForm">
        <table>
        <tr><td>Phone</td><td><input name="phone" value="${esc(j.phone)}"></td></tr>
        <tr><td>Email</td><td><input name="email" value="${esc(j.email)}"></td></tr>
        <tr><td>Address</td><td><input name="address" value="${esc(j.address)}"></td></tr>
        <tr><td>City / State / Zip</td><td>
          <input name="city" value="${esc(j.city)}" style="width:38%">
          <input name="state" value="${esc(j.state)}" style="width:18%">
          <input name="zip" value="${esc(j.zip)}" style="width:28%"></td></tr>
        <tr><td>Scope of work</td><td><input name="scope_of_work" value="${esc(j.scope_of_work)}"></td></tr>
        <tr><td>Contacted</td><td><input type="date" name="contacted_date" value="${j.contacted_date}"></td></tr>
        <tr><td>Inspection</td><td><input type="date" name="inspection_date" value="${j.inspection_date}"></td></tr>
        <tr><td>Proposal sent</td><td><input type="date" name="proposal_sent" value="${j.proposal_sent}"></td></tr>
        <tr><td>Signed contract</td><td><input type="date" name="signed_contract" value="${j.signed_contract}"></td></tr>
        <tr><td>Sub assigned</td><td><select name="contractor_id"><option value="">—</option>
          ${contractors.map(c => `<option value="${c.id}" ${c.id === j.contractor_id ? 'selected' : ''}>${esc(c.name)}${c.insurance_lapsed ? ' — INSURANCE LAPSED' : ''}</option>`).join('')}
        </select>${sub && sub.insurance_lapsed ? ' <span class="flag">SUB INSURANCE LAPSED</span>' : ''}</td></tr>
        <tr><td>Schedule date</td><td><input type="date" name="schedule_date" value="${j.schedule_date}"></td></tr>
        <tr><td>Completed date</td><td><input type="date" name="completed_date" value="${j.completed_date}"></td></tr>
        <tr><td>Job total ($)</td><td><input name="job_total" value="${(j.job_total_cents / 100).toFixed(2)}"></td></tr>
        <tr><td>Notes</td><td><textarea name="notes">${esc(j.notes)}</textarea></td></tr>
        </table><button class="btn">Save</button>
      </form></div>

    <div class="panel"><h3>Money</h3>
      <table>
        <tr><td>Job Total</td><td class="num">${fmt$(j.job_total_cents)}</td></tr>
        <tr><td>Payments received</td><td class="num">${fmt$(j.payments_cents)}</td></tr>
        <tr class="totals"><td>Balance Owed</td><td class="num">${fmt$(j.balance_owed_cents)}</td></tr>
        <tr><td>Material cost</td><td class="num">${fmt$(j.material_cost_cents)}</td></tr>
        <tr><td>Labor (contractor payments)</td><td class="num">${fmt$(j.labor_cost_cents)}</td></tr>
        <tr><td>Dumpster</td><td class="num">${fmt$(j.dumpster_cost_cents)}</td></tr>
        <tr><td>Other direct costs</td><td class="num">${fmt$(j.other_cost_cents)}</td></tr>
        <tr class="totals"><td>Net Profit ${j.margin_pct !== null ? `(${j.margin_pct}%)` : ''}</td>
          <td class="num ${j.net_profit_cents < 0 ? 'neg' : 'pos'}">${fmt$(j.net_profit_cents)}</td></tr>
      </table>
      <h3>Payments</h3>
      <table>${j.payment_list.map(p => `<tr><td>${esc(p.label)}</td><td>${p.date}</td>
        <td class="num">${fmt$(p.amount_cents)}</td>
        <td><button class="btn small danger" data-del-pay="${p.id}">×</button></td></tr>`).join('')}</table>
      <form class="inline" id="payForm">
        <label>Type<select name="label"><option>Deposit</option><option>Additional Payment</option><option>Final Payment</option><option>Payment</option></select></label>
        <label>Date<input type="date" name="date"></label>
        <label>Amount ($)<input name="amount" required></label>
        <button class="btn small">Add payment</button>
      </form></div>
    </div>

    <div class="panel"><h3>Scope quantities</h3>
      <table>${j.scope.map(s => `<tr><td>${esc(s.name)}</td><td class="num">${s.quantity} ${esc(s.unit)}</td>
        <td><button class="btn small danger" data-del-scope="${s.id}">×</button></td></tr>`).join('')}</table>
      <form class="inline" id="scopeForm">
        <label>Trade<select name="scope_type_id">${scopeTypes.map(t => `<option value="${t.id}">${esc(t.name)} (${esc(t.unit)})</option>`).join('')}</select></label>
        <label>Quantity<input name="quantity" required></label>
        <button class="btn small">Add</button>
      </form></div>

    <div class="panel"><h3>Material documents</h3>
      ${j.material_documents.map(d => `<div>
        <b>${d.doc_type} ${esc(d.document_number)}</b> — ${esc((suppliers.find(s => s.id === d.supplier_id) || {}).name || 'supplier?')}
         · subtotal ${fmt$(d.subtotal_cents)} + fuel ${fmt$(d.fuel_surcharge_cents)} + tax ${fmt$(d.sales_tax_cents)}
         = <b>${fmt$(d.total_cents)}</b>
        <button class="btn small danger" data-del-doc="${d.id}">delete</button>
        <table>${d.lines.map(l => `<tr><td>${esc(l.sku)}</td><td>${esc(l.description)}</td>
          <td class="num">${l.quantity} ${esc(l.uom)}</td><td class="num">${fmt$(l.unit_price_cents)}</td>
          <td class="num">${fmt$(l.amount_cents)}</td>
          <td><button class="btn small danger" data-del-line="${l.id}">×</button></td></tr>`).join('')}</table>
        <form class="inline" data-line-form="${d.id}">
          <label>SKU<input name="sku"></label><label>Description<input name="description"></label>
          <label>Qty<input name="quantity"></label><label>UOM<input name="uom"></label>
          <label>Price/UOM ($)<input name="price"></label>
          <button class="btn small">Add line</button>
        </form></div>`).join('')}
      <form class="inline" id="docForm">
        <label>Type<select name="doc_type"><option>Quote</option><option>Invoice</option></select></label>
        <label>Document #<input name="document_number"></label>
        <label>Supplier<select name="supplier_id">${suppliers.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></label>
        <label>Fuel surcharge ($)<input name="fuel"></label>
        <label>Sales tax ($)<input name="tax"></label>
        <button class="btn small">New material document</button>
      </form></div>

    <div class="panel"><h3>Job expenses (labor, dumpster, other)</h3>
      <table>${j.expenses.map(e => `<tr><td>${e.date}</td><td>${esc(e.category)}</td>
        <td>${esc(e.vendor)}</td><td class="num">${fmt$(e.amount_cents)}</td></tr>`).join('')}</table>
      <p><small>Add job expenses from the Expenses tab and link them to this job.
      Enter supplier material invoices as Material Documents above (not as Supplier
      Payment expenses) so costs aren't counted twice.</small></p></div>`;

  document.getElementById('jobForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    f.job_total_cents = toCents(f.job_total); delete f.job_total;
    f.contractor_id = f.contractor_id || null;
    await api.send('PUT', '/api/jobs/' + id, f);
    jobDetail(id);
  };
  document.getElementById('payForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    await api.send('POST', `/api/jobs/${id}/payments`, { label: f.label, date: f.date, amount_cents: toCents(f.amount) });
    jobDetail(id);
  };
  document.getElementById('scopeForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    await api.send('POST', `/api/jobs/${id}/scope`, { scope_type_id: +f.scope_type_id, quantity: +f.quantity });
    jobDetail(id);
  };
  document.getElementById('docForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    await api.send('POST', '/api/material-documents', { job_id: +id, doc_type: f.doc_type,
      document_number: f.document_number, supplier_id: +f.supplier_id || null,
      fuel_surcharge_cents: toCents(f.fuel), sales_tax_cents: toCents(f.tax) });
    jobDetail(id);
  };
  $view.querySelectorAll('[data-line-form]').forEach(form => form.onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(form));
    await api.send('POST', `/api/material-documents/${form.dataset.lineForm}/lines`,
      { sku: f.sku, description: f.description, quantity: +f.quantity || 0, uom: f.uom,
        unit_price_cents: toCents(f.price) });
    jobDetail(id);
  });
  const del = (sel, url) => $view.querySelectorAll(sel).forEach(b => b.onclick = async () => {
    await api.send('DELETE', url + b.dataset[Object.keys(b.dataset)[0]]); jobDetail(id);
  });
  del('[data-del-pay]', '/api/payments/');
  del('[data-del-scope]', '/api/scope/');
  del('[data-del-doc]', '/api/material-documents/');
  del('[data-del-line]', '/api/material-lines/');
}

/* ---------- P&L ---------- */
async function pnl() {
  const from = document.querySelector('[name=pnl_from]')?.value || '';
  const to = document.querySelector('[name=pnl_to]')?.value || '';
  const data = await api.get(`/api/pnl?from=${from}&to=${to}`);
  const t = data.totals;
  $view.innerHTML = `<h2>P&amp;L — completed jobs</h2>
    <form class="inline" id="pnlFilter">
      <label>From<input type="date" name="pnl_from" value="${from}"></label>
      <label>To<input type="date" name="pnl_to" value="${to}"></label>
      <button class="btn small">Filter</button>
    </form>
    <table><tr><th>Completed</th><th>Customer</th><th>Scope</th>
      <th class="num">Job Total</th><th class="num">Materials</th><th class="num">Labor</th>
      <th class="num">Dumpster</th><th class="num">Other</th><th class="num">Net Profit</th><th class="num">Margin</th></tr>
    ${data.rows.map(j => `<tr><td>${j.completed_date}</td>
      <td><a class="link" data-id="${j.id}">${esc(j.customer_name)}</a></td><td>${esc(j.scope_of_work)}</td>
      <td class="num">${fmt$(j.job_total_cents)}</td><td class="num">${fmt$(j.material_cost_cents)}</td>
      <td class="num">${fmt$(j.labor_cost_cents)}</td><td class="num">${fmt$(j.dumpster_cost_cents)}</td>
      <td class="num">${fmt$(j.other_cost_cents)}</td>
      <td class="num ${j.net_profit_cents < 0 ? 'neg' : 'pos'}">${fmt$(j.net_profit_cents)}</td>
      <td class="num">${j.margin_pct ?? ''}%</td></tr>`).join('')}
    <tr class="totals"><td colspan="3">Totals</td>
      <td class="num">${fmt$(t.job_total_cents)}</td><td class="num">${fmt$(t.material_cost_cents)}</td>
      <td class="num">${fmt$(t.labor_cost_cents)}</td><td class="num">${fmt$(t.dumpster_cost_cents)}</td>
      <td class="num">${fmt$(t.other_cost_cents)}</td>
      <td class="num ${t.net_profit_cents < 0 ? 'neg' : 'pos'}">${fmt$(t.net_profit_cents)}</td><td></td></tr>
    </table>`;
  document.getElementById('pnlFilter').onsubmit = (e) => { e.preventDefault(); pnl(); };
  $view.querySelectorAll('a.link').forEach(a => a.onclick = () => openJob(a.dataset.id));
}

/* ---------- Expenses ---------- */
async function expenses() {
  const month = document.querySelector('[name=exp_month]')?.value
    || new Date().toISOString().slice(0, 7);
  const year = new Date().getFullYear();
  const [list, cats, jobsList, contractors, n1099] = await Promise.all([
    api.get('/api/expenses?month=' + month), api.get('/api/expense-categories'),
    api.get('/api/jobs'), api.get('/api/contractors'), api.get('/api/1099?year=' + year)]);
  const catName = (c) => c.parent_id
    ? `${(cats.find(p => p.id === c.parent_id) || {}).name} › ${c.name}` : c.name;
  const byCat = {};
  list.forEach(e => { byCat[e.category] = (byCat[e.category] || 0) + e.amount_cents; });
  $view.innerHTML = `<h2>Expenses</h2>
    <form class="inline" id="expForm" enctype="multipart/form-data">
      <label>Date<input type="date" name="date" value="${new Date().toISOString().slice(0, 10)}"></label>
      <label>Amount ($)<input name="amount" required></label>
      <label>Category<select name="category_id">
        ${cats.map(c => `<option value="${c.id}">${esc(catName(c))}${c.qb_type === 'equity' ? ' (equity)' : ''}</option>`).join('')}</select></label>
      <label>Vendor<input name="vendor"></label>
      <label>Job (optional = direct job cost)<select name="job_id"><option value="">— overhead —</option>
        ${jobsList.map(j => `<option value="${j.id}">${esc(j.customer_name)}</option>`).join('')}</select></label>
      <label>Contractor (for Contractor Payment / 1099)<select name="contractor_id"><option value="">—</option>
        ${contractors.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label>
      <label>Payment method<input name="payment_method"></label>
      <label>Receipt<input type="file" name="receipt"></label>
      <label>Notes<input name="notes"></label>
      <button class="btn">Add expense</button>
    </form>
    <form class="inline" id="monthForm">
      <label>Month<input type="month" name="exp_month" value="${month}"></label>
      <button class="btn small">View</button>
      <a class="link" href="${API_BASE}/api/expenses/export.csv" download>Export CSV for QuickBooks</a>
    </form>
    <div class="grid2">
      <div class="panel"><h3>${month} by category</h3>
        <table>${Object.entries(byCat).map(([c, s]) =>
          `<tr><td>${esc(c)}</td><td class="num">${fmt$(s)}</td></tr>`).join('')}
        <tr class="totals"><td>Total</td><td class="num">${fmt$(list.reduce((a, e) => a + e.amount_cents, 0))}</td></tr></table>
        <p><small>Owner's Draw and Partner Capital Investment are equity, not
        expenses — they export flagged for the bookkeeper's equity accounts.</small></p>
        <h3>1099-NEC — ${year}</h3>
        ${n1099.length ? `<table><tr><th>Contractor</th><th class="num">Paid YTD</th><th>W-9</th></tr>
          ${n1099.map(r => `<tr><td>${esc(r.legal_name)} <small>${esc(r.tin_masked)}</small></td>
            <td class="num">${fmt$(r.paid_cents)}</td>
            <td>${r.w9_on_file ? '<span class="pos">on file</span>' : '<span class="flag">MISSING</span>'}</td></tr>`).join('')}
          </table>` : `<p><small>No contractor paid ≥ $600 in ${year} yet. Log payments with the
          Contractor Payment category and a contractor selected.</small></p>`}
        <p><a class="link" href="${API_BASE}/api/1099?year=${year}&format=csv" download>Export 1099-NEC CSV</a></p></div>
      <div class="panel"><h3>Entries</h3>
        <table>${list.map(e => `<tr><td>${e.date}</td><td>${esc(e.category)}${e.qb_type === 'equity' ? ' <span class="pill">equity</span>' : ''}</td>
          <td>${esc(e.vendor)}</td><td class="num">${fmt$(e.amount_cents)}</td>
          <td>${e.receipt_path ? `<a class="link" href="${API_BASE}/uploads/${e.receipt_path}">receipt</a>` : ''}</td>
          <td><button class="btn small danger" data-id="${e.id}">×</button></td></tr>`).join('')}</table></div>
    </div>`;
  document.getElementById('expForm').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.set('amount_cents', toCents(fd.get('amount'))); fd.delete('amount');
    await api.form('/api/expenses', fd);
    expenses();
  };
  document.getElementById('monthForm').onsubmit = (e) => { e.preventDefault(); expenses(); };
  $view.querySelectorAll('button[data-id]').forEach(b => b.onclick = async () => {
    await api.send('DELETE', '/api/expenses/' + b.dataset.id); expenses();
  });
}

/* ---------- Reference lists (all add-a-row) ---------- */
async function reference() {
  const [contractors, specialties, vendors, prices, suppliers, scopeTypes, cats] = await Promise.all([
    api.get('/api/contractors'), api.get('/api/specialties'), api.get('/api/dumpster-vendors'),
    api.get('/api/dumpster-prices'), api.get('/api/suppliers'), api.get('/api/scope-types'),
    api.get('/api/expense-categories')]);
  $view.innerHTML = `<h2>Reference lists</h2>

    <div class="panel"><h3>Contractors</h3>
      <table><tr><th>Name</th><th>Specialties</th><th>Phone</th><th>License</th><th>Insurance exp.</th><th>Docs</th></tr>
      ${contractors.map(c => `<tr><td>${esc(c.name)}</td>
        <td>${c.specialty_ids.map(id => (specialties.find(s => s.id === id) || {}).name).filter(Boolean).join(', ')}</td>
        <td>${esc(c.phone)}</td>
        <td>${esc(c.license_number)} ${c.license_lapsed ? '<span class="flag">LAPSED</span>' : ''}</td>
        <td>${c.insurance_expiry} ${c.insurance_lapsed ? '<span class="flag">LAPSED</span>' : ''}</td>
        <td>${['insurance', 'w9', 'license'].map(k =>
          `<form style="display:inline" data-doc="${c.id}:${k}"><input type="file" name="file" style="width:90px">
           <button class="btn small">${k}</button></form>`).join(' ')}</td></tr>`).join('')}</table>
      <form class="inline" id="contractorForm">
        <label>Company / name<input name="name" required></label>
        <label>Phone<input name="phone"></label>
        <label>License #<input name="license_number"></label>
        <label>License expiry<input type="date" name="license_expiry"></label>
        <label>Insurance expiry<input type="date" name="insurance_expiry"></label>
        <label>Specialties<select name="specialty_ids" multiple size="3">
          ${specialties.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></label>
        <button class="btn small">Add contractor</button>
      </form>
      <form class="inline" data-add="specialties"><label>New specialty<input name="name" required></label>
        <button class="btn small">Add specialty</button></form></div>

    <div class="panel"><h3>Dumpster vendors</h3>
      <table><tr><th>Vendor</th><th>Contact</th><th>Prices</th></tr>
      ${vendors.map(v => `<tr><td>${esc(v.name)}</td><td>${esc(v.contact_info)}</td>
        <td>${prices.filter(p => p.vendor_id === v.id).map(p => `${esc(p.size_label)}: ${fmt$(p.cost_cents)}`).join(' · ')}
        <form style="display:inline" data-price="${v.id}">
          <input name="size_label" placeholder="Size (e.g. 40 Yard)" style="width:110px">
          <input name="cost" placeholder="$" style="width:70px"><button class="btn small">+</button></form></td></tr>`).join('')}</table>
      <form class="inline" data-add="dumpster-vendors">
        <label>Company<input name="name" required></label><label>Contact<input name="contact_info"></label>
        <button class="btn small">Add vendor</button></form></div>

    <div class="panel"><h3>Suppliers</h3>
      <table><tr><th>Company</th><th>Branch</th><th>Account #</th><th>Rep</th><th>Phone</th><th>Materials</th></tr>
      ${suppliers.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.branch_address)}</td><td>${esc(s.account_number)}</td>
        <td>${esc(s.rep)}</td><td>${esc(s.phone)}</td><td>${esc(s.materials_carried)}</td></tr>`).join('')}</table>
      <form class="inline" data-add="suppliers">
        <label>Company<input name="name" required></label><label>Branch<input name="branch_address"></label>
        <label>Account #<input name="account_number"></label><label>Rep<input name="rep"></label>
        <label>Phone<input name="phone"></label>
        <button class="btn small">Add supplier</button></form></div>

    <div class="panel"><h3>Scope / trade types</h3>
      <table>${scopeTypes.map(t => `<tr><td>${esc(t.name)}</td><td>${esc(t.unit)}</td></tr>`).join('')}</table>
      <form class="inline" data-add="scope-types">
        <label>Trade<input name="name" required></label><label>Unit<input name="unit"></label>
        <button class="btn small">Add trade type</button></form></div>

    <div class="panel"><h3>Expense categories</h3>
      <table>${cats.filter(c => !c.parent_id).map(c => `<tr><td>${esc(c.name)}
          ${c.qb_type === 'equity' ? '<span class="pill">equity</span>' : ''}</td>
        <td>${cats.filter(s => s.parent_id === c.id).map(s => esc(s.name)).join(', ')}</td></tr>`).join('')}</table>
      <form class="inline" id="catForm">
        <label>Name<input name="name" required></label>
        <label>Parent (for subcategory)<select name="parent_id"><option value="">— top level —</option>
          ${cats.filter(c => !c.parent_id).map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label>
        <label>QB type<select name="qb_type"><option value="expense">Expense</option><option value="equity">Equity</option></select></label>
        <button class="btn small">Add category</button></form></div>`;

  $view.querySelectorAll('form[data-add]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    await api.send('POST', '/api/' + f.dataset.add, Object.fromEntries(new FormData(f)));
    reference();
  });
  document.getElementById('contractorForm').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = Object.fromEntries(fd);
    body.specialty_ids = fd.getAll('specialty_ids').map(Number);
    await api.send('POST', '/api/contractors', body);
    reference();
  };
  document.getElementById('catForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    await api.send('POST', '/api/expense-categories',
      { name: f.name, parent_id: f.parent_id || null, qb_type: f.qb_type });
    reference();
  };
  $view.querySelectorAll('form[data-price]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(f));
    await api.send('POST', '/api/dumpster-prices',
      { vendor_id: +f.dataset.price, size_label: d.size_label, cost_cents: toCents(d.cost) });
    reference();
  });
  $view.querySelectorAll('form[data-doc]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    const [id, kind] = f.dataset.doc.split(':');
    await api.form(`/api/contractors/${id}/docs/${kind}`, new FormData(f));
    reference();
  });
}

/* ---------- Onboarding (invites, review queue, compliance) ---------- */
async function onboarding(inviteLink) {
  const [contractors, specialties, invites] = await Promise.all([
    api.get('/api/contractors'), api.get('/api/specialties'), api.get('/api/onboarding')]);
  const pending = invites.filter(i => i.status === 'submitted');
  const open = invites.filter(i => i.status === 'pending');
  const queueHtml = `
    <div class="panel"><h3>Invite a contractor to self-onboard</h3>
      <form class="inline" id="invForm">
        <label>Name*<input name="name" required></label>
        <label>Email<input name="email" type="email"></label>
        <label>Phone<input name="phone"></label>
        <button class="btn">Generate link</button>
      </form>
      ${inviteLink ? `<p><b>Send this link</b> (single use, expires in 7 days):<br>
        <code>${esc(inviteLink)}</code></p>` : ''}
      <p><small>The contractor fills out the whole package themselves: W-9 with
      e-signature, license and insurance uploads with expiry dates, direct
      deposit (encrypted), specialties, and the six NJ agreements. The link
      shows them their form and nothing else.</small></p></div>

    ${pending.length ? `<div class="panel"><h3>Awaiting review (${pending.length})</h3>
      ${pending.map(i => `<div style="border-bottom:1px solid #eef0f4;padding:10px 0">
        <b>${esc(i.data.legal_name || i.name)}</b>
        ${i.data.worker_type ? `<span class="pill">1099 ${esc(i.data.worker_type)}</span>` : ''}
        ${i.data.dba ? `(DBA ${esc(i.data.dba)})` : ''} · ${esc(i.data.entity_type || '')}
        · TIN ${esc(i.data.tin_masked || 'missing')}
        <br><small>${esc([i.data.address, i.data.city, i.data.state, i.data.zip].filter(Boolean).join(', '))}
        · ${esc(i.data.phone || '')} ${esc(i.data.email || '')}
        · HIC ${esc(i.data.hic_number || '—')} · GL exp ${esc(i.data.gl_expiry || '—')}
        · WC ${esc(i.data.wc_expiry || (i.data.wc_exempt ? 'exempt' : '—'))}
        · crew ${esc(i.data.crew_size || '—')} · zips ${esc(i.data.service_zips || '—')}</small>
        <br><small>Docs: ${Object.entries(i.doc_files).map(([k, f]) =>
          `<a class="link" href="${API_BASE}/uploads/${esc(f)}" target="_blank">${k}</a>`).join(' · ') || 'none'}
        · Signatures: ${i.signature_records.map(s => `${esc(s.agreement)} (${esc(s.name)}, ${s.ts.slice(0, 10)})`).join(', ')}</small>
        <br><button class="btn small" data-approve="${i.id}">Approve</button>
        <button class="btn small danger" data-reject="${i.id}">Reject</button>
      </div>`).join('')}</div>` : ''}

    ${open.length ? `<div class="panel"><h3>Invites out (${open.length})</h3>
      <table><tr><th>Name</th><th>Sent to</th><th>Expires</th><th>Link</th></tr>
      ${open.map(i => `<tr><td>${esc(i.name)}</td><td>${esc(i.email)} ${esc(i.phone)}</td>
        <td>${i.expires_at.slice(0, 10)}${i.reject_reason ? ` <span class="flag">returned: ${esc(i.reject_reason)}</span>` : ''}</td>
        <td><code>/onboard/${esc(i.token)}</code></td></tr>`).join('')}</table></div>` : ''}`;
  const docStatus = (c) => {
    const items = [
      ['W9', !!c.w9_doc],
      ['Insurance doc', !!c.insurance_doc],
      ['Insurance current', !!c.insurance_expiry && !c.insurance_lapsed],
      ['License doc', !!c.license_doc],
      ['License current', !!c.license_expiry && !c.license_lapsed],
    ];
    return { items, done: items.filter(i => i[1]).length, total: items.length };
  };
  $view.innerHTML = `
    ${queueHtml}
    <div class="panel"><h3>Manual add (office fills it in)</h3>
      <form class="inline" id="obForm">
        <label>Company / name*<input name="name" required></label>
        <label>Contact<input name="contact_name"></label>
        <label>Phone<input name="phone"></label>
        <label>Email<input name="email"></label>
        <label>License #<input name="license_number"></label>
        <label>License expiry<input type="date" name="license_expiry"></label>
        <label>Insurance expiry<input type="date" name="insurance_expiry"></label>
        <label>Specialties<select name="specialty_ids" multiple size="3">
          ${specialties.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></label>
        <label>Login email (creates contractor portal login)<input name="login_email" type="email"></label>
        <button class="btn">Add contractor</button>
      </form><div id="obNotice"></div></div>
    <div class="panel"><h3>Compliance status</h3>
      <table><tr><th>Contractor</th><th>Checklist</th><th>Upload docs</th><th>Compliance</th></tr>
      ${contractors.map(c => {
        const st = docStatus(c);
        return `<tr><td><b>${esc(c.name)}</b><br><small>${esc(c.phone)} ${esc(c.email)}</small></td>
        <td>${st.items.map(([label, ok]) =>
          `<span class="pill ${ok ? '' : 'pending'}">${ok ? '✓' : '·'} ${label}</span>`).join(' ')}</td>
        <td>${['insurance', 'w9', 'license'].map(k =>
          `<form style="display:inline" data-doc="${c.id}:${k}"><input type="file" name="file" style="width:90px">
           <button class="btn small">${k}</button></form>`).join(' ')}</td>
        <td>${st.done === st.total ? '<span class="pos"><b>READY</b></span>'
          : `<b>${st.done}/${st.total}</b>${(c.insurance_lapsed || c.license_lapsed) ? ' <span class="flag">LAPSED DOCS</span>' : ''}`}</td>
        </tr>`;
      }).join('')}</table></div>`;
  document.getElementById('obForm').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = Object.fromEntries(fd);
    body.specialty_ids = fd.getAll('specialty_ids').map(Number);
    const r = await api.send('POST', '/api/contractors', body);
    if (r.login && r.login.temp_password) {
      alert(`Portal login created for ${r.login.email}\nTemporary password: ${r.login.temp_password}\n\nShare it now — it is shown only once.`);
    }
    onboarding();
  };
  $view.querySelectorAll('form[data-doc]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    const [id, kind] = f.dataset.doc.split(':');
    await api.form(`/api/contractors/${id}/docs/${kind}`, new FormData(f));
    onboarding();
  });
  document.getElementById('invForm').onsubmit = async (e) => {
    e.preventDefault();
    const r = await api.send('POST', '/api/onboarding/invite', Object.fromEntries(new FormData(e.target)));
    onboarding(r.link);
  };
  $view.querySelectorAll('button[data-approve]').forEach(b => b.onclick = async () => {
    const r = await api.send('POST', `/api/onboarding/${b.dataset.approve}/approve`, {});
    if (r.login && r.login.temp_password) {
      alert(`Approved. Portal login for ${r.login.email}\nTemporary password: ${r.login.temp_password}\n\nShare it now — shown only once.`);
    }
    onboarding();
  });
  $view.querySelectorAll('button[data-reject]').forEach(b => b.onclick = async () => {
    const reason = prompt('Reason (the contractor sees this and the link re-opens):');
    if (reason === null) return;
    await api.send('POST', `/api/onboarding/${b.dataset.reject}/reject`, { reason });
    onboarding();
  });
}

/* ---------- Team (user management: invite, role, deactivate) ---------- */
async function team(notice) {
  const [users, contractors, jobsList] = await Promise.all([
    api.get('/api/users'), api.get('/api/contractors'), api.get('/api/jobs')]);
  $view.innerHTML = `
    ${notice ? `<div class="panel"><b>Login created.</b> ${notice} — share it now;
      it's shown only once.</div>` : ''}
    <div class="panel"><h3>Invite a user</h3>
      <form class="inline" id="teamForm">
        <label>Name*<input name="name" required></label>
        <label>Email*<input name="email" type="email" required></label>
        <label>Role<select name="role" id="roleSel">
          <option value="admin">Admin (everything)</option>
          <option value="office" selected>Office (CRM/Pipeline/Reference/Onboarding)</option>
          <option value="contractor">Contractor (their jobs only)</option>
          <option value="client">Client (their job only)</option></select></label>
        <label>Contractor (for contractor role)<select name="contractor_id"><option value="">—</option>
          ${contractors.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label>
        <label>Job (for client role)<select name="job_id"><option value="">—</option>
          ${jobsList.slice(0, 200).map(j => `<option value="${j.id}">${esc(j.customer_name)}</option>`).join('')}</select></label>
        <button class="btn">Invite</button>
      </form>
      <p><small>An invite creates the login with a temporary password shown once —
      text or email it to them; they can change it after signing in.</small></p></div>
    <div class="panel"><h3>Users</h3>
      <table><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr>
      ${users.map(u => `<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td>
        <td><span class="pill">${esc(u.role)}</span></td>
        <td>${u.active ? '<span class="pos">active</span>' : '<span class="flag">deactivated</span>'}</td>
        <td><button class="btn small" data-pin="${u.id}">set PIN</button>
          ${u.active ? `<button class="btn small danger" data-id="${u.id}">deactivate</button>`
          : `<button class="btn small" data-react="${u.id}">reactivate</button>`}</td></tr>`).join('')}
      </table></div>`;
  document.getElementById('teamForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    f.contractor_id = f.contractor_id || null;
    f.job_id = f.job_id || null;
    const r = await api.send('POST', '/api/users', f);
    team(r.temp_password
      ? `<b>${esc(r.email)}</b> — temporary password: <code>${esc(r.temp_password)}</code>`
      : esc(r.error || ''));
  };
  $view.querySelectorAll('button[data-id]').forEach(b => b.onclick = async () => {
    await api.send('DELETE', '/api/users/' + b.dataset.id); team();
  });
  $view.querySelectorAll('button[data-react]').forEach(b => b.onclick = async () => {
    await api.send('PUT', '/api/users/' + b.dataset.react, { active: 1 }); team();
  });
  $view.querySelectorAll('button[data-pin]').forEach(b => b.onclick = async () => {
    const pin = prompt('New 4-digit PIN for this user (blank to remove):');
    if (pin === null) return;
    try { await api.send('PUT', '/api/users/' + b.dataset.pin, { pin }); alert(pin ? 'PIN set.' : 'PIN removed.'); }
    catch (e) { alert('PIN must be 4 digits.'); }
  });
}

/* ---------- Dev Tools ---------- */
async function devtools() {
  const [items, envStatus] = await Promise.all([
    api.get('/api/integrations'), api.get('/api/integration-status')]);
  const keys = items.filter(i => i.kind === 'api_key');
  const hooks = items.filter(i => i.kind === 'webhook');
  const base = API_BASE || location.origin;
  $view.innerHTML = `
    <div class="grid2">
    <div class="panel"><h3>API keys</h3>
      <table><tr><th>Name</th><th>Key</th><th>Notes</th><th></th></tr>
      ${keys.map(k => `<tr><td>${esc(k.name)}</td>
        <td><code>${esc(k.value.length > 12 ? k.value.slice(0, 6) + '…' + k.value.slice(-4) : k.value)}</code></td>
        <td>${esc(k.notes)}</td>
        <td><button class="btn small danger" data-id="${k.id}">×</button></td></tr>`).join('')}</table>
      <form class="inline" data-kind="api_key">
        <label>Name<input name="name" required placeholder="e.g. Twilio"></label>
        <label>Key<input name="value" required></label>
        <label>Notes<input name="notes"></label>
        <button class="btn small">Save key</button></form></div>

    <div class="panel"><h3>Webhooks</h3>
      <table><tr><th>Name</th><th>URL</th><th>Event</th><th></th></tr>
      ${hooks.map(h => `<tr><td>${esc(h.name)}</td><td><code>${esc(h.value)}</code></td>
        <td><span class="pill">${esc(h.event)}</span></td>
        <td><button class="btn small danger" data-id="${h.id}">×</button></td></tr>`).join('')}</table>
      <form class="inline" data-kind="webhook">
        <label>Name<input name="name" required placeholder="e.g. Zapier lead alert"></label>
        <label>URL<input name="value" required placeholder="https://..."></label>
        <label>Event<select name="event"><option>job.created</option><option>storm.alert</option></select></label>
        <button class="btn small">Add webhook</button></form>
      <p><small>Webhooks POST <code>{event, data}</code> JSON when the event
      fires — wire Zapier/Make/n8n here to push new leads anywhere.</small></p></div>
    </div>

    <div class="panel"><h3>Platform integrations (server env)</h3>
      <table>${envStatus.map(s => `<tr><td><code>${esc(s.key)}</code></td>
        <td>${s.configured ? '<span class="pos">configured</span>' : '<span class="flag">not set</span>'}</td></tr>`).join('')}</table>
      <p><small>Values live only in the server environment — never in the browser,
      the database, or git.</small></p></div>

    <div class="panel"><h3>REST API</h3>
      <p>Everything in this dashboard is a JSON API — same endpoints the UI uses:</p>
      <table>
        <tr><td><code>GET/POST ${esc(base)}/api/jobs</code></td><td>list / create jobs &amp; leads</td></tr>
        <tr><td><code>GET ${esc(base)}/api/jobs/:id</code></td><td>full job: payments, materials, costs, profit</td></tr>
        <tr><td><code>POST ${esc(base)}/api/jobs/:id/payments</code></td><td>record a payment (amount_cents)</td></tr>
        <tr><td><code>GET/POST ${esc(base)}/api/expenses</code></td><td>expense tracking</td></tr>
        <tr><td><code>GET ${esc(base)}/api/expenses/export.csv</code></td><td>QuickBooks CSV export</td></tr>
        <tr><td><code>GET/POST ${esc(base)}/api/contractors</code></td><td>sub-contractor records</td></tr>
        <tr><td><code>GET ${esc(base)}/api/pnl?from=&amp;to=</code></td><td>P&amp;L rows + totals</td></tr>
      </table>
      <p><small>All endpoints require auth: the browser uses your login cookie;
      integrations use a Bearer token — <a class="link" id="mintToken">mint one</a>.</small></p>
      <div id="tokenOut"></div>
      <p><small>Example — create a lead from anywhere (website form, AI receptionist):</small>
        <button class="gcopy" data-copy="curl -X POST ${esc(base)}/api/jobs -H &quot;Content-Type: application/json&quot; -H &quot;Authorization: Bearer YOUR_TOKEN&quot; -d '{&quot;customer_name&quot;:&quot;Jane Doe&quot;,&quot;phone&quot;:&quot;732-555-0100&quot;,&quot;address&quot;:&quot;1 Main St, Keansburg NJ&quot;}'">Copy curl</button></p>
      <pre>curl -X POST ${esc(base)}/api/jobs \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -d '{"customer_name":"Jane Doe","phone":"732-555-0100","address":"1 Main St, Keansburg NJ"}'</pre></div>`;
  document.getElementById('mintToken').onclick = async () => {
    const t = await api.get('/api/token');
    document.getElementById('tokenOut').innerHTML =
      `<pre>${esc(t.token)}</pre>
       <button class="gcopy" data-copy="${esc(t.token)}">Copy token</button>
       <p><small>Treat this like a password — it has your admin access.</small></p>`;
  };
  $view.querySelectorAll('form[data-kind]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(f));
    body.kind = f.dataset.kind;
    await api.send('POST', '/api/integrations', body);
    devtools();
  });
  $view.querySelectorAll('button[data-id]').forEach(b => b.onclick = async () => {
    await api.send('DELETE', '/api/integrations/' + b.dataset.id); devtools();
  });
}

/* ---------- shared modal helper ---------- */
function openModal(html) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.innerHTML = `<div class="modal"><button class="x" title="Close">×</button>${html}</div>`;
  document.body.appendChild(back);
  const onEsc = (e) => { if (e.key === 'Escape') close(); };
  const close = () => { back.remove(); removeEventListener('keydown', onEsc); };
  addEventListener('keydown', onEsc);
  back.querySelector('.x').onclick = close;
  back.onclick = (e) => { if (e.target === back) close(); };
  back.close = close;
  return back;
}

/* ---------- pop-up tutorial (first visit + the ❓ button) ---------- */
const TUTORIAL = [
  ['👋', 'Welcome to your CRM!', 'This is where every customer lives — from first phone call to final payment. You never have to retype anything: enter a customer once and the whole system uses it.\n\nThis quick tour takes 1 minute.'],
  ['🗂️', 'The tabs on the left', 'CRM = your customer list. Pipeline = the same customers as sticky-note columns (Lead → Paid). P&L and Expenses = the money side. Click a tab, that\'s it.'],
  ['➕', 'Adding a customer', 'Go to Pipeline and use the little form at the top — just a name is enough to start. Click any customer to open their card and fill in the rest whenever you get to it.'],
  ['📥', 'Import from Excel or Google Sheets', 'Already have customers in a spreadsheet? Click "Import from Excel / Google Sheets" on the CRM tab. It walks you through 3 easy steps, shows you a preview first, and NOTHING is saved until you say so.'],
  ['📤', 'Export back out any time', 'One click on "Export" downloads your whole customer list as a normal spreadsheet file — same columns you\'re used to (Name, Phone, Job Cost, Deposit, Balance Owed…). Open it in Excel or upload it to Google Drive.'],
  ['✨', 'Meet Ellianna', 'Ellianna is your office secretary — she\'s the "Ellianna ✨" tab. Ask her things in plain English like "how much did we spend on gas in March?" or upload a receipt photo and say "file this". She knows who you are when you log in.'],
  ['🎉', 'That\'s it!', 'You can re-watch this any time with the "❓ Show me how this works" button. Now go make some money.'],
];
function showTutorial(force) {
  if (!force) localStorage.setItem('paragonTutorialSeen', '1');
  let i = 0;
  const back = openModal('<div id="tutBody"></div>');
  const draw = () => {
    const [emoji, title, body] = TUTORIAL[i];
    back.querySelector('#tutBody').innerHTML = `
      <div class="steps">Step ${i + 1} of ${TUTORIAL.length}</div>
      <div class="big-emoji">${emoji}</div>
      <h2>${esc(title)}</h2>
      <p style="white-space:pre-wrap;font-size:15px;line-height:1.5">${esc(body)}</p>
      <div class="actions">
        ${i > 0 ? '<button class="bigbtn" id="tutBack">← Back</button>' : ''}
        <button class="btn" id="tutNext">${i === TUTORIAL.length - 1 ? 'Done ✓' : 'Next →'}</button>
      </div>`;
    const b = back.querySelector('#tutBack');
    if (b) b.onclick = () => { i--; draw(); };
    back.querySelector('#tutNext').onclick = () => {
      if (i === TUTORIAL.length - 1) return back.close();
      i++; draw();
    };
  };
  draw();
}

/* ---------- import wizard (3 steps, preview before anything saves) ---------- */
function openImportWizard() {
  const back = openModal('<div id="wizBody"></div>');
  const body = () => back.querySelector('#wizBody');
  let csvText = '';

  const step1 = () => {
    body().innerHTML = `
      <div class="steps">Step 1 of 3 — Get your sheet ready</div>
      <h2>📥 Import your customers</h2>
      <p style="font-size:15px;line-height:1.5">Your spreadsheet just needs the first row to be the column
      names — the same ones you already use:<br>
      <small><b>Name, Phone Number, Email, Address, Scope of Work, Proposal Sent (Date), Signed Contract,
      Sub Assigned, Job Cost, Schedule Date, Completed Date, Deposit, Additional Payment, Final Payment,
      Balance Owed, Notes</b></small></p>
      <p style="font-size:14px;color:#8593a2">Extra columns are fine. Empty boxes are fine. Dollar signs and
      dates like 6/1/2026 are fine. In Excel or Google Sheets use <b>File → Download → CSV</b> to save the file.</p>
      <p><a class="bigbtn" href="${API_BASE}/api/jobs/import-template.csv" download>📄 Download a ready-made template</a></p>
      <div class="actions"><button class="btn" id="wNext">I have my file → </button></div>`;
    body().querySelector('#wNext').onclick = step2;
  };

  const step2 = () => {
    body().innerHTML = `
      <div class="steps">Step 2 of 3 — Pick the file</div>
      <h2>Drop your file here</h2>
      <div class="dropzone" id="dz">📄 Click here to choose your file<br><small>or drag it from your desktop and drop it in this box</small></div>
      <input type="file" id="wFile" accept=".csv,text/csv,.txt" style="display:none">
      <div id="wMsg"></div>`;
    const dz = body().querySelector('#dz');
    const input = body().querySelector('#wFile');
    dz.onclick = () => input.click();
    dz.ondragover = (e) => { e.preventDefault(); dz.classList.add('drag'); };
    dz.ondragleave = () => dz.classList.remove('drag');
    dz.ondrop = (e) => { e.preventDefault(); dz.classList.remove('drag'); handle(e.dataTransfer.files[0]); };
    input.onchange = () => handle(input.files[0]);
    async function handle(file) {
      if (!file) return;
      if (/\.(xlsx|xls)$/i.test(file.name)) {
        body().querySelector('#wMsg').innerHTML = `<p class="flag">That's an Excel file (.xlsx). One tiny step first:
          open it in Excel and use <b>File → Save As → CSV</b> (or in Google Sheets: File → Download → CSV),
          then pick that file here.</p>`;
        return;
      }
      csvText = await file.text();
      body().querySelector('#wMsg').innerHTML = '<p>Checking your file…</p>';
      try {
        const preview = await api.send('POST', '/api/jobs/import', { csv: csvText, dry_run: true });
        step3(preview);
      } catch (err) {
        const msg = /400/.test(err.message)
          ? 'The file could not be read. Make sure the first row is the column names (use the template if unsure).'
          : err.message;
        body().querySelector('#wMsg').innerHTML = `<p class="flag">${esc(msg)}</p>`;
      }
    }
  };

  const step3 = (p) => {
    body().innerHTML = `
      <div class="steps">Step 3 of 3 — Check &amp; confirm</div>
      <h2>Here's what will happen</h2>
      <p style="font-size:16px">
        🆕 <b>${p.created}</b> new customer${p.created === 1 ? '' : 's'} will be added<br>
        🔄 <b>${p.updated}</b> existing customer${p.updated === 1 ? '' : 's'} will be updated<br>
        ${p.skipped ? `⏭️ <b>${p.skipped}</b> row${p.skipped === 1 ? '' : 's'} skipped (blank or example rows)<br>` : ''}
        ${p.new_subs.length ? `👷 New subs added to your contractor list: <b>${p.new_subs.map(esc).join(', ')}</b>` : ''}
      </p>
      <div class="import-preview"><table>
        <tr><th>Row</th><th>Customer</th><th>What happens</th></tr>
        ${p.details.slice(0, 50).map(d => `<tr><td>${d.row}</td><td>${esc(d.name)}</td>
          <td>${d.action === 'create' ? '🆕 add' : d.action === 'update' ? '🔄 update' : '⏭️ skip'}
          <small>${esc(d.reason)}</small></td></tr>`).join('')}
      </table></div>
      <p><small>Nothing has been saved yet. Wrong file? Just close this window — no harm done.</small></p>
      <div class="actions">
        <button class="bigbtn" id="wBack">← Pick a different file</button>
        <button class="btn" id="wGo">✓ Looks right — import now</button>
      </div>`;
    body().querySelector('#wBack').onclick = step2;
    body().querySelector('#wGo').onclick = async (e) => {
      e.target.disabled = true;
      e.target.textContent = 'Importing…';
      try {
        const r = await api.send('POST', '/api/jobs/import', { csv: csvText });
        body().innerHTML = `
          <div class="big-emoji">🎉</div>
          <h2>All done!</h2>
          <p style="font-size:16px" class="ok-badge">✓ ${r.created} added · ${r.updated} updated</p>
          <p>Your customers are in the CRM now. You can re-import the same sheet any time — it updates
          instead of making doubles.</p>
          <div class="actions"><button class="btn" id="wDone">Show my customers</button></div>`;
        body().querySelector('#wDone').onclick = () => { back.close(); jobs(); };
      } catch (err) {
        body().innerHTML += `<p class="flag">Something went wrong: ${esc(err.message)}</p>`;
      }
    };
  };

  step1();
}

/* ---------- Ellianna — the back-office AI secretary ---------- */
let elliannaLog = [];      // [{role:'user'|'assistant', content, attachments?, fileName?}]
let devLogState = [];      // Dev Dechado's chat (Dev Tools tab only)
let elliannaFile = null;   // pending File to send with the next message

// Ellianna's agent interface: her chat, her phone line, and her mailbox
// (Ellianna@paragonhomeimprovementco.com) all live under one identity.
let elliannaPane = 'chat';
async function ellianna(pane) {
  if (pane) elliannaPane = pane;
  $view.innerHTML = `
    <div class="ell-tabs">
      ${[['chat', '💬 Chat'], ['calls', '📞 Calls'], ['email', '✉️ Email']].map(([k, label]) =>
        `<button class="btn small ${elliannaPane === k ? 'active' : ''}" data-pane="${k}">${label}</button>`).join('')}
    </div>
    <div id="ellPane"></div>`;
  $view.querySelectorAll('[data-pane]').forEach(b => b.onclick = () => ellianna(b.dataset.pane));
  const pane_el = $view.querySelector('#ellPane');
  if (elliannaPane === 'chat') renderElliannaChat(pane_el);
  else if (elliannaPane === 'calls') renderElliannaCalls(pane_el);
  else renderElliannaEmail(pane_el);
}

// 📞 Her phone line — the Hume call log (same data as the dashboard panel).
async function renderElliannaCalls(root) {
  root.innerHTML = '<div class="panel"><h3>📞 Ellianna\'s phone line</h3><p>Loading…</p></div>';
  let calls = [];
  try { calls = await api.get('/api/calls'); } catch { calls = []; }
  root.innerHTML = `<div class="panel"><h3>📞 Ellianna's phone line — latest calls</h3>
    ${calls.length ? `<table class="table"><tr><th>When</th><th>Caller</th><th>Event</th><th>Length</th><th>Ended</th></tr>
      ${calls.map(c => `<tr><td><small>${esc(c.created_at)}</small></td><td>${esc(c.caller_number || '—')}</td>
        <td>${esc(c.event_name)}</td><td>${c.duration_seconds != null ? esc(c.duration_seconds) + 's' : '—'}</td>
        <td>${esc(c.end_reason || '—')}</td></tr>`).join('')}</table>`
      : '<p>No calls logged yet. Calls land here automatically once the Hume webhook key is set on the server.</p>'}
  </div>`;
}

// ✉️ Her mailbox — inbox, sent, and compose/reply as Ellianna's address.
let elliannaBox = 'inbox';
async function renderElliannaEmail(root, opts = {}) {
  const status = await api.get('/api/ellianna/email/status').catch(() => ({ configured: false, address: '' }));
  const head = `<div class="panel"><h3>✉️ Ellianna's email <small>${esc(status.address)}</small></h3>
    <div class="ell-tabs">
      <button class="btn small ${elliannaBox === 'inbox' ? 'active' : ''}" id="emBoxIn">Inbox</button>
      <button class="btn small ${elliannaBox === 'sent' ? 'active' : ''}" id="emBoxSent">Sent</button>
      <button class="btn small" id="emCompose">✏️ Compose</button>
      <button class="btn small" id="emRefresh">🔄</button>
    </div><div id="emBody"><p>Loading…</p></div></div>`;
  root.innerHTML = head;
  const body = root.querySelector('#emBody');
  root.querySelector('#emBoxIn').onclick = () => { elliannaBox = 'inbox'; renderElliannaEmail(root); };
  root.querySelector('#emBoxSent').onclick = () => { elliannaBox = 'sent'; renderElliannaEmail(root); };
  root.querySelector('#emRefresh').onclick = () => renderElliannaEmail(root);
  root.querySelector('#emCompose').onclick = () => drawCompose();

  const drawCompose = (reply) => {
    body.innerHTML = `
      <label>To <input id="emTo" value="${esc(reply ? reply.replyTo : '')}"></label>
      <label>Subject <input id="emSubj" value="${esc(reply ? 'Re: ' + reply.subject.replace(/^Re:\s*/i, '') : '')}"></label>
      <label>Message <textarea id="emText" rows="8"></textarea></label>
      <button class="btn" id="emSend">Send as Ellianna</button> <button class="btn small" id="emCancel">Cancel</button>
      <div id="emNote"></div>`;
    body.querySelector('#emCancel').onclick = () => renderElliannaEmail(root);
    body.querySelector('#emSend').onclick = async () => {
      const note = body.querySelector('#emNote');
      note.textContent = 'Sending…';
      try {
        await api.send('POST', '/api/ellianna/email/send', {
          to: body.querySelector('#emTo').value,
          subject: body.querySelector('#emSubj').value,
          body: body.querySelector('#emText').value,
          in_reply_to: reply ? reply.message_id : undefined,
          references: reply ? [...(reply.references || []), reply.message_id].filter(Boolean) : undefined,
        });
        note.textContent = '✅ Sent.';
        setTimeout(() => { elliannaBox = 'sent'; renderElliannaEmail(root); }, 900);
      } catch (e) { note.textContent = '😕 ' + e.message; }
    };
  };

  const drawMessage = async (uid) => {
    body.innerHTML = '<p>Loading message…</p>';
    try {
      const m = await api.get(`/api/ellianna/email/${elliannaBox}/${uid}`);
      body.innerHTML = `
        <button class="btn small" id="emBack">← Back</button>
        ${elliannaBox === 'inbox' ? '<button class="btn small" id="emReply">↩️ Reply</button>' : ''}
        <div class="panel"><b>${esc(m.subject)}</b><br>
          <small>From: ${esc(m.from)}<br>To: ${esc(m.to)}<br>${esc(m.date || '')}</small>
          <pre class="em-text">${esc(m.text)}</pre></div>`;
      body.querySelector('#emBack').onclick = () => renderElliannaEmail(root);
      const rb = body.querySelector('#emReply');
      if (rb) rb.onclick = () => drawCompose({ replyTo: m.from, subject: m.subject,
        message_id: m.message_id, references: m.references });
    } catch (e) { body.innerHTML = `<p>😕 ${esc(e.message)}</p>`; }
  };

  if (opts.compose) return drawCompose();
  if (!status.configured) {
    body.innerHTML = `<p>Her mailbox isn't connected yet — the server needs
      <code>ELLIANNA_EMAIL_PASSWORD</code> (a Google App Password for ${esc(status.address)}).</p>`;
    return;
  }
  try {
    const msgs = await api.get(`/api/ellianna/email/${elliannaBox}?limit=25`);
    body.innerHTML = msgs.length ? `<table class="table em-list">
      <tr><th>${elliannaBox === 'inbox' ? 'From' : 'To'}</th><th>Subject</th><th>When</th></tr>
      ${msgs.map(m => `<tr data-uid="${m.uid}" class="${m.seen ? '' : 'em-unread'}">
        <td>${esc(elliannaBox === 'inbox' ? m.from : m.to)}</td>
        <td>${esc(m.subject)}</td><td><small>${esc(m.date ? new Date(m.date).toLocaleString() : '')}</small></td></tr>`).join('')}
    </table>` : '<p>Nothing here yet.</p>';
    body.querySelectorAll('[data-uid]').forEach(tr => tr.onclick = () => drawMessage(tr.dataset.uid));
  } catch (e) { body.innerHTML = `<p>😕 ${esc(e.message)}</p>`; }
}

// Renders the chat into any container — the Ellianna tab uses $view, the
// floating "Ask Ellianna" bubble uses its slide-over panel.
function renderElliannaChat(root) {
  const CHIPS = [
    'What did we make last month?',
    'How much did we spend on gas this year?',
    'Which customers still owe us money?',
    'Help me — how do I add a job?',
  ];
  root.innerHTML = `
    <div class="chat-wrap">
      <div class="chat-log" id="chatLog"></div>
      ${elliannaLog.length ? '' : `<div class="chat-chips">${CHIPS.map(c =>
        `<button class="chip">${esc(c)}</button>`).join('')}</div>`}
      <div class="chat-input">
        <button class="bigbtn" id="chatFile" title="Attach a photo, receipt, or spreadsheet">📎</button>
        <input type="file" id="chatFileInput" style="display:none" accept="image/*,.pdf,.csv,.txt,.tsv,.xlsx,.xls">
        <button class="bigbtn" id="chatMic" title="Hold on — tap and talk instead of typing">🎤</button>
        <button class="bigbtn" id="chatVoice" title="Ellianna reads her answers out loud">${localStorage.getItem('elliannaVoice') === 'on' ? '🔊' : '🔇'}</button>
        <textarea id="chatText" placeholder="Type here — or tap 🎤 and just talk"></textarea>
        <button class="btn" id="chatSend">Send</button>
      </div>
    </div>`;
  const log = root.querySelector('#chatLog');
  const text = root.querySelector('#chatText');

  const draw = () => {
    log.innerHTML = elliannaLog.length ? elliannaLog.map(m => `
      ${m.fileName ? `<div class="file-tag">📎 ${esc(m.fileName)}</div>` : ''}
      <div class="msg ${m.role === 'user' ? 'user' : 'ellianna'}">${esc(m.content)}
        ${(m.attachments || []).map((a, i) => `<br><a class="link dl" data-att="${esc(m.ts)}:${i}">⬇️ Download ${esc(a.filename)}</a>`).join('')}
      </div>`).join('')
      : `<div class="msg ellianna">Hi${me && me.name ? ' ' + esc(me.name.split(' ')[0]) : ''}! I'm Ellianna, your office secretary. 💁‍♀️
Ask me about jobs, money, or expenses — or attach a receipt photo and tell me what to do with it.</div>`;
    log.querySelectorAll('[data-att]').forEach(a => a.onclick = () => {
      const [ts, i] = a.dataset.att.split(':');
      const att = elliannaLog.find(m => String(m.ts) === ts).attachments[+i];
      const url = URL.createObjectURL(new Blob([att.csv], { type: 'text/csv' }));
      const link = Object.assign(document.createElement('a'), { href: url, download: att.filename });
      link.click();
      URL.revokeObjectURL(url);
    });
    log.scrollTop = log.scrollHeight;
  };

  const send = async () => {
    const content = text.value.trim();
    if (!content && !elliannaFile) return;
    text.value = '';
    elliannaLog.push({ role: 'user', content: content || '(file attached)', fileName: elliannaFile ? elliannaFile.name : '', ts: Date.now() });
    draw();
    log.insertAdjacentHTML('beforeend', '<div class="msg ellianna thinking">Ellianna is working on it…</div>');
    log.scrollTop = log.scrollHeight;
    const fd = new FormData();
    fd.append('messages', JSON.stringify(elliannaLog.map(m => ({ role: m.role, content: m.content }))));
    if (elliannaFile) fd.append('file', elliannaFile);
    elliannaFile = null;
    root.querySelector('#chatFile').textContent = '📎';
    try {
      const r = await api.form('/api/assistant', fd);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'request failed');
      elliannaLog.push({ role: 'assistant', content: data.reply || '(no answer)', attachments: data.attachments || [], ts: Date.now() });
      speakReply(data.reply);
    } catch (err) {
      elliannaLog.push({ role: 'assistant', content: '😕 ' + err.message, ts: Date.now() });
    }
    draw();
  };

  // Voice playback (Hume TTS via the server) — toggled with the 🔊 button.
  async function speakReply(text) {
    if (localStorage.getItem('elliannaVoice') !== 'on' || !text) return;
    try {
      const r = await fetch(API_BASE + '/api/assistant/tts', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (!r.ok) return;
      const url = URL.createObjectURL(await r.blob());
      const audio = new Audio(url);
      audio.onended = () => URL.revokeObjectURL(url);
      audio.play();
    } catch { /* voice is a nice-to-have; never break chat over it */ }
  }

  root.querySelector('#chatSend').onclick = send;
  text.onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
  root.querySelector('#chatFile').onclick = () => root.querySelector('#chatFileInput').click();
  root.querySelector('#chatFileInput').onchange = (e) => {
    elliannaFile = e.target.files[0] || null;
    root.querySelector('#chatFile').textContent = elliannaFile ? '📎 ' + elliannaFile.name.slice(0, 14) : '📎';
  };
  root.querySelectorAll('.chip').forEach(c => c.onclick = () => { text.value = c.textContent; send(); });

  // 🔊 toggle — remember the choice per device.
  const voiceBtn = root.querySelector('#chatVoice');
  voiceBtn.onclick = () => {
    const on = localStorage.getItem('elliannaVoice') === 'on' ? '' : 'on';
    localStorage.setItem('elliannaVoice', on);
    voiceBtn.textContent = on ? '🔊' : '🔇';
  };

  // 🎤 tap-to-talk (browser speech recognition; Chrome/Edge/Safari).
  const micBtn = root.querySelector('#chatMic');
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) micBtn.style.display = 'none';
  else {
    let rec = null;
    micBtn.onclick = () => {
      if (rec) { rec.stop(); return; }
      rec = new SR();
      rec.lang = 'en-US';
      rec.interimResults = true;
      micBtn.textContent = '🔴';
      rec.onresult = (e) => {
        text.value = Array.from(e.results).map(r => r[0].transcript).join('');
      };
      rec.onend = () => {
        micBtn.textContent = '🎤';
        rec = null;
        if (text.value.trim()) send();
      };
      rec.onerror = () => { micBtn.textContent = '🎤'; rec = null; };
      rec.start();
    };
  }

  draw();
  text.focus();
}

/* ---------- Videos — Mux upload + playback (job walkthroughs, crew clips) ---------- */
async function videos() {
  const status = await api.get('/api/video/status').catch(() => ({ configured: false }));
  if (!status.configured) {
    $view.innerHTML = `<div class="panel"><h3>🎥 Videos</h3>
      <p>Video isn't connected yet — add <code>MUX_TOKEN_ID</code> and
      <code>MUX_TOKEN_SECRET</code> in Vercel → Settings → Environment
      Variables and redeploy.</p></div>`;
    return;
  }
  let assets = [];
  try { assets = await api.get('/api/video/assets'); } catch { assets = []; }
  $view.innerHTML = `
    <div class="panel"><h3>🎥 Upload a video</h3>
      <mux-uploader id="muxUp"></mux-uploader>
      <p><small>Job walkthroughs, roof inspections, crew clips — drag a file in.
      Processing takes a minute after upload; refresh to see it below.</small></p></div>
    <div class="panel"><h3>Library</h3>
      ${assets.length ? `<div class="video-grid">
        ${assets.map(a => `<div class="video-card">
          ${a.playback_id && a.status === 'ready'
            ? `<mux-player stream-type="on-demand" playback-id="${esc(a.playback_id)}" accent-color="#d4af37"></mux-player>`
            : `<div class="video-processing">⏳ ${esc(a.status)}…</div>`}
          <div class="video-meta"><small>${esc(new Date(a.created_at * 1000).toLocaleString())}
            ${a.duration ? ' · ' + Math.round(a.duration) + 's' : ''}</small>
            <button class="btn small danger" data-del="${esc(a.id)}">×</button></div>
        </div>`).join('')}
      </div>` : '<p>No videos yet. Upload the first one above.</p>'}
    </div>`;
  const up = $view.querySelector('#muxUp');
  up.endpoint = async () => (await api.send('POST', '/api/video/uploads', {})).url;
  up.addEventListener('success', () => setTimeout(videos, 4000));
  $view.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
    if (!confirm('Delete this video for everyone?')) return;
    await api.send('DELETE', '/api/video/assets/' + b.dataset.del);
    videos();
  });
}

/* ---------- Geist-style context card + copy button (vanilla ports) ----------
   Context card: entity metadata on hover/focus (150ms entry delay so it
   doesn't flash on a fast mouse sweep). Copy button: .gcopy[data-copy]. */
let ctxEl = null, ctxTimer = null;
function attachContextCard(trigger, html, side = 'top') {
  if (!trigger.hasAttribute('tabindex')) trigger.setAttribute('tabindex', '0');
  trigger.dataset.ctx = '1';
  const show = () => {
    ctxTimer = setTimeout(() => {
      if (!ctxEl) { ctxEl = document.createElement('div'); ctxEl.className = 'ctx-card'; document.body.appendChild(ctxEl); }
      ctxEl.innerHTML = html;
      ctxEl.classList.add('open');
      const r = trigger.getBoundingClientRect(), pad = 8, c = ctxEl.getBoundingClientRect();
      let x = r.left + r.width / 2 - c.width / 2;
      let y = side === 'bottom' ? r.bottom + pad : r.top - c.height - pad;
      if (side === 'left') { x = r.left - c.width - pad; y = r.top + r.height / 2 - c.height / 2; }
      if (side === 'right') { x = r.right + pad; y = r.top + r.height / 2 - c.height / 2; }
      x = Math.max(8, Math.min(x, innerWidth - c.width - 8));
      y = Math.max(8, Math.min(y, innerHeight - c.height - 8));
      ctxEl.style.left = x + 'px'; ctxEl.style.top = y + 'px';
    }, 150);
  };
  const hide = () => { clearTimeout(ctxTimer); if (ctxEl) ctxEl.classList.remove('open'); };
  trigger.addEventListener('mouseenter', show);
  trigger.addEventListener('mouseleave', hide);
  trigger.addEventListener('focus', show);
  trigger.addEventListener('blur', hide);
}
document.addEventListener('click', async (e) => {
  const b = e.target.closest('.gcopy');
  if (!b) return;
  try { await navigator.clipboard.writeText(b.dataset.copy ?? ''); } catch { return; }
  const prev = b.textContent;
  b.textContent = '✓ Copied';
  b.classList.add('copied');
  setTimeout(() => { b.textContent = prev; b.classList.remove('copied'); }, 1200);
});

/* ---------- liquid-metal CTAs (vanilla port of the LiquidMetalButton) ----------
   Every primary CTA (.btn, not the small/danger utility buttons) gets the
   liquid-metal skin automatically, on every page, including ones rendered
   later (wizards, modals, login). Ripple is event-delegated so real form
   submit buttons keep working untouched. */
function liquifyCtas() {
  document.querySelectorAll('button.btn:not(.small):not(.danger):not(.liquid-cta)')
    .forEach(b => b.classList.add('liquid-cta'));
}
new MutationObserver(liquifyCtas).observe(document.documentElement, { childList: true, subtree: true });
liquifyCtas();
document.addEventListener('click', (e) => {
  const b = e.target.closest('.liquid-cta');
  if (!b) return;
  const r = b.getBoundingClientRect();
  const s = document.createElement('span');
  s.className = 'lm-ripple';
  s.style.left = (e.clientX - r.left) + 'px';
  s.style.top = (e.clientY - r.top) + 'px';
  b.appendChild(s);
  setTimeout(() => s.remove(), 650);
});

boot();
