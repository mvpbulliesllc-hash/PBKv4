// Lead score weights — the ONE place to tune scoring (brief §4.2e).
// score = roof-age points + assessed-value band points + absentee bonus.
// Higher = better campaign target (old roof, real house, owner lives elsewhere).
const WEIGHTS = {
  roofAge: [                 // [min age, points] — first match wins
    [30, 40],
    [20, 30],
    [15, 20],
    [10, 10],
  ],
  assessedValue: [           // [min whole dollars, points]
    [500000, 20],
    [350000, 15],
    [250000, 10],
    [150000, 5],
  ],
  absenteeBonus: 15,
};

function scoreLead({ roof_age_min, assessed_value, absentee }) {
  let s = 0;
  const band = (table, v) => (table.find(([min]) => v >= min) || [0, 0])[1];
  if (Number(roof_age_min) > 0) s += band(WEIGHTS.roofAge, Number(roof_age_min));
  if (Number(assessed_value) > 0) s += band(WEIGHTS.assessedValue, Number(assessed_value));
  if (absentee) s += WEIGHTS.absenteeBonus;
  return s;
}

// Address normalization for the upsert key: uppercase, strip punctuation,
// collapse spaces, standardize street suffixes. Import + API share this.
function normalizeAddress(street) {
  return String(street || '').toUpperCase()
    .replace(/[^\w\s]/g, ' ').replace(/\s+/g, ' ').trim()
    .replace(/\bAVENUE\b/g, 'AVE').replace(/\bSTREET\b/g, 'ST').replace(/\bROAD\b/g, 'RD')
    .replace(/\bBOULEVARD\b/g, 'BLVD').replace(/\bDRIVE\b/g, 'DR').replace(/\bCOURT\b/g, 'CT')
    .replace(/\bPLACE\b/g, 'PL').replace(/\bLANE\b/g, 'LN').replace(/\bTERRACE\b/g, 'TER')
    .replace(/\bHIGHWAY\b/g, 'HWY');
}

module.exports = { WEIGHTS, scoreLead, normalizeAddress };
