// CRM sheet import/export in the office's "CRM Outline" layout:
//   Name | Phone Number | Email | Address | Scope of Work | Proposal Sent (Date)
//   | Signed Contract | Sub Assigned | Job Cost | Schedule Date | Completed Date
//   | Deposit | Additional Payment | Final Payment | Balance Owed | Notes
// Extra CRM-only fields are appended AFTER Notes so the sheet stays familiar.
// Balance Owed and Status are computed by the system — they export for the
// office's benefit but are ignored on import (humans enter inputs, the
// system does math).
const { toCsv, parseCsv, parseMoneyCents, parseDateText, normalizeHeader } = require('./csv-utils');

const SHEET_COLUMNS = ['Name', 'Phone Number', 'Email', 'Address', 'Scope of Work',
  'Proposal Sent (Date)', 'Signed Contract', 'Sub Assigned', 'Job Cost', 'Schedule Date',
  'Completed Date', 'Deposit', 'Additional Payment', 'Final Payment', 'Balance Owed', 'Notes'];
const EXTRA_COLUMNS = ['City', 'State', 'Zip', 'Contacted Date', 'Inspection Date', 'Status'];

// Forgiving header → field mapping (headers are normalized before lookup).
const HEADER_MAP = {
  'name': 'name', 'customer': 'name', 'customer name': 'name',
  'phone number': 'phone', 'phone': 'phone', 'phone 1': 'phone',
  'email': 'email', 'email address': 'email',
  'address': 'address', 'job address': 'address', 'street': 'address',
  'scope of work': 'scope_of_work', 'scope': 'scope_of_work',
  'proposal sent date': 'proposal_sent', 'proposal sent': 'proposal_sent', 'proposal': 'proposal_sent',
  'signed contract': 'signed_contract', 'signed': 'signed_contract', 'contract signed': 'signed_contract',
  'sub assigned': 'sub_assigned', 'sub': 'sub_assigned', 'contractor': 'sub_assigned', 'crew': 'sub_assigned',
  'job cost': 'job_cost', 'job total': 'job_cost', 'contract total': 'job_cost', 'price': 'job_cost',
  'schedule date': 'schedule_date', 'scheduled': 'schedule_date', 'start date': 'schedule_date',
  'completed date': 'completed_date', 'completed': 'completed_date', 'finish date': 'completed_date',
  'deposit': 'deposit',
  'additional payment': 'additional_payment', 'additional payments': 'additional_payment',
  'final payment': 'final_payment',
  'balance owed': 'balance_owed',   // computed — ignored on import
  'notes': 'notes', 'note': 'notes',
  'city': 'city', 'state': 'state', 'zip': 'zip', 'zip code': 'zip',
  'contacted date': 'contacted_date', 'contacted': 'contacted_date',
  'inspection date': 'inspection_date', 'inspection': 'inspection_date',
  'status': 'status',               // computed — ignored on import
};

const money = (cents) => cents ? (cents / 100).toFixed(2) : '';
const digits = (v) => String(v ?? '').replace(/\D/g, '');

// One exported row per job, in the exact CRM Outline column order.
async function buildExportRows({ all }, computeJob, maps) {
  const [jobs, contractors, payments] = await Promise.all([
    all('SELECT * FROM jobs ORDER BY id'),
    all('SELECT id, name FROM contractors'),
    all('SELECT job_id, label, amount_cents FROM payments'),
  ]);
  const subName = new Map(contractors.map(c => [c.id, c.name]));
  const pay = new Map(); // job_id → {deposit, additional, final}
  for (const p of payments) {
    const b = pay.get(p.job_id) || { deposit: 0, additional: 0, final: 0 };
    if (p.label === 'Deposit') b.deposit += p.amount_cents;
    else if (p.label === 'Final Payment') b.final += p.amount_cents;
    else b.additional += p.amount_cents;
    pay.set(p.job_id, b);
  }
  const rows = [[...SHEET_COLUMNS, ...EXTRA_COLUMNS]];
  for (const raw of jobs) {
    const j = computeJob(raw, maps);
    const b = pay.get(j.id) || { deposit: 0, additional: 0, final: 0 };
    rows.push([
      j.customer_name, j.phone, j.email, j.address, j.scope_of_work,
      j.proposal_sent, j.signed_contract, subName.get(j.contractor_id) || '',
      money(j.job_total_cents), j.schedule_date, j.completed_date,
      money(b.deposit), money(b.additional), money(b.final),
      money(j.balance_owed_cents), j.notes,
      j.city, j.state, j.zip, j.contacted_date, j.inspection_date, j.status,
    ]);
  }
  return rows;
}

function templateCsv() {
  return toCsv([
    [...SHEET_COLUMNS, ...EXTRA_COLUMNS],
    ['EXAMPLE - Jane Homeowner (this row is ignored on import)', '732-555-0100', 'jane@email.com',
      '12 Main St', 'Roof replacement', '6/1/2026', '6/5/2026', 'Shore Roofing LLC', '$18,500.00',
      '6/20/2026', '6/25/2026', '$9,250.00', '', '$9,250.00', '0.00',
      'Left key under mat', 'Keansburg', 'NJ', '07734', '5/25/2026', '5/28/2026', 'Paid'],
    ['EXAMPLE - Bob Builderfan (this row is ignored on import)', '848-555-0177', '',
      '9 Bay Ave', 'Siding + soffit', '', '', '', '$12,000.00',
      '', '', '', '', '', '', 'Wants a call after 5pm', 'Toms River', 'NJ', '08753', '', '', 'Lead'],
  ]);
}

// Sheet rows (string CSV or pre-parsed rows) → created/updated jobs + payments.
// dryRun previews without writing anything.
async function importSheet({ all, get, run }, body, { dryRun, defaultDate } = {}) {
  let rows = body.rows;
  if (!Array.isArray(rows)) {
    const parsed = parseCsv(body.csv || '');
    if (parsed.length < 2) return { error: 'The file looks empty — it needs a header row plus at least one customer row.' };
    const keys = parsed[0].map(h => HEADER_MAP[normalizeHeader(h)] || null);
    if (!keys.includes('name')) return { error: 'Could not find a "Name" column in the first row. Use the template — the first row must be the column names.' };
    rows = parsed.slice(1).map(cells =>
      Object.fromEntries(cells.map((v, i) => [keys[i], v]).filter(([k]) => k)));
  }

  const summary = { created: 0, updated: 0, skipped: 0, new_subs: [], details: [] };
  const note = (rowNum, name, action, reason) =>
    summary.details.push({ row: rowNum, name, action, reason: reason || '' });

  // Sub lookup with lazy creation (deferred in dry runs).
  const subs = new Map((await all('SELECT id, name FROM contractors'))
    .map(c => [c.name.toLowerCase().trim(), c.id]));
  const subId = async (name) => {
    const key = String(name || '').toLowerCase().trim();
    if (!key) return null;
    if (subs.has(key)) return subs.get(key);
    if (!summary.new_subs.includes(name.trim())) summary.new_subs.push(name.trim());
    if (dryRun) return null;
    const info = await run('INSERT INTO contractors (name) VALUES (?)', name.trim());
    subs.set(key, info.lastInsertRowid);
    return info.lastInsertRowid;
  };

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const rowNum = i + 2; // 1-based + header row, matches what the sheet shows
    const name = String(r.name || '').trim();
    if (!name) { summary.skipped++; note(rowNum, '(blank)', 'skip', 'no name'); continue; }
    if (/^example\b/i.test(name)) { summary.skipped++; note(rowNum, name, 'skip', 'template example row'); continue; }

    const fields = { customer_name: name };
    const setText = (col, v) => { if (v !== undefined) fields[col] = String(v).trim(); };
    const setDate = (col, v) => { if (v !== undefined) fields[col] = parseDateText(v); };
    setText('phone', r.phone); setText('email', r.email); setText('address', r.address);
    setText('city', r.city); setText('state', r.state); setText('zip', r.zip);
    setText('scope_of_work', r.scope_of_work); setText('notes', r.notes);
    setDate('proposal_sent', r.proposal_sent);
    setDate('signed_contract', r.signed_contract);   // date, or "yes"-style text passes through
    setDate('schedule_date', r.schedule_date); setDate('completed_date', r.completed_date);
    setDate('contacted_date', r.contacted_date); setDate('inspection_date', r.inspection_date);
    if (r.job_cost !== undefined) {
      const c = parseMoneyCents(r.job_cost);
      if (c !== null) fields.job_total_cents = c;
    }
    if (r.sub_assigned !== undefined && String(r.sub_assigned).trim()) {
      fields.contractor_id = await subId(r.sub_assigned);
      if (dryRun) delete fields.contractor_id;  // may not exist yet in a dry run
    }

    // Match an existing job: same name + same address, else same name + same
    // phone, else a single same-name job with no conflicting address.
    const candidates = await all('SELECT * FROM jobs WHERE LOWER(customer_name)=?', name.toLowerCase());
    const addr = String(r.address || '').toLowerCase().trim();
    const ph = digits(r.phone);
    const existing =
      (addr && candidates.find(j => String(j.address).toLowerCase().trim() === addr)) ||
      (ph && candidates.find(j => digits(j.phone) === ph)) ||
      (candidates.length === 1 && (!addr || !String(candidates[0].address).trim()) ? candidates[0] : null) ||
      null;

    let jobId;
    if (existing) {
      summary.updated++;
      note(rowNum, name, 'update', 'matched existing customer');
      if (!dryRun) {
        const cols = Object.keys(fields);
        await run(`UPDATE jobs SET ${cols.map(c => `${c}=?`).join(',')} WHERE id=?`,
          ...cols.map(c => fields[c]), existing.id);
      }
      jobId = existing.id;
    } else {
      summary.created++;
      note(rowNum, name, 'create', '');
      if (!dryRun) {
        const cols = Object.keys(fields);
        const info = await run(`INSERT INTO jobs (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
          ...cols.map(c => fields[c]));
        jobId = info.lastInsertRowid;
      }
    }

    // Payments: a filled-in Deposit / Additional / Final cell replaces that
    // payment on the job. Blank cells leave existing payments alone (never
    // destructive on a partial sheet).
    if (!dryRun && jobId) {
      const payDate = fields.completed_date || fields.signed_contract || defaultDate || '';
      for (const [col, label] of [['deposit', 'Deposit'],
        ['additional_payment', 'Additional Payment'], ['final_payment', 'Final Payment']]) {
        if (r[col] === undefined) continue;
        const cents = parseMoneyCents(r[col]);
        if (cents === null) continue;
        await run('DELETE FROM payments WHERE job_id=? AND label=?', jobId, label);
        if (cents > 0) {
          await run('INSERT INTO payments (job_id, label, date, amount_cents) VALUES (?,?,?,?)',
            jobId, label, /^\d{4}-\d{2}-\d{2}$/.test(payDate) ? payDate : '', cents);
        }
      }
    }
  }
  return summary;
}

module.exports = { SHEET_COLUMNS, EXTRA_COLUMNS, buildExportRows, templateCsv, importSheet, toCsv };
