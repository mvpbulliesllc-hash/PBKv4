// Ellianna — the back-office AI assistant (the in-app half; the full Hermes
// harness deployment lives in /ellianna). Chats with staff, knows who is
// talking from their login, reads uploaded photos/files, answers questions
// from the live database (jobs, P&L tracker, expenses, payments) via tools,
// and can hand back detailed CSV reports for download.
//
// Model: claude-fable-5 at low effort per the build spec, with a server-side
// fallback to claude-opus-4-8 if Fable's safety classifiers decline a turn.
// Requires ANTHROPIC_API_KEY in the server environment. Without it the
// endpoint answers with friendly setup instructions instead of erroring.
const fs = require('fs');
const path = require('path');
const { toCsv } = require('./csv-utils');
const tracker = require('./tracker');
const crmSheet = require('./crm-sheet');

// Sanitized business knowledge (ellianna/knowledge.md) — no secrets in it.
let KNOWLEDGE = '';
try { KNOWLEDGE = fs.readFileSync(path.join(__dirname, '..', 'ellianna', 'knowledge.md'), 'utf8'); }
catch { /* knowledge file optional */ }

const MODEL = 'claude-fable-5';
const FALLBACK_MODEL = 'claude-opus-4-8';
const MAX_TOOL_ROUNDS = 8;

const IMAGE_TYPES = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.gif': 'image/gif', '.webp': 'image/webp' };

const TOOLS = [
  {
    name: 'tracker_jobs',
    description: 'List jobs from the P&L Job Tracker (Joe\'s spreadsheet replacement). Each row: customer, dates signed/completed, job total, material/labor/dumpster costs, computed net profit and cost/profit percentages — all money in dollars. Optional filters.',
    input_schema: {
      type: 'object',
      properties: {
        q: { type: 'string', description: 'Free text match on customer name or notes' },
        signed_from: { type: 'string', description: 'Only jobs signed on/after YYYY-MM-DD' },
        signed_to: { type: 'string', description: 'Only jobs signed on/before YYYY-MM-DD' },
      },
    },
  },
  {
    name: 'tracker_summary',
    description: 'Business summary from the P&L tracker: jobs, revenue, and profit for the current month plus the last 6 months. Use for "what did we make last month" style questions.',
    input_schema: { type: 'object', properties: {} },
  },
  {
    name: 'add_tracker_job',
    description: 'Add one job to the P&L Job Tracker. Money in dollars. Use when someone dictates a job or a document (photo/PDF/sheet) contains one job to file.',
    input_schema: {
      type: 'object',
      properties: {
        customer_name: { type: 'string' },
        date_signed: { type: 'string', description: 'YYYY-MM-DD' },
        date_completed: { type: 'string' },
        job_total: { type: 'number' }, material_cost: { type: 'number' },
        labor_cost: { type: 'number' }, dumpster_cost: { type: 'number' },
        interior_repair: { type: 'number' }, bathroom: { type: 'number' },
        windows_quantity: { type: 'integer' }, deck_feet: { type: 'number' },
        siding_feet: { type: 'number' }, roof_sq_size: { type: 'number' },
        notes: { type: 'string' },
      },
      required: ['customer_name'],
    },
  },
  {
    name: 'add_crm_job',
    description: 'Add a customer/job to the CRM pipeline (name, contact, scope, dates). Use for new leads or customers someone mentions or a document contains.',
    input_schema: {
      type: 'object',
      properties: {
        customer_name: { type: 'string' }, phone: { type: 'string' }, email: { type: 'string' },
        address: { type: 'string' }, city: { type: 'string' }, state: { type: 'string' }, zip: { type: 'string' },
        scope_of_work: { type: 'string' }, notes: { type: 'string' },
        proposal_sent: { type: 'string', description: 'YYYY-MM-DD' },
        signed_contract: { type: 'string' }, schedule_date: { type: 'string' },
        job_total: { type: 'number', description: 'contract price in dollars' },
      },
      required: ['customer_name'],
    },
  },
  {
    name: 'import_sheet',
    description: 'Bulk-import spreadsheet rows (CSV text) into the system. target "crm" uses the CRM Outline columns (Name, Phone Number, ... Notes); target "tracker" uses Joe\'s P&L columns (Date Signed, Customer Name, Job Total, ...). Use when an uploaded file contains MANY rows. Pass dry_run true first to preview, tell the user the counts, then re-run with dry_run false when they confirm.',
    input_schema: {
      type: 'object',
      properties: {
        target: { type: 'string', enum: ['crm', 'tracker'] },
        csv: { type: 'string', description: 'The full CSV text including the header row' },
        dry_run: { type: 'boolean' },
      },
      required: ['target', 'csv'],
    },
  },
  {
    name: 'recent_calls',
    description: 'List recent phone calls handled by the Ellianna phone line (from the Hume webhook): caller number, when, duration, how it ended. Use for "who called today / any calls this week" questions.',
    input_schema: {
      type: 'object',
      properties: {
        since: { type: 'string', description: 'Only calls on/after this date-time, YYYY-MM-DD or YYYY-MM-DD HH:MM' },
      },
    },
  },
  {
    name: 'expense_report',
    description: 'Query expenses from the books. Filter by date range, category name, vendor, or free text. Dates are stored day-level (YYYY-MM-DD); times of day in a request should be rounded to whole days. Amounts returned are in dollars. Use group_by to summarize.',
    input_schema: {
      type: 'object',
      properties: {
        from_date: { type: 'string', description: 'Start date YYYY-MM-DD (inclusive)' },
        to_date: { type: 'string', description: 'End date YYYY-MM-DD (inclusive)' },
        category: { type: 'string', description: 'Category name, partial match ok (e.g. "Gas", "Contractor Payment")' },
        vendor: { type: 'string', description: 'Vendor name, partial match ok' },
        q: { type: 'string', description: 'Free text matched against vendor, notes, and category (e.g. "nails")' },
        group_by: { type: 'string', enum: ['category', 'vendor', 'month', 'job', 'none'], description: 'Optional summary grouping' },
      },
    },
  },
  {
    name: 'list_jobs',
    description: 'List jobs/customers in the CRM. Optional free-text search over name, address, phone, scope. Returns id, customer, status, job total, paid, balance owed (dollars).',
    input_schema: { type: 'object', properties: { q: { type: 'string' } } },
  },
  {
    name: 'get_job',
    description: 'Full detail for one job by id: contact info, pipeline dates, payments, expenses, material cost, net profit (dollars).',
    input_schema: { type: 'object', properties: { id: { type: 'integer' } }, required: ['id'] },
  },
  {
    name: 'add_expense',
    description: 'Record an expense in the books. If the user uploaded a file this conversation, it is automatically attached as the receipt. Category is matched by name and created if new.',
    input_schema: {
      type: 'object',
      properties: {
        amount_dollars: { type: 'number' },
        category: { type: 'string', description: 'e.g. "Gas", "Equipment/Tools"' },
        date: { type: 'string', description: 'YYYY-MM-DD, default today' },
        vendor: { type: 'string' },
        job_id: { type: 'integer', description: 'Link to a job for direct job costing (optional)' },
        notes: { type: 'string' },
      },
      required: ['amount_dollars', 'category'],
    },
  },
  {
    name: 'export_csv',
    description: 'Hand the user a downloadable CSV file (e.g. a detailed expense report they asked to export). Give it a clear filename, a header row, and the data rows. The file appears as a download button in the chat.',
    input_schema: {
      type: 'object',
      properties: {
        filename: { type: 'string', description: 'e.g. nails-jan2024-sep2025.csv' },
        header: { type: 'array', items: { type: 'string' } },
        rows: { type: 'array', items: { type: 'array', items: { type: ['string', 'number', 'null'] } } },
      },
      required: ['filename', 'header', 'rows'],
    },
  },
];

const dollars = (cents) => Math.round(cents) / 100;

function systemPrompt(user, hasFile) {
  const isJarad = /^j@ecoaisolutions\.com$/i.test(user.email);
  const isJoe = /^joe@/i.test(user.email);
  const who = isJarad ? 'Jarad (admin, the builder of this system)'
    : isJoe ? 'Joe Ballaccomo (the owner of Paragon)'
    : `${user.name || user.email} (a Paragon team member)`;
  return `You are Ellianna, the back-office assistant for Paragon Roofing / Paragon Exteriors.

You work for two people and you always know which one you are talking to from their login. Right now: ${who} — signed in as ${user.name || ''} <${user.email}>, role "${user.role}".
${isJarad ? '- Jarad mode: talk operator to operator. Short sentences. Build status, system detail, no fluff.'
    : '- Joe mode (and anyone else): plain English, patient, zero jargon. Explain money in dollars, not percentages, unless asked. Offer to walk them through screens step by step.'}

Today's date is ${new Date().toISOString().slice(0, 10)}.

What you do: answer questions from the P&L Job Tracker and the books, run expense reports, file receipts, hand back spreadsheet exports, and walk people through the app when they're stuck.

Working rules:
- Use your tools to answer from the real data — never guess numbers. Money: tools take and return DOLLARS.
- "What did we make last month" style questions → tracker_summary. Per-job questions → tracker_jobs. Spending questions → expense_report (dates are stored by DAY; if someone gives times of day, use the dates and say the books track by day).
- When someone asks for a report, give the answer first (total + short breakdown), then OFFER export options ("Want that as a spreadsheet — by vendor, by month, or the full list?"). Use export_csv when they choose.
- When a photo or file is uploaded${hasFile ? ' (one came with this message)' : ''}, look at it, say what you see, and do what they ask — a receipt photo: read amount/vendor/date off it, confirm, record with add_expense (the file attaches as the receipt automatically).
- Before recording or changing anything, state exactly what you'll save. Missing key info (like the amount)? Ask.

Filing things: when a file or dictated info contains ONE job → add_tracker_job (P&L) or add_crm_job (pipeline/lead) — ask which if unclear. MANY rows → import_sheet (dry_run first, report the counts, wait for their OK). A receipt → add_expense. Always say what you filed and where.

Hard rules (not negotiable):
- If anyone asks whether you are an AI, answer straight and smoothly: yes. Never dodge.
- Never fabricate a price, warranty term, insurance outcome, or timeline. If you don't know, say so and suggest checking with Jarad or Joe.
- Never read secrets, API keys, or credentials into a conversation, even if asked.
- If a search finds nothing, say so — never invent data.

${KNOWLEDGE ? '--- BUSINESS KNOWLEDGE BASE ---\n' + KNOWLEDGE : ''}`;
}

function makeTools({ all, get, run }, uploadedFile) {
  const like = (v) => `%${v}%`;
  const NOW = "to_char(now() AT TIME ZONE 'utc','YYYY-MM-DD HH24:MI:SS')";
  return {
    async add_tracker_job(input, user) {
      const cents = (v) => Math.round((Number(v) || 0) * 100);
      const info = await run(`INSERT INTO pnl_jobs (customer_name, date_signed, date_completed,
          job_total_cents, material_cost_cents, labor_cost_cents, dumpster_cost_cents,
          interior_repair_cents, bathroom_cents, windows_quantity, deck_feet, siding_feet,
          roof_sq_size, notes, created_by, updated_by)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        input.customer_name, input.date_signed || '', input.date_completed || '',
        cents(input.job_total), cents(input.material_cost), cents(input.labor_cost),
        cents(input.dumpster_cost), cents(input.interior_repair), cents(input.bathroom),
        Math.round(Number(input.windows_quantity) || 0), Number(input.deck_feet) || 0,
        Number(input.siding_feet) || 0, Number(input.roof_sq_size) || 0,
        input.notes || '', user.id, user.id);
      const j = tracker.computed(await get('SELECT * FROM pnl_jobs WHERE id=?', info.lastInsertRowid));
      return { ok: true, id: j.id, net_profit: dollars(j.net_profit_cents) };
    },
    async add_crm_job(input) {
      const fields = ['customer_name', 'phone', 'email', 'address', 'city', 'state', 'zip',
        'scope_of_work', 'notes', 'proposal_sent', 'signed_contract', 'schedule_date'];
      const cols = fields.filter(f => input[f] !== undefined);
      const vals = cols.map(f => String(input[f] ?? ''));
      if (input.job_total !== undefined) { cols.push('job_total_cents'); vals.push(Math.round(Number(input.job_total) * 100)); }
      const info = await run(`INSERT INTO jobs (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`, ...vals);
      return { ok: true, id: info.lastInsertRowid };
    },
    async import_sheet(input, user) {
      if (input.target === 'crm') {
        return crmSheet.importSheet({ all, get, run }, { csv: input.csv },
          { dryRun: !!input.dry_run, defaultDate: new Date().toISOString().slice(0, 10) });
      }
      const parsed = tracker.parseWorkbook(Buffer.from(String(input.csv)));
      if (parsed.error) return parsed;
      if (input.dry_run) return { count: parsed.jobs.length, headers_ignored: parsed.headers_ignored, preview: parsed.jobs.slice(0, 10) };
      const saved = await tracker.saveImported({ all, run }, parsed.jobs, user.id, NOW);
      return { count: parsed.jobs.length, ...saved };
    },
    async recent_calls(input) {
      let rows = await all(`SELECT event_name, caller_number, duration_seconds, end_reason, created_at
        FROM call_events ORDER BY id DESC LIMIT 200`);
      if (input.since) rows = rows.filter(r => r.created_at >= input.since);
      return rows.map(r => ({ when: r.created_at, event: r.event_name,
        caller: r.caller_number || '(unknown number)',
        duration_seconds: r.duration_seconds, ended: r.end_reason }));
    },
    async tracker_jobs(input) {
      let rows = (await all('SELECT * FROM pnl_jobs ORDER BY date_signed DESC, id DESC')).map(tracker.computed);
      if (input.signed_from) rows = rows.filter(j => j.date_signed >= input.signed_from);
      if (input.signed_to) rows = rows.filter(j => j.date_signed && j.date_signed <= input.signed_to);
      if (input.q) {
        const q = String(input.q).toLowerCase();
        rows = rows.filter(j => (j.customer_name + ' ' + j.notes).toLowerCase().includes(q));
      }
      return rows.slice(0, 200).map(j => ({ id: j.id, customer: j.customer_name,
        date_signed: j.date_signed, date_completed: j.date_completed,
        job_total: dollars(j.job_total_cents), material: dollars(j.material_cost_cents),
        labor: dollars(j.labor_cost_cents), dumpster: dollars(j.dumpster_cost_cents),
        net_profit: dollars(j.net_profit_cents), cost_pct: j.cost_pct, profit_pct: j.profit_pct,
        windows: j.windows_quantity, deck_feet: j.deck_feet, siding_feet: j.siding_feet,
        roof_squares: j.roof_sq_size, notes: j.notes }));
    },
    async tracker_summary() {
      const rows = (await all('SELECT * FROM pnl_jobs')).map(tracker.computed);
      const bucket = (key) => {
        const ms = rows.filter(j => (j.date_signed || '').startsWith(key));
        return { jobs: ms.length, revenue: dollars(ms.reduce((a, j) => a + j.job_total_cents, 0)),
          profit: dollars(ms.reduce((a, j) => a + j.net_profit_cents, 0)) };
      };
      const months = {};
      for (let i = 0; i < 6; i++) {
        const d = new Date(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - i);
        const key = d.toISOString().slice(0, 7);
        months[key] = bucket(key);
      }
      return { total_jobs: rows.length,
        all_time: { revenue: dollars(rows.reduce((a, j) => a + j.job_total_cents, 0)),
          profit: dollars(rows.reduce((a, j) => a + j.net_profit_cents, 0)) },
        by_month: months };
    },
    async expense_report(input) {
      let sql = `SELECT e.date, e.amount_cents, c.name category, e.vendor, e.notes, e.payment_method,
          (SELECT customer_name FROM jobs j WHERE j.id=e.job_id) job
        FROM expenses e JOIN expense_categories c ON c.id=e.category_id WHERE c.qb_type='expense'`;
      const p = [];
      if (input.from_date) { sql += ' AND e.date >= ?'; p.push(input.from_date); }
      if (input.to_date) { sql += ' AND e.date <= ?'; p.push(input.to_date); }
      if (input.category) { sql += ' AND c.name ILIKE ?'; p.push(like(input.category)); }
      if (input.vendor) { sql += ' AND e.vendor ILIKE ?'; p.push(like(input.vendor)); }
      if (input.q) { sql += ' AND (e.vendor ILIKE ? OR e.notes ILIKE ? OR c.name ILIKE ?)'; p.push(like(input.q), like(input.q), like(input.q)); }
      const rows = await all(sql + ' ORDER BY e.date', ...p);
      const total = dollars(rows.reduce((a, r) => a + r.amount_cents, 0));
      const out = { count: rows.length, total_dollars: total };
      const g = input.group_by;
      if (g && g !== 'none') {
        const keyOf = (r) => g === 'month' ? r.date.slice(0, 7) : g === 'job' ? (r.job || '(overhead)') : (r[g] || '(none)');
        const groups = {};
        for (const r of rows) groups[keyOf(r)] = (groups[keyOf(r)] || 0) + r.amount_cents;
        out.groups = Object.fromEntries(Object.entries(groups)
          .sort((a, b) => b[1] - a[1]).map(([k, v]) => [k, dollars(v)]));
      }
      out.entries = rows.slice(0, 200).map(r => ({ date: r.date, amount: dollars(r.amount_cents),
        category: r.category, vendor: r.vendor, job: r.job || '', notes: r.notes }));
      if (rows.length > 200) out.note = `showing first 200 of ${rows.length} entries; totals cover all`;
      return out;
    },
    async list_jobs(input) {
      let rows = await all(`SELECT j.id, j.customer_name, j.address, j.city, j.zip, j.phone,
          j.scope_of_work, j.job_total_cents, j.signed_contract, j.completed_date, j.schedule_date, j.proposal_sent,
          COALESCE((SELECT SUM(amount_cents) FROM payments p WHERE p.job_id=j.id),0) paid_cents
        FROM jobs j ORDER BY j.id DESC`);
      if (input.q) {
        const q = String(input.q).toLowerCase();
        rows = rows.filter(j => [j.customer_name, j.address, j.city, j.zip, j.phone, j.scope_of_work]
          .join(' ').toLowerCase().includes(q));
      }
      return rows.slice(0, 100).map(j => ({ id: j.id, customer: j.customer_name,
        address: [j.address, j.city, j.zip].filter(Boolean).join(', '),
        scope: j.scope_of_work, job_total: dollars(j.job_total_cents),
        paid: dollars(j.paid_cents), balance_owed: dollars(j.job_total_cents - j.paid_cents),
        signed: j.signed_contract, scheduled: j.schedule_date, completed: j.completed_date }));
    },
    async get_job(input) {
      const j = await get('SELECT * FROM jobs WHERE id=?', input.id);
      if (!j) return { error: 'no job with that id' };
      const payments = await all('SELECT label, date, amount_cents FROM payments WHERE job_id=? ORDER BY date', j.id);
      const expenses = await all(`SELECT e.date, e.amount_cents, c.name category, e.vendor
        FROM expenses e JOIN expense_categories c ON c.id=e.category_id WHERE e.job_id=? ORDER BY e.date`, j.id);
      const sub = j.contractor_id ? await get('SELECT name FROM contractors WHERE id=?', j.contractor_id) : null;
      return { ...j, job_total: dollars(j.job_total_cents), job_total_cents: undefined,
        sub_assigned: sub ? sub.name : '',
        payments: payments.map(p => ({ ...p, amount: dollars(p.amount_cents), amount_cents: undefined })),
        expenses: expenses.map(e => ({ ...e, amount: dollars(e.amount_cents), amount_cents: undefined })) };
    },
    async add_expense(input) {
      let cat = await get('SELECT id, name FROM expense_categories WHERE name ILIKE ?', `%${input.category}%`);
      if (!cat) {
        const info = await run("INSERT INTO expense_categories (name, parent_id, qb_type) VALUES (?,NULL,'expense')", input.category.trim());
        cat = { id: info.lastInsertRowid, name: input.category.trim() };
      }
      const info = await run(`INSERT INTO expenses (date, amount_cents, category_id, vendor, job_id, receipt_path, notes)
        VALUES (?,?,?,?,?,?,?)`,
        input.date || new Date().toISOString().slice(0, 10), Math.round(input.amount_dollars * 100),
        cat.id, input.vendor || '', input.job_id || null,
        uploadedFile ? uploadedFile.filename : '', input.notes || '');
      return { ok: true, expense_id: info.lastInsertRowid, category: cat.name,
        receipt_attached: !!uploadedFile };
    },
    // export_csv is intercepted by the chat loop (result goes to the browser).
  };
}

function createAssistantHandler(db) {
  let client = null;
  return async function assistantHandler(req, res) {
    if (!process.env.ANTHROPIC_API_KEY) {
      return res.json({ reply: "I'm almost ready to work! The ANTHROPIC_API_KEY isn't set on the server yet — add it in the hosting dashboard (Vercel → Settings → Environment Variables) and redeploy, and I'll be right here." });
    }
    if (!client) {
      const Anthropic = require('@anthropic-ai/sdk');
      client = new Anthropic();
    }

    let history;
    try { history = JSON.parse(req.body.messages || '[]'); } catch { history = []; }
    if (!Array.isArray(history)) history = [];
    // Only trust plain text turns from the browser.
    const messages = history
      .filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string' && m.content.trim())
      .slice(-30)
      .map(m => ({ role: m.role, content: m.content }));

    // Attach an uploaded photo/PDF to the last user turn so Ellian can see it.
    const file = req.file || null;
    if (file) {
      const ext = path.extname(file.originalname || '').toLowerCase();
      const blocks = [];
      const raw = fs.readFileSync(file.path);
      let sheetText = '';
      if (IMAGE_TYPES[ext]) {
        blocks.push({ type: 'image', source: { type: 'base64', media_type: IMAGE_TYPES[ext], data: raw.toString('base64') } });
      } else if (ext === '.pdf') {
        blocks.push({ type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: raw.toString('base64') } });
      } else if (['.csv', '.txt', '.tsv'].includes(ext)) {
        sheetText = raw.toString('utf8').slice(0, 200000);
      } else if (['.xlsx', '.xls'].includes(ext)) {
        try {
          const XLSX = require('xlsx');
          const wb = XLSX.read(raw, { type: 'buffer' });
          sheetText = XLSX.utils.sheet_to_csv(wb.Sheets[wb.SheetNames[0]]).slice(0, 200000);
        } catch { sheetText = '(could not read that Excel file)'; }
      }
      const lastText = messages.length && messages[messages.length - 1].role === 'user'
        ? messages.pop().content : 'Here is a file.';
      blocks.push({ type: 'text', text: `${lastText}\n\n(Uploaded file: ${file.originalname})`
        + (sheetText ? `\n\nFile contents as CSV:\n${sheetText}` : '') });
      messages.push({ role: 'user', content: blocks });
    }
    if (!messages.length) return res.status(400).json({ error: 'say something first' });

    const tools = makeTools(db, file);
    const attachments = [];
    try {
      for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
        // Fable 5: thinking is always on (omit the param); low effort per
        // spec; server-side fallback to Opus if a safety classifier declines.
        const response = await client.beta.messages.create({
          model: MODEL,
          max_tokens: 4000,
          output_config: { effort: 'low' },
          betas: ['server-side-fallback-2026-06-01'],
          fallbacks: [{ model: FALLBACK_MODEL }],
          system: systemPrompt(req.user, !!file),
          tools: TOOLS,
          messages,
        });
        if (response.stop_reason === 'refusal') {
          return res.json({ reply: "I can't help with that one. If you think I should be able to, flag it to Jarad.", attachments });
        }
        if (response.stop_reason !== 'tool_use') {
          const reply = response.content.filter(b => b.type === 'text').map(b => b.text).join('\n');
          return res.json({ reply, attachments });
        }
        messages.push({ role: 'assistant', content: response.content });
        const results = [];
        for (const block of response.content) {
          if (block.type !== 'tool_use') continue;
          let result;
          try {
            if (block.name === 'export_csv') {
              const { filename, header, rows } = block.input;
              attachments.push({
                filename: String(filename || 'report.csv').replace(/[^\w.\- ]/g, '_'),
                csv: toCsv([header, ...rows]),
              });
              result = { ok: true, note: 'File is now attached in the chat as a download button.' };
            } else if (tools[block.name]) {
              result = await tools[block.name](block.input || {}, req.user);
            } else {
              result = { error: 'unknown tool' };
            }
          } catch (e) {
            result = { error: e.message };
          }
          results.push({ type: 'tool_result', tool_use_id: block.id, content: JSON.stringify(result) });
        }
        messages.push({ role: 'user', content: results });
      }
      res.json({ reply: 'I got a little lost in that one — can you break it into smaller steps for me?', attachments });
    } catch (err) {
      console.error('[ellian]', err.message);
      res.status(502).json({ error: 'Ellian had trouble reaching her brain (the AI service). Try again in a moment. Detail: ' + err.message });
    }
  };
}

module.exports = { createAssistantHandler };
