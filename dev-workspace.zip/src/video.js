// Mux video — upload and playback for the back office (job walkthroughs,
// roof inspections, crew clips). Plain REST with basic auth; no SDK.
// Env: MUX_TOKEN_ID / MUX_TOKEN_SECRET (the Vercel Mux integration prefixes
// them prgbkv2_* — both names are accepted). Graceful 503 until set.
const TOKEN_ID = () => process.env.MUX_TOKEN_ID || process.env.prgbkv2_MUX_TOKEN_ID;
const TOKEN_SECRET = () => process.env.MUX_TOKEN_SECRET || process.env.prgbkv2_MUX_TOKEN_SECRET;

const configured = () => !!(TOKEN_ID() && TOKEN_SECRET());

async function mux(method, path, body) {
  const auth = Buffer.from(`${TOKEN_ID()}:${TOKEN_SECRET()}`).toString('base64');
  const r = await fetch('https://api.mux.com' + path, {
    method,
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = (data.error && (data.error.messages || []).join('; ')) || `Mux API ${r.status}`;
    const err = new Error(msg);
    err.status = r.status;
    throw err;
  }
  return data.data;
}

// Direct upload: browser PUTs the file straight to Mux; we only mint the URL.
const createUpload = (corsOrigin) => mux('POST', '/video/v1/uploads', {
  cors_origin: corsOrigin || '*',
  new_asset_settings: { playback_policy: ['public'], video_quality: 'basic' },
});

const getUpload = (id) => mux('GET', `/video/v1/uploads/${encodeURIComponent(id)}`);

const listAssets = () => mux('GET', '/video/v1/assets?limit=50');

const deleteAsset = (id) => mux('DELETE', `/video/v1/assets/${encodeURIComponent(id)}`);

module.exports = { configured, createUpload, getUpload, listAssets, deleteAsset };
