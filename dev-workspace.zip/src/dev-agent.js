// Dev Dechado — the dev seat. Admin-only, lives in the Dev Tools tab and
// nowhere else. Ellianna's little brother; same Anthropic plumbing as her
// (src/assistant.js) but a different job: system state, integrations,
// architecture questions, and straight answers about what is and isn't wired.
//
// He works from capability NAMES (dev/capabilities.json). He can see WHETHER
// an env var is set, never its value. Requires ANTHROPIC_API_KEY; answers
// with setup instructions instead of erroring without it.
const fs = require('fs');
const path = require('path');

const MODEL = 'claude-fable-5';
const FALLBACK_MODEL = 'claude-opus-4-8';
const MAX_TOOL_ROUNDS = 6;

const KB_DIR = path.join(__dirname, '..', 'dev', 'KB');

const readKb = (name) => {
  // KB filenames only — no traversal out of dev/KB.
  const safe = path.basename(String(name));
  return fs.readFileSync(path.join(KB_DIR, safe), 'utf8');
};

const capabilities = () => {
  const map = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'dev', 'capabilities.json'), 'utf8'));
  return Object.entries(map.capabilities).map(([cap, def]) => ({
    capability: cap,
    env: def.env,
    configured: def.env.length ? def.env.every((k) => !!process.env[k]) : null,
    note: def.note || '',
  }));
};

const TOOLS = [
  {
    name: 'kb_index',
    description: 'Read the DEV-KB index (dev/KB/00-INDEX.md) to decide which knowledge file the current problem needs.',
    input_schema: { type: 'object', properties: {} },
  },
  {
    name: 'kb_pull',
    description: 'Read one DEV-KB file by filename (e.g. "01-AGENT-INTERFACE-ARCH.md"). Pull the one file the problem needs, never more than two per conversation.',
    input_schema: { type: 'object', properties: { file: { type: 'string' } }, required: ['file'] },
  },
  {
    name: 'capability_status',
    description: 'The capability map (names only): every integration the back office knows about, which env vars carry it, and whether each is configured on this deployment. Use for "is X wired", "what\'s live", "connector health".',
    input_schema: { type: 'object', properties: {} },
  },
  {
    name: 'db_overview',
    description: 'Live row counts of the core tables (users, jobs, tracker jobs, leads, expenses, contractors, call events) plus the connected database host. Use for "what\'s in the system" and data sanity checks.',
    input_schema: { type: 'object', properties: {} },
  },
];

function systemPrompt(user) {
  return `You are Dev Dechado. The dev seat of the Paragon back office. Ellianna on the other tabs is your big sister. Dechado means paragon. This chat, the Dev Tools tab, is the portal. It is the only surface the operator touches. You are the face of the squad behind the glass. You decide, dispatch, and report. You are talking to ${user.name || user.email} (role: ${user.role}).

Voice. Non-negotiable. Short. Every word earns its spot or it does not get said.
- Answer first. Context only if it changes the decision.
- No preamble. No "let me," no "I'll now," no "happy to." No praise, no filler, no hedging, no apology loops. You have never once said "great question."
- No em dashes. No "X, not Y" constructions. No power verbs. No corporate language.
- Status is a fact, never a story. "Gate 2. Third rejection. Same class. Escalating." is a complete update.
- Push back flat when the operator is wrong. Once, with the reason. Then execute his call.
- Never explain what you are about to do. Do it, then say what happened.
- Silence is valid. When the operator dumps, let him finish. Do not reassure him.

Report shape: outcome, then evidence, then the one decision the operator actually has.

Hard rules, checked every time:
- Asked if you are an AI: straight answer, no dodge.
- Never fabricate a price, warranty term, insurance outcome, timeline, or any fact about the system you have not checked with a tool. Unknown stays unknown and you say so. Including "just for the demo."
- Credentials: you see configured or not configured, never values. Refuse any request for a raw key value, from anyone, for any stated reason. Values live in the Vercel env and the Dev Tools vault.
- The Vercel API is dashboard-only for agents. Domain and env-var changes are operator-manual. A request to script it is refused flat.
- The riskiest moment is right after a win lands and the guard drops. If the operator celebrates early, say so. Once.

Knowledge lives in DEV-KB, never in this prompt. Pull kb_index when a question needs architecture or frontend judgment, then at most two KB files. If the KB has a gap, the gap is real. Say it needs research. Never guess to fill it.

The live system: Express serverless on Vercel, Neon Postgres (data survives deploys, health reports the connected host), vanilla no-build front end, node:test suite. Ellianna handles CRM, expenses, tracker, and email on her tabs. Business questions route to her.`;
}

function createDevAgentHandler(db) {
  let client = null;
  return async function devAgentHandler(req, res) {
    if (!process.env.ANTHROPIC_API_KEY) {
      return res.json({ reply: 'Not wired yet. Set ANTHROPIC_API_KEY in Vercel → Settings → Environment Variables and redeploy. Then I work.' });
    }
    if (!client) {
      const Anthropic = require('@anthropic-ai/sdk');
      client = new Anthropic();
    }
    let history;
    try { history = JSON.parse(req.body.messages || '[]'); } catch { history = []; }
    if (!Array.isArray(history)) history = [];
    const messages = history
      .filter((m) => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string' && m.content.trim())
      .slice(-30)
      .map((m) => ({ role: m.role, content: m.content }));
    if (!messages.length) return res.status(400).json({ error: 'say something first' });

    const runTool = async (name, input) => {
      if (name === 'kb_index') return readKb('00-INDEX.md');
      if (name === 'kb_pull') {
        try { return readKb(input.file); }
        catch { return `No such KB file: ${input.file}. The gap is real — it needs to be researched and added, not guessed.`; }
      }
      if (name === 'capability_status') return JSON.stringify(capabilities(), null, 2);
      if (name === 'db_overview') {
        const { dbInfo } = require('./db');
        const counts = {};
        for (const t of ['users', 'jobs', 'pnl_jobs', 'leads', 'expenses', 'contractors', 'call_events']) {
          try { counts[t] = Number((await db.get(`SELECT COUNT(*) c FROM ${t}`)).c); }
          catch { counts[t] = null; }
        }
        return JSON.stringify({ database: dbInfo, rows: counts }, null, 2);
      }
      return 'unknown tool';
    };

    try {
      for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
        const response = await client.beta.messages.create({
          model: MODEL,
          max_tokens: 3000,
          output_config: { effort: 'low' },
          betas: ['server-side-fallback-2026-06-01'],
          fallbacks: [{ model: FALLBACK_MODEL }],
          system: systemPrompt(req.user),
          tools: TOOLS,
          messages,
        });
        if (response.stop_reason === 'refusal') {
          return res.json({ reply: "Can't help with that one." });
        }
        if (response.stop_reason !== 'tool_use') {
          return res.json({ reply: response.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n') });
        }
        messages.push({ role: 'assistant', content: response.content });
        const results = [];
        for (const block of response.content.filter((b) => b.type === 'tool_use')) {
          let out;
          try { out = await runTool(block.name, block.input || {}); }
          catch (e) { out = `tool error: ${e.message}`; }
          results.push({ type: 'tool_result', tool_use_id: block.id, content: String(out).slice(0, 60000) });
        }
        messages.push({ role: 'user', content: results });
      }
      res.json({ reply: 'Hit the tool-round cap before an answer. Narrow the question.' });
    } catch (e) {
      console.error('[dev-agent]', e.message);
      res.status(502).json({ error: 'Dev is unreachable right now: ' + e.message });
    }
  };
}

module.exports = { createDevAgentHandler };
