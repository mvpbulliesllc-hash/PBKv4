// Postgres data layer for Paragon CRM + Job P&L.
//  - Production (Vercel): pg Pool against DATABASE_URL (Neon).
//  - Local dev & tests: embedded PGlite (in-memory for ':memory:', on-disk
//    under data/pgdata otherwise) — same SQL dialect, no server needed.
// Design rules (from the brief):
//  1. A job is entered once; pipeline, costing, and P&L read the same record.
//  2. Every "list of things" is data, not schema.
//  3. Humans enter inputs, the system does math. All money is integer cents.
const path = require('path');

// SQLite stored dates as UTC text; keep the same text format so string
// comparisons and substr() reports keep working unchanged.
const NOW = "to_char(now() AT TIME ZONE 'utc','YYYY-MM-DD HH24:MI:SS')";
const TODAY = "to_char(now() AT TIME ZONE 'utc','YYYY-MM-DD')";
const NOW_PLUS_7D = "to_char(now() AT TIME ZONE 'utc' + interval '7 days','YYYY-MM-DD HH24:MI:SS')";

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS scope_types (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    unit TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS specialties (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS contractors (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    contact_name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    license_number TEXT DEFAULT '',
    license_expiry TEXT DEFAULT '',
    insurance_expiry TEXT DEFAULT '',
    insurance_doc TEXT DEFAULT '',
    w9_doc TEXT DEFAULT '',
    license_doc TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    legal_name TEXT DEFAULT '',
    entity_type TEXT DEFAULT '',
    address TEXT DEFAULT '',
    wc_expiry TEXT DEFAULT '',
    crew_size TEXT DEFAULT '',
    service_zips TEXT DEFAULT '',
    tin_enc TEXT DEFAULT '',
    bank_enc TEXT DEFAULT '',
    w9_signed_at TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS contractor_specialties (
    contractor_id INTEGER NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
    specialty_id INTEGER NOT NULL REFERENCES specialties(id) ON DELETE CASCADE,
    PRIMARY KEY (contractor_id, specialty_id)
  );

  CREATE TABLE IF NOT EXISTS dumpster_vendors (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    contact_info TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS dumpster_prices (
    id SERIAL PRIMARY KEY,
    vendor_id INTEGER NOT NULL REFERENCES dumpster_vendors(id) ON DELETE CASCADE,
    size_label TEXT NOT NULL,
    cost_cents INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS suppliers (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    branch_address TEXT DEFAULT '',
    account_number TEXT DEFAULT '',
    rep TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    materials_carried TEXT DEFAULT '',
    notes TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS jobs (
    id SERIAL PRIMARY KEY,
    customer_name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    address TEXT DEFAULT '',
    city TEXT DEFAULT '',
    state TEXT DEFAULT '',
    zip TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    scope_of_work TEXT DEFAULT '',
    contacted_date TEXT DEFAULT '',
    inspection_date TEXT DEFAULT '',
    proposal_sent TEXT DEFAULT '',
    signed_contract TEXT DEFAULT '',
    contractor_id INTEGER REFERENCES contractors(id) ON DELETE SET NULL,
    schedule_date TEXT DEFAULT '',
    completed_date TEXT DEFAULT '',
    job_total_cents INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (${TODAY})
  );

  CREATE TABLE IF NOT EXISTS job_scope (
    id SERIAL PRIMARY KEY,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    scope_type_id INTEGER NOT NULL REFERENCES scope_types(id),
    quantity DOUBLE PRECISION NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS payments (
    id SERIAL PRIMARY KEY,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    label TEXT NOT NULL DEFAULT 'Payment',
    date TEXT DEFAULT '',
    amount_cents INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS material_documents (
    id SERIAL PRIMARY KEY,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    supplier_id INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
    document_number TEXT DEFAULT '',
    doc_type TEXT NOT NULL DEFAULT 'Quote',
    ship_to TEXT DEFAULT '',
    activation_date TEXT DEFAULT '',
    close_date TEXT DEFAULT '',
    delivery_date TEXT DEFAULT '',
    fuel_surcharge_cents INTEGER NOT NULL DEFAULT 0,
    sales_tax_cents INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS material_lines (
    id SERIAL PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES material_documents(id) ON DELETE CASCADE,
    sku TEXT DEFAULT '',
    description TEXT DEFAULT '',
    quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    uom TEXT DEFAULT '',
    unit_price_cents INTEGER NOT NULL DEFAULT 0,
    trade_tag TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS expense_categories (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id INTEGER REFERENCES expense_categories(id) ON DELETE SET NULL,
    qb_type TEXT NOT NULL DEFAULT 'expense',
    UNIQUE (name, parent_id)
  );

  CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'office',
    contractor_id INTEGER REFERENCES contractors(id) ON DELETE SET NULL,
    job_id INTEGER REFERENCES jobs(id) ON DELETE SET NULL,
    active INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS team_members (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    role TEXT NOT NULL DEFAULT 'Member',
    notes TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS integrations (
    id SERIAL PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'api_key',
    name TEXT NOT NULL,
    value TEXT NOT NULL DEFAULT '',
    event TEXT DEFAULT 'job.created',
    notes TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS onboarding_invites (
    id SERIAL PRIMARY KEY,
    token TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    email TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    reject_reason TEXT DEFAULT '',
    data TEXT NOT NULL DEFAULT '{}',
    docs TEXT NOT NULL DEFAULT '{}',
    signatures TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (${NOW}),
    expires_at TEXT NOT NULL DEFAULT (${NOW_PLUS_7D}),
    submitted_at TEXT DEFAULT '',
    contractor_id INTEGER REFERENCES contractors(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS leads (
    id SERIAL PRIMARY KEY,
    external_id TEXT DEFAULT '',
    source TEXT NOT NULL DEFAULT '',
    property_address TEXT NOT NULL,
    address_norm TEXT NOT NULL,
    city TEXT DEFAULT '',
    state TEXT DEFAULT '',
    zip TEXT DEFAULT '',
    owner_first TEXT DEFAULT '',
    owner_last TEXT DEFAULT '',
    primary_phone TEXT DEFAULT '',
    phone_type TEXT DEFAULT '',
    mail_address TEXT DEFAULT '',
    mail_city TEXT DEFAULT '',
    mail_state TEXT DEFAULT '',
    mail_zip TEXT DEFAULT '',
    absentee INTEGER NOT NULL DEFAULT 0,
    year_built INTEGER,
    roof_age_min INTEGER,
    assessed_value INTEGER,
    bldg_desc TEXT DEFAULT '',
    enriched INTEGER NOT NULL DEFAULT 0,
    pipeline_stage TEXT NOT NULL DEFAULT 'scraped',
    assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
    last_touch_at TEXT DEFAULT '',
    next_action_at TEXT DEFAULT '',
    dnc INTEGER NOT NULL DEFAULT 0,
    score INTEGER NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (${NOW}),
    updated_at TEXT NOT NULL DEFAULT (${NOW}),
    UNIQUE (address_norm, zip)
  );

  CREATE INDEX IF NOT EXISTS idx_leads_stage ON leads(pipeline_stage);
  CREATE INDEX IF NOT EXISTS idx_leads_zip ON leads(zip);

  CREATE TABLE IF NOT EXISTS lead_contacts (
    id SERIAL PRIMARY KEY,
    lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    value TEXT NOT NULL,
    is_primary INTEGER NOT NULL DEFAULT 0,
    UNIQUE (lead_id, type, value)
  );

  CREATE TABLE IF NOT EXISTS lead_activities (
    id SERIAL PRIMARY KEY,
    lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    kind TEXT NOT NULL DEFAULT 'note',
    detail TEXT DEFAULT '',
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (${NOW})
  );

  CREATE TABLE IF NOT EXISTS lead_stage_history (
    id SERIAL PRIMARY KEY,
    lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    from_stage TEXT DEFAULT '',
    to_stage TEXT NOT NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (${NOW})
  );

  -- P&L Job Tracker: 1:1 with Joe's spreadsheet so his old data imports clean
  -- and exports open in Excel looking identical. Money is integer cents;
  -- net profit / cost % / profit % are computed on read, never stored.
  CREATE TABLE IF NOT EXISTS pnl_jobs (
    id SERIAL PRIMARY KEY,
    date_signed TEXT DEFAULT '',
    date_completed TEXT DEFAULT '',
    customer_name TEXT NOT NULL,
    job_total_cents INTEGER NOT NULL DEFAULT 0,
    interior_repair_cents INTEGER NOT NULL DEFAULT 0,
    bathroom_cents INTEGER NOT NULL DEFAULT 0,
    windows_quantity INTEGER NOT NULL DEFAULT 0,
    deck_feet DOUBLE PRECISION NOT NULL DEFAULT 0,
    siding_feet DOUBLE PRECISION NOT NULL DEFAULT 0,
    roof_sq_size DOUBLE PRECISION NOT NULL DEFAULT 0,
    material_cost_cents INTEGER NOT NULL DEFAULT 0,
    labor_cost_cents INTEGER NOT NULL DEFAULT 0,
    dumpster_cost_cents INTEGER NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (${NOW}),
    updated_at TEXT NOT NULL DEFAULT (${NOW})
  );

  -- 4-digit PIN login (Joe-proof: no password to forget).
  ALTER TABLE users ADD COLUMN IF NOT EXISTS pin_hash TEXT NOT NULL DEFAULT '';

  -- Phone-agent activity from the Hume EVI webhook (callback URL:
  -- /api/callbacks/hume). One row per event; raw payload kept for audit.
  CREATE TABLE IF NOT EXISTS call_events (
    id SERIAL PRIMARY KEY,
    event_name TEXT NOT NULL,
    chat_id TEXT DEFAULT '',
    chat_group_id TEXT DEFAULT '',
    caller_number TEXT DEFAULT '',
    duration_seconds INTEGER,
    end_reason TEXT DEFAULT '',
    payload TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (${NOW})
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id SERIAL PRIMARY KEY,
    date TEXT NOT NULL DEFAULT (${TODAY}),
    amount_cents INTEGER NOT NULL DEFAULT 0,
    category_id INTEGER NOT NULL REFERENCES expense_categories(id),
    vendor TEXT DEFAULT '',
    job_id INTEGER REFERENCES jobs(id) ON DELETE SET NULL,
    contractor_id INTEGER REFERENCES contractors(id) ON DELETE SET NULL,
    payment_method TEXT DEFAULT '',
    receipt_path TEXT DEFAULT '',
    notes TEXT DEFAULT ''
  );
`;

// Numeric result columns arrive as strings (int8/numeric) from the wire
// protocol; coerce them back to JS numbers so money math stays math.
const NUMERIC_OIDS = new Set([20, 1700]); // int8, numeric
function coerceRows(res) {
  const numeric = (res.fields || []).filter(f => NUMERIC_OIDS.has(f.dataTypeID)).map(f => f.name);
  if (numeric.length) {
    for (const row of res.rows) {
      for (const name of numeric) {
        const v = row[name];
        if (v !== null && v !== undefined) row[name] = Number(v);
      }
    }
  }
  return res;
}

// The app database is Neon Postgres, full stop. Marketplace integrations
// (Nile, Convex, Vercel Postgres, …) may stuff competing URLs into the env —
// scan the candidates, adopt ONLY a neon.tech URL (pooled preferred), and
// report which one so /api/health can prove what we're connected to.
function pickDatabaseUrl() {
  const CANDIDATES = ['DATABASE_URL', 'POSTGRES_URL', 'DATABASE_URL_UNPOOLED',
    'POSTGRES_PRISMA_URL', 'POSTGRES_URL_NON_POOLING'];
  const urls = CANDIDATES.map((k) => [k, process.env[k]]).filter(([, v]) => v);
  const pick = urls.find(([, v]) => /neon\.tech/.test(v) && /-pooler/.test(v))
    || urls.find(([, v]) => /neon\.tech/.test(v))
    || urls[0];
  return pick || [null, null];
}
const dbInfo = { source: null, host: null, driver: null };

function open(dbPath) {
  const [envVar, url] = pickDatabaseUrl();
  let backend, ready;
  if (url && dbPath === undefined) {
    dbInfo.source = envVar;
    try { dbInfo.host = new URL(url).hostname; } catch { dbInfo.host = 'unparseable'; }
    console.log(`[db] using ${envVar} → ${dbInfo.host}`);
    if (/neon\.tech/.test(url)) {
      // Neon from a serverless function: raw TCP pg flaps ("socket
      // disconnected before secure TLS", dead pooled sockets between
      // invocations). Neon's own driver runs each query as a stateless
      // HTTPS fetch — no sockets to die between invocations.
      const { Pool, neonConfig } = require('@neondatabase/serverless');
      neonConfig.webSocketConstructor = require('ws');
      neonConfig.poolQueryViaFetch = true;
      dbInfo.driver = 'neon-serverless';
      backend = new Pool({ connectionString: url, max: 3 });
      // The multi-statement schema DDL can't ride the single-statement HTTP
      // path — run it one statement at a time (no dollar-quoted bodies here).
      backend.execMulti = async (sql) => {
        for (const stmt of sql.split(/;\s*(?:\r?\n|$)/).map((s) => s.trim()).filter(Boolean)) {
          await backend.query(stmt);
        }
      };
    } else {
      dbInfo.driver = 'pg';
      const { Pool } = require('pg');
      backend = new Pool({
        connectionString: url,
        max: 3,                       // serverless: keep the pool tiny
        ssl: /localhost|127\.0\.0\.1/.test(url) ? false : { rejectUnauthorized: false },
      });
    }
  } else if (process.env.VERCEL) {
    // No DATABASE_URL on Vercel: don't crash the whole function at module
    // load (opaque FUNCTION_INVOCATION_FAILED). Serve readable errors instead.
    const err = new Error('DATABASE_URL is not set on this deployment — add it in the Vercel dashboard (Neon Postgres connection string) and redeploy.');
    return {
      query: async () => { throw err; },
      close: () => {},
      initError: err,
    };
  } else {
    const { PGlite } = require('@electric-sql/pglite');
    backend = dbPath === ':memory:'
      ? new PGlite()
      : new PGlite(path.join(__dirname, '..', 'data', 'pgdata'));
  }
  let initError = null;
  const TRANSIENT = /fetch failed|socket hang up|Connection terminated|ECONNRESET|ETIMEDOUT|57P01/i;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const initialize = async () => {
    // Multi-statement DDL: PGlite wants exec(); pg's simple query handles it;
    // the Neon HTTP path runs it statement-by-statement (execMulti).
    if (backend.execMulti) await backend.execMulti(SCHEMA);
    else if (backend.exec) await backend.exec(SCHEMA);
    else await backend.query(SCHEMA);
    await seed(backend);
    initError = null;
  };
  const attemptInit = async () => {
    // Neon autosuspends idle endpoints; the first request after a deploy can
    // land mid-wake and fail transiently. Retry inside one attempt…
    for (let i = 0; ; i++) {
      try { return await initialize(); }
      catch (e) {
        if (i < 2 && TRANSIENT.test(e.message)) { await sleep(1500 * (i + 1)); continue; }
        initError = e;
        throw e;
      }
    }
  };
  ready = attemptInit();
  // …a schema/connection failure must surface as a per-request error, never
  // as an unhandled rejection that kills the serverless function.
  ready.catch(() => {});

  const runQuery = async (text, params) => {
    // …and a failed init must NEVER poison the instance: re-attempt on the
    // next request instead of replaying the same rejected promise forever.
    try { await ready; }
    catch { ready = attemptInit(); ready.catch(() => {}); await ready; }
    try {
      return await backend.query(text, params);
    } catch (e) {
      if (!TRANSIENT.test(e.message)) throw e;
      await sleep(1200);                    // one retry rides out a DB wake-up
      return backend.query(text, params);
    }
  };

  return {
    query: async (text, params) => {
      const res = await runQuery(text, params);
      return coerceRows({ rows: res.rows || [], fields: res.fields || [],
        rowCount: res.rowCount ?? res.affectedRows ?? 0 });
    },
    close: () => (backend.end ? backend.end() : backend.close && backend.close()),
    get initError() { return initError; },
  };
}

async function seed(backend) {
  const q = (text, params) => backend.query(text, params);
  const has = async (t) => Number((await q(`SELECT COUNT(*) c FROM ${t}`)).rows[0].c) > 0;

  // Admin seed is per-user idempotent: a missing admin is (re)created on any
  // boot, but an existing row is NEVER touched — a password or PIN a user has
  // since changed survives every redeploy.
  {
    const crypto = require('crypto');
    const hash = (pw) => {
      const salt = crypto.randomBytes(8).toString('hex');
      return salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
    };
    // The universal admin password comes ONLY from the env (never committed).
    // Without it, existing rows still work — we just can't create missing ones.
    const pw = process.env.ADMIN_PASSWORD;
    const ADMINS = [
      ['j@ecoaisolutions.com', 'Jarad'],
      ['joe@paragonexteriorsnj.com', 'Joe Ballaccomo'],
      ['contact@paragonhomeimprovementco.com', 'Paragon Home Improvement'],
      ['hq@paragonhomeimprovementco.com', 'Paragon HQ'],
      ['elliana@paragonhomeimprovementco.com', 'Ellianna'],
      ['helpdeskclaims@paragonhomeimprovementco.com', 'Help Desk / Claims'],
      ['paragonexteriors.co@gmail.com', 'Paragon Exteriors'],
    ];
    if (pw) {
      for (const [email, name] of ADMINS) {
        const exists = (await q('SELECT 1 FROM users WHERE email=$1', [email])).rows.length;
        if (!exists) {
          await q('INSERT INTO users (email, name, password_hash, role) VALUES ($1,$2,$3,$4)',
            [email, name, hash(pw), 'admin']);
        }
      }
    } else if (!(await has('users'))) {
      console.warn('[seed] ADMIN_PASSWORD is not set — no admin accounts created on this empty database.');
    }
  }

  if (!(await has('scope_types'))) {
    for (const [name, unit] of [['Roof', 'SQ'], ['Siding', 'LF'], ['Deck', 'SF'],
      ['Windows', 'Qty'], ['Bathroom', 'Job'], ['Interior Repair', 'Job']]) {
      await q('INSERT INTO scope_types (name, unit) VALUES ($1,$2)', [name, unit]);
    }
  }

  if (!(await has('specialties'))) {
    for (const n of ['Roofing', 'Siding', 'Soffit', 'Windows', 'Decks', 'Interior', 'Bathroom']) {
      await q('INSERT INTO specialties (name) VALUES ($1)', [n]);
    }
  }

  if (!(await has('suppliers'))) {
    await q(`INSERT INTO suppliers (name, branch_address, account_number, materials_carried)
             VALUES ($1,$2,$3,$4)`,
      ['ABC Supply', 'Toms River, NJ', '2173114', 'Roofing, siding, soffit']);
  }

  if (!(await has('expense_categories'))) {
    const top = ['Gas', 'Trucks', 'Equipment/Tools', 'Insurance', 'Contractor Payment',
      'Supplier Payment', 'Promotional Payment', 'Marketing Expenses', 'Marketing Collateral',
      'Travel', 'Food', 'Cell Phone', 'Petty Cash', 'CC Fees', 'Office Expenses', 'EZ Pass',
      'Dumpster'];
    const ids = {};
    for (const n of top) {
      const r = await q("INSERT INTO expense_categories (name, parent_id, qb_type) VALUES ($1,NULL,'expense') RETURNING id", [n]);
      ids[n] = r.rows[0].id;
    }
    await q("INSERT INTO expense_categories (name, parent_id, qb_type) VALUES ($1,NULL,'equity')", ["Owner's Draw"]);
    await q("INSERT INTO expense_categories (name, parent_id, qb_type) VALUES ($1,NULL,'equity')", ['Partner Capital Investment']);
    for (const n of ['Google', 'Meta', 'Direct Mail']) {
      await q("INSERT INTO expense_categories (name, parent_id, qb_type) VALUES ($1,$2,'expense')", [n, ids['Marketing Expenses']]);
    }
  }
}

module.exports = { open, NOW, TODAY, NOW_PLUS_7D, dbInfo };
