// Ellianna's mailbox — she sends and receives as ELLIANNA_EMAIL
// (Ellianna@paragonhomeimprovementco.com). The domain's mail is hosted on
// Google Workspace, so this talks straight to Gmail: IMAP to read (inbox +
// sent), SMTP to send. Auth is a Google App Password for that mailbox
// (ELLIANNA_EMAIL_PASSWORD) — no OAuth dance, works from a serverless
// function. Connections are opened per request and closed; Vercel functions
// can't hold sockets between invocations anyway.
const ADDRESS = process.env.ELLIANNA_EMAIL || 'Ellianna@paragonhomeimprovementco.com';
const IMAP_HOST = process.env.ELLIANNA_IMAP_HOST || 'imap.gmail.com';
const SMTP_HOST = process.env.ELLIANNA_SMTP_HOST || 'smtp.gmail.com';

const configured = () => !!process.env.ELLIANNA_EMAIL_PASSWORD;

// Gmail's canonical folder names; [Gmail]/Sent Mail holds SMTP sends too.
const BOXES = { inbox: 'INBOX', sent: '[Gmail]/Sent Mail' };

async function withImap(fn) {
  const { ImapFlow } = require('imapflow');
  const client = new ImapFlow({
    host: IMAP_HOST, port: 993, secure: true, logger: false,
    auth: { user: ADDRESS, pass: process.env.ELLIANNA_EMAIL_PASSWORD },
  });
  await client.connect();
  try { return await fn(client); }
  finally { await client.logout().catch(() => {}); }
}

const addr = (a) => (a && a.length ? a.map(x => x.name ? `${x.name} <${x.address}>` : x.address).join(', ') : '');

async function listMessages(box = 'inbox', limit = 25) {
  const mailbox = BOXES[box] || BOXES.inbox;
  return withImap(async (client) => {
    const lock = await client.getMailboxLock(mailbox);
    try {
      const total = client.mailbox.exists;
      if (!total) return [];
      const first = Math.max(1, total - limit + 1);
      const out = [];
      for await (const msg of client.fetch(`${first}:${total}`, { uid: true, envelope: true, flags: true })) {
        out.push({
          uid: msg.uid,
          from: addr(msg.envelope.from),
          to: addr(msg.envelope.to),
          subject: msg.envelope.subject || '(no subject)',
          date: msg.envelope.date,
          message_id: msg.envelope.messageId,
          seen: msg.flags.has('\\Seen'),
        });
      }
      return out.reverse(); // newest first
    } finally { lock.release(); }
  });
}

async function getMessage(box, uid) {
  const mailbox = BOXES[box] || BOXES.inbox;
  return withImap(async (client) => {
    const lock = await client.getMailboxLock(mailbox);
    try {
      const dl = await client.download(String(uid), undefined, { uid: true });
      if (!dl) return null;
      const { simpleParser } = require('mailparser');
      const parsed = await simpleParser(dl.content);
      await client.messageFlagsAdd(String(uid), ['\\Seen'], { uid: true }).catch(() => {});
      return {
        uid: Number(uid),
        from: parsed.from ? parsed.from.text : '',
        to: parsed.to ? parsed.to.text : '',
        subject: parsed.subject || '(no subject)',
        date: parsed.date,
        message_id: parsed.messageId,
        references: parsed.references || [],
        text: parsed.text || (parsed.html ? parsed.html.replace(/<[^>]+>/g, ' ') : ''),
      };
    } finally { lock.release(); }
  });
}

async function send({ to, subject, text, inReplyTo, references }) {
  const nodemailer = require('nodemailer');
  const transport = nodemailer.createTransport({
    host: SMTP_HOST, port: 465, secure: true,
    auth: { user: ADDRESS, pass: process.env.ELLIANNA_EMAIL_PASSWORD },
  });
  const info = await transport.sendMail({
    from: `Ellianna — Paragon Home Improvement <${ADDRESS}>`,
    to, subject, text,
    inReplyTo: inReplyTo || undefined,
    references: references && references.length ? references : undefined,
  });
  return { message_id: info.messageId, accepted: info.accepted };
}

module.exports = { configured, ADDRESS, listMessages, getMessage, send };
