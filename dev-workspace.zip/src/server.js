// Paragon CRM + Job P&L — API + static server. Runs identically as a plain
// Express server (local dev) and as a Vercel serverless function (api/index.js).
// Data lives in Postgres (Neon via DATABASE_URL; embedded PGlite locally).
// All money in/out of the API is integer cents. Computed fields (status,
// balance owed, material cost, net profit) are calculated here, never entered.
const express = require('express');
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const { open, NOW, TODAY, NOW_PLUS_7D } = require('./db');
const { startStormWatch } = require('./storms');
const { scoreLead, normalizeAddress } = require('./lead-score');
const fs = require('fs');
const crmSheet = require('./crm-sheet');
const tracker = require('./tracker');
const { createAssistantHandler } = require('./assistant');

const AUTH_SECRET = process.env.AUTH_SECRET || 'dev-only-secret-change-me';
const sign = (id) => `${id}.${crypto.createHmac('sha256', AUTH_SECRET).update(String(id)).digest('hex')}`;
const signShort = (id, ttlMs) => {
  const exp = Date.now() + ttlMs;
  const mac = crypto.createHmac('sha256', AUTH_SECRET).update(`${id}.${exp}`).digest('hex');
  return `${id}.${exp}.${mac}`;
};
const verifyToken = (t) => {
  const parts = String(t || '').split('.');
  try {
    if (parts.length === 3) {           // short-lived SSO token: id.exp.mac
      const [id, exp, mac] = parts;
      if (Number(exp) < Date.now()) return null;
      const good = crypto.createHmac('sha256', AUTH_SECRET).update(`${id}.${exp}`).digest('hex');
      return crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(good)) ? Number(id) : null;
    }
    const [id, mac] = parts;            // long-lived integration token: id.mac
    if (!id || !mac) return null;
    const good = crypto.createHmac('sha256', AUTH_SECRET).update(id).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(good)) ? Number(id) : null;
  } catch { return null; }
};
const checkPassword = (pw, stored) => {
  const [salt, hash] = String(stored).split(':');
  try {
    return crypto.timingSafeEqual(crypto.scryptSync(pw, salt, 32), Buffer.from(hash, 'hex'));
  } catch { return false; }
};
const hashPassword = (pw) => {
  const salt = crypto.randomBytes(8).toString('hex');
  return salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
};

// AES-256-GCM for TIN / bank data at rest. Key from env; falls back to the
// auth secret in dev. Ciphertext format: iv:tag:data (hex).
const ENC_KEY = crypto.createHash('sha256').update(process.env.ENC_KEY || AUTH_SECRET).digest();
const encrypt = (text) => {
  if (!text) return '';
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  const ct = Buffer.concat([c.update(String(text), 'utf8'), c.final()]);
  return [iv.toString('hex'), c.getAuthTag().toString('hex'), ct.toString('hex')].join(':');
};
const decrypt = (blob) => {
  if (!blob) return '';
  const [iv, tag, ct] = blob.split(':').map(h => Buffer.from(h, 'hex'));
  const d = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(ct), d.final()]).toString('utf8');
};
const mask = (v) => v ? '****' + String(v).replace(/\D/g, '').slice(-4) : '';

const AGREEMENTS = [
  ['ica', 'Independent Contractor Agreement (NJ ABC test: contractor controls means and methods, operates an independently established business, and performs work outside Paragon\'s usual employ relationship; not an employee — no benefits, taxes, or withholding)', 'v1'],
  ['insurance', 'Insurance maintenance: contractor keeps General Liability and Workers Comp current for the engagement; a lapsed certificate means no job assignment', 'v1'],
  ['hicpa', 'NJ HICPA acknowledgment: contractor is registered under the NJ Contractors\' Registration Act and performs work per NJ HIC requirements', 'v1'],
  ['esign', 'Consent to electronic records and signatures (E-SIGN / UETA)', 'v1'],
  ['ach', 'Direct deposit authorization', 'v1'],
  ['privacy', 'Data and privacy notice: Paragon stores this information for contractor engagement and 1099 reporting', 'v1'],
];

function createApp(dbPath) {
  const db = open(dbPath);

  // '?' placeholders (kept from the SQLite era) → $1..$n for Postgres.
  const qmark = (sql) => { let i = 0; return sql.replace(/\?/g, () => '$' + (++i)); };
  const all = async (sql, ...p) => (await db.query(qmark(sql), p)).rows;
  const get = async (sql, ...p) => (await db.query(qmark(sql), p)).rows[0];
  const run = async (sql, ...p) => {
    const isInsert = /^\s*INSERT\b/i.test(sql);
    const res = await db.query(qmark(sql) + (isInsert ? ' RETURNING *' : ''), p);
    return { lastInsertRowid: isInsert ? res.rows[0]?.id : undefined, changes: res.rowCount };
  };
  const cents = (v) => Math.round(Number(v) || 0);

  const app = express();
  app.set('trust proxy', 1);
  // The UI may be served from a separate static host that calls this API
  // cross-origin. Credentials mode requires echoing the origin.
  app.use((req, res, next) => {
    res.set('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.set('Access-Control-Allow-Credentials', 'true');
    res.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type,Authorization');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });
  // rawBody is kept for webhook signature verification (Hume signs the
  // exact bytes, not the parsed JSON).
  app.use(express.json({ limit: '10mb', verify: (req, res, buf) => { req.rawBody = buf; } }));

  // Serverless filesystems are ephemeral outside /tmp.
  const uploadDir = process.env.VERCEL
    ? '/tmp/uploads' : path.join(__dirname, '..', 'data', 'uploads');
  const upload = multer({ dest: uploadDir });

  // Vercel Blob (BLOB_READ_WRITE_TOKEN) makes uploads survive redeploys —
  // serverless disk is ephemeral. Intake still lands on disk via multer;
  // persistUpload mirrors it to Blob under the same random filename (the
  // random name is the access guard), and /uploads redirects to the Blob URL.
  // Without the token (local dev) everything stays on disk as before.
  const blobToken = process.env.BLOB_READ_WRITE_TOKEN;
  const persistUpload = async (file) => {
    if (!blobToken || !file) return;
    const { put } = require('@vercel/blob');
    await put(`uploads/${file.filename}`, fs.createReadStream(file.path),
      { access: 'public', token: blobToken, addRandomSuffix: false,
        contentType: file.mimetype || 'application/octet-stream' });
  };

  // Async route helper: forward rejections to the error handler.
  const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

  // Public health probe: tells us WHY production is down instead of an
  // opaque platform error. No data, no auth.
  app.get('/api/health', h(async (req, res) => {
    try {
      await db.query('SELECT 1');
      const { dbInfo } = require('./db');
      // host/source prove WHICH database we're on (no credentials exposed) —
      // guards against marketplace integrations swapping the URL underneath us.
      res.json({ ok: true, db: 'up', host: dbInfo.host, source: dbInfo.source, driver: dbInfo.driver });
    } catch (e) {
      res.status(500).json({ ok: false, error: (db.initError && db.initError.message) || e.message });
    }
  }));

  // ---------- auth ----------
  const userById = (id) => get(`SELECT id, email, name, role, contractor_id, job_id, active,
    CASE WHEN pin_hash <> '' THEN 1 ELSE 0 END AS has_pin FROM users WHERE id=?`, id);

  app.post('/api/login', h(async (req, res) => {
    const u = await get('SELECT * FROM users WHERE email=? AND active=1', String(req.body.email || '').toLowerCase().trim());
    if (!u || !checkPassword(req.body.password || '', u.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    res.set('Set-Cookie', `auth=${sign(u.id)}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
    res.json(await userById(u.id));
  }));
  // 4-digit PIN login (Joe-proof). Rate-limited — a 4-digit space needs it.
  // Session cookie lasts a year: log in once per device, stay logged in.
  app.post('/api/login-pin', h(async (req, res, next) => rateLimit(req, res, next)), h(async (req, res) => {
    const pin = String(req.body.pin || '').trim();
    if (!/^\d{4,6}$/.test(pin)) return res.status(400).json({ error: 'PINs are 4 digits' });
    const users = await all("SELECT * FROM users WHERE active=1 AND pin_hash <> ''");
    const u = users.find(u => checkPassword(pin, u.pin_hash));
    if (!u) return res.status(401).json({ error: "That PIN doesn't match — try again" });
    res.set('Set-Cookie', `auth=${sign(u.id)}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=31536000`);
    res.json(await userById(u.id));
  }));
  app.post('/api/logout', (req, res) => {
    res.set('Set-Cookie', 'auth=; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=0');
    res.json({ ok: true });
  });

  // ---------- PUBLIC contractor onboarding (token is the only credential) ----------
  const rateBucket = new Map();
  const rateLimit = (req, res, next) => {
    const k = req.ip + ':' + Math.floor(Date.now() / 60000);
    const n = (rateBucket.get(k) || 0) + 1;
    rateBucket.set(k, n);
    if (rateBucket.size > 5000) rateBucket.clear();
    if (n > 60) return res.status(429).json({ error: 'slow down' });
    next();
  };
  const liveInvite = async (token) => {
    const inv = await get('SELECT * FROM onboarding_invites WHERE token=?', String(token || ''));
    if (!inv) return null;
    if (inv.status === 'approved') return { expired: true };
    if (inv.status !== 'submitted' && inv.expires_at < new Date().toISOString().replace('T', ' ').slice(0, 19)) return { expired: true };
    return inv;
  };
  // Never echo stored secrets back to the browser — masked only.
  const inviteOut = (inv) => {
    const data = JSON.parse(inv.data);
    if (data.tin_enc) { data.tin_masked = mask(decrypt(data.tin_enc)); delete data.tin_enc; }
    if (data.bank_enc) {
      const b = JSON.parse(decrypt(data.bank_enc));
      data.bank_masked = { bank_name: b.bank_name, account_type: b.account_type, account: mask(b.account) };
      delete data.bank_enc;
    }
    return { name: inv.name, status: inv.status, reject_reason: inv.reject_reason,
      data, docs: Object.keys(JSON.parse(inv.docs)), signatures: JSON.parse(inv.signatures).map(s => s.agreement),
      agreements: AGREEMENTS };
  };

  app.get('/api/onboard/:token', rateLimit, h(async (req, res) => {
    const inv = await liveInvite(req.params.token);
    if (!inv) return res.status(404).json({ error: 'invalid link' });
    if (inv.expired) return res.status(410).json({ error: 'link expired or already used' });
    res.json(inviteOut(inv));
  }));
  app.put('/api/onboard/:token', rateLimit, h(async (req, res) => {
    const inv = await liveInvite(req.params.token);
    if (!inv || inv.expired) return res.status(410).json({ error: 'invalid or expired link' });
    if (inv.status === 'submitted') return res.status(400).json({ error: 'already submitted — awaiting review' });
    const data = JSON.parse(inv.data);
    const b = req.body || {};
    for (const f of ['legal_name', 'dba', 'entity_type', 'address', 'city', 'state', 'zip',
      'phone', 'email', 'hic_number', 'trade_licenses', 'gl_expiry', 'wc_expiry', 'wc_exempt',
      'specialties', 'crew_size', 'service_zips']) {
      if (b[f] !== undefined) data[f] = b[f];
    }
    if (b.tin) { data.tin_enc = encrypt(b.tin.replace(/\D/g, '')); data.tin_type = b.tin_type || 'EIN'; }
    if (b.bank && b.bank.routing && b.bank.account) data.bank_enc = encrypt(JSON.stringify(b.bank));
    await run('UPDATE onboarding_invites SET data=? WHERE id=?', JSON.stringify(data), inv.id);
    if (b.sign && b.sign.agreement && b.sign.typed_name) {
      const sigs = JSON.parse(inv.signatures).filter(s => s.agreement !== b.sign.agreement);
      const version = (AGREEMENTS.find(a => a[0] === b.sign.agreement) || [])[2] || 'v1';
      sigs.push({ agreement: b.sign.agreement, version, name: b.sign.typed_name,
        ts: new Date().toISOString(), ip: req.ip });
      await run('UPDATE onboarding_invites SET signatures=? WHERE id=?', JSON.stringify(sigs), inv.id);
    }
    res.json(inviteOut(await get('SELECT * FROM onboarding_invites WHERE id=?', inv.id)));
  }));
  app.post('/api/onboard/:token/doc/:kind', rateLimit, h(async (req, res, next) => {
    const inv = await liveInvite(req.params.token);
    if (!inv || inv.expired || inv.status === 'submitted') return res.status(410).json({ error: 'invalid link' });
    req.invite = inv;
    next();
  }), (req, res, next) => upload.single('file')(req, res, next), h(async (req, res) => {
    const KINDS = ['drivers_license', 'hic_cert', 'trade_license', 'gl_cert', 'wc_cert', 'voided_check', 'w9_pdf'];
    if (!KINDS.includes(req.params.kind) || !req.file) return res.status(400).json({ error: 'bad upload' });
    await persistUpload(req.file);
    const docs = JSON.parse(req.invite.docs);
    docs[req.params.kind] = req.file.filename;
    await run('UPDATE onboarding_invites SET docs=? WHERE id=?', JSON.stringify(docs), req.invite.id);
    res.json({ ok: true, docs: Object.keys(docs) });
  }));
  app.post('/api/onboard/:token/submit', rateLimit, h(async (req, res) => {
    const inv = await liveInvite(req.params.token);
    if (!inv || inv.expired) return res.status(410).json({ error: 'invalid or expired link' });
    const data = JSON.parse(inv.data);
    const docs = JSON.parse(inv.docs);
    const sigs = JSON.parse(inv.signatures).map(s => s.agreement);
    const missing = [];
    if (!data.legal_name) missing.push('legal name');
    if (!data.tin_enc) missing.push('EIN or SSN');
    if (!data.address) missing.push('business address');
    if (!docs.drivers_license) missing.push('driver\'s license upload');
    if (!docs.gl_cert) missing.push('general liability certificate');
    if (!data.gl_expiry) missing.push('GL expiry date');
    if (!docs.wc_cert && !data.wc_exempt) missing.push('workers comp certificate or exemption');
    if (!sigs.includes('w9')) missing.push('W-9 certification signature');
    for (const [k, label] of AGREEMENTS.map(a => [a[0], a[1]])) {
      if (!sigs.includes(k)) missing.push('signature: ' + label.split(':')[0].split('(')[0].trim());
    }
    if (missing.length) return res.status(400).json({ error: 'incomplete', missing });
    await run(`UPDATE onboarding_invites SET status='submitted', submitted_at=${NOW} WHERE id=?`, inv.id);
    res.json({ ok: true, status: 'submitted' });
  }));

  // ---------- PUBLIC self-serve onboarding portal (/join) ----------
  // A dedicated door that gives access to onboarding and NOTHING else.
  // Anyone who wants a check (1099 contractor or vendor) signs up here;
  // their account gets the 'onboarding' role, which the auth gate below
  // locks out of every other endpoint.
  const startInvite = async (name, email, workerType) => {
    const existing = await get(
      "SELECT * FROM onboarding_invites WHERE LOWER(email)=? AND status IN ('pending','submitted') ORDER BY id DESC LIMIT 1",
      email);
    if (existing) return existing.token;
    const token = crypto.randomUUID();
    await run('INSERT INTO onboarding_invites (token, name, email, phone, data) VALUES (?,?,?,?,?)',
      token, name, email, '', JSON.stringify({ worker_type: workerType || 'contractor' }));
    return token;
  };
  const joinSession = (res, userId) =>
    res.set('Set-Cookie', `auth=${sign(userId)}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);

  app.get('/api/join/config', (req, res) =>
    res.json({ google_client_id: process.env.GOOGLE_CLIENT_ID || null }));

  app.post('/api/join/signup', rateLimit, h(async (req, res) => {
    const email = String(req.body.email || '').toLowerCase().trim();
    const name = String(req.body.name || '').trim();
    const workerType = req.body.worker_type === 'vendor' ? 'vendor' : 'contractor';
    if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ error: 'name and a real email required' });
    if (String(req.body.password || '').length < 6) return res.status(400).json({ error: 'password needs at least 6 characters' });
    try {
      const info = await run('INSERT INTO users (email, name, password_hash, role) VALUES (?,?,?,?)',
        email, name, hashPassword(req.body.password), 'onboarding');
      joinSession(res, info.lastInsertRowid);
    } catch {
      return res.status(400).json({ error: 'That email already has an account — use "I\'ve been here before" to log in.' });
    }
    const token = await startInvite(name, email, workerType);
    res.status(201).json({ link: '/onboard/' + token, worker_type: workerType });
  }));

  app.post('/api/join/login', rateLimit, h(async (req, res) => {
    const email = String(req.body.email || '').toLowerCase().trim();
    const u = await get('SELECT * FROM users WHERE email=? AND active=1', email);
    if (!u || !checkPassword(req.body.password || '', u.password_hash)) {
      return res.status(401).json({ error: "That email and password don't match" });
    }
    joinSession(res, u.id);
    const token = await startInvite(u.name || email, email, req.body.worker_type);
    res.json({ link: '/onboard/' + token });
  }));

  // Google Sign-In (only active when GOOGLE_CLIENT_ID is set in the env).
  app.post('/api/join/google', rateLimit, h(async (req, res) => {
    if (!process.env.GOOGLE_CLIENT_ID) return res.status(503).json({ error: 'Google sign-in is not set up yet' });
    const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(String(req.body.credential || '')));
    if (!r.ok) return res.status(401).json({ error: 'Google sign-in failed' });
    const info = await r.json();
    if (info.aud !== process.env.GOOGLE_CLIENT_ID || info.email_verified !== 'true') {
      return res.status(401).json({ error: 'Google sign-in failed' });
    }
    const email = String(info.email).toLowerCase();
    let u = await get('SELECT * FROM users WHERE email=?', email);
    if (!u) {
      const created = await run('INSERT INTO users (email, name, password_hash, role) VALUES (?,?,?,?)',
        email, info.name || email, hashPassword(crypto.randomBytes(16).toString('hex')), 'onboarding');
      u = await userById(created.lastInsertRowid);
    }
    joinSession(res, u.id);
    const token = await startInvite(u.name || email, email, req.body.worker_type);
    res.json({ link: '/onboard/' + token });
  }));

  // ---------- Hume EVI webhook (the phone agent's callback URL) ----------
  // PUBLIC endpoint, authenticated by Hume's HMAC signature:
  //   HMAC-SHA256(signing_key, `${rawBody}.${timestamp}`), hex, and the
  //   timestamp must be within 180s. Configure in the Hume EVI config:
  //   webhook URL = https://<host>/api/callbacks/hume  (events: chat_started,
  //   chat_ended). Requires HUME_WEBHOOK_SIGNING_KEY in the server env.
  app.post('/api/callbacks/hume', rateLimit, h(async (req, res) => {
    const key = process.env.HUME_WEBHOOK_SIGNING_KEY;
    if (!key) return res.status(503).json({ error: 'HUME_WEBHOOK_SIGNING_KEY is not set on this deployment' });
    const sig = String(req.headers['x-hume-ai-webhook-signature'] || '');
    const ts = String(req.headers['x-hume-ai-webhook-timestamp'] || '');
    if (!sig || !ts || Math.abs(Date.now() / 1000 - Number(ts)) > 180) {
      return res.status(401).json({ error: 'bad or stale signature' });
    }
    const expected = crypto.createHmac('sha256', key)
      .update(`${(req.rawBody || Buffer.from('')).toString('utf8')}.${ts}`).digest('hex');
    try {
      if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) throw new Error('nope');
    } catch { return res.status(401).json({ error: 'bad signature' }); }
    const b = req.body || {};
    await run(`INSERT INTO call_events (event_name, chat_id, chat_group_id, caller_number,
        duration_seconds, end_reason, payload) VALUES (?,?,?,?,?,?,?)`,
      String(b.event_name || 'unknown'), b.chat_id || '', b.chat_group_id || '',
      b.caller_number || '', b.duration_seconds ?? null, b.end_reason || '',
      JSON.stringify(b).slice(0, 100000));
    res.json({ ok: true });
  }));

  // Who am I, without the 401: the login screen probes the session on every
  // page load, and an anonymous 401 litters the browser console. This always
  // answers 200 — {user:null} when nobody is signed in.
  app.get('/api/session', h(async (req, res) => {
    const cookie = (req.headers.cookie || '').split(/;\s*/).find((c) => c.startsWith('auth='));
    const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const id = verifyToken(cookie ? cookie.slice(5) : bearer);
    const user = id && await userById(id);
    res.json({ user: user && user.active ? user : null });
  }));

  // Everything under /api (except login) requires a signed cookie or Bearer token.
  app.use('/api', h(async (req, res, next) => {
    if (req.path === '/login' || req.path === '/session' || req.path.startsWith('/onboard/')) return next();
    const cookie = (req.headers.cookie || '').split(/;\s*/).find(c => c.startsWith('auth='));
    const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const id = verifyToken(cookie ? cookie.slice(5) : bearer);
    const user = id && await userById(id);
    if (!user || !user.active) return res.status(401).json({ error: 'Login required' });
    // Onboarding-portal accounts see onboarding and NOTHING else.
    if (user.role === 'onboarding' && !['/me', '/logout'].includes(req.path)) {
      return res.status(403).json({ error: 'This account only has access to the onboarding portal.' });
    }
    req.user = user;
    next();
  }));
  app.get('/api/me', (req, res) => res.json(req.user));
  // Self-serve PIN: after the first password login anyone can set their own
  // 4-digit PIN and log in with just that from then on (password stays valid).
  app.post('/api/me/pin', h(async (req, res) => {
    const pin = String(req.body.pin || '').trim();
    if (!/^\d{4,6}$/.test(pin)) return res.status(400).json({ error: 'PINs are 4 digits' });
    await run('UPDATE users SET pin_hash=? WHERE id=?', hashPassword(pin), req.user.id);
    res.json({ ok: true });
  }));
  app.get('/api/token', (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'admin only' });
    res.json({ token: sign(req.user.id), usage: 'Authorization: Bearer <token>' });
  });
  app.get('/api/sso-token', (req, res) => {
    if (!['admin', 'office'].includes(req.user.role)) return res.status(403).json({ error: 'staff only' });
    res.json({ token: signShort(req.user.id, 5 * 60 * 1000) });
  });

  const requireRole = (...roles) => (req, res, next) =>
    roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'Forbidden for your role' });
  const staff = requireRole('admin', 'office');
  const adminOnly = requireRole('admin');

  app.use('/api/onboarding', staff);
  app.use('/api/1099', adminOnly);
  app.use('/api/pnl', adminOnly);
  app.use('/api/expenses', adminOnly);
  app.use('/api/expense-categories', adminOnly);
  app.use('/api/integrations', adminOnly);
  app.use('/api/dev-agent', adminOnly);
  app.use('/api/users', adminOnly);
  app.use('/api/team', adminOnly);
  app.use('/api/leads', staff);        // homeowner PII — never contractor/client visible
  app.use(['/api/contractors', '/api/suppliers', '/api/dumpster-vendors', '/api/dumpster-prices',
    '/api/scope-types', '/api/specialties', '/api/material-documents', '/api/material-lines',
    '/api/payments', '/api/scope', '/api/assistant', '/api/tracker', '/api/calls',
    '/api/ellianna', '/api/video'], staff);
  app.use('/api/jobs', (req, res, next) => {
    if (['admin', 'office'].includes(req.user.role)) return next();
    if (req.method !== 'GET') return res.status(403).json({ error: 'Read-only access' });
    next();
  });

  // ---------- onboarding admin (invite, review, approve/reject) ----------
  app.get('/api/onboarding', h(async (req, res) => {
    res.json((await all('SELECT * FROM onboarding_invites ORDER BY id DESC')).map(inv => ({
      id: inv.id, token: inv.token, name: inv.name, email: inv.email, phone: inv.phone,
      status: inv.status, reject_reason: inv.reject_reason, created_at: inv.created_at,
      expires_at: inv.expires_at, submitted_at: inv.submitted_at,
      ...inviteOut(inv),
      doc_files: JSON.parse(inv.docs),
      signature_records: JSON.parse(inv.signatures),
    })));
  }));
  app.post('/api/onboarding/invite', h(async (req, res) => {
    if (!req.body.name) return res.status(400).json({ error: 'name required' });
    const token = crypto.randomUUID();
    const info = await run('INSERT INTO onboarding_invites (token, name, email, phone) VALUES (?,?,?,?)',
      token, req.body.name, req.body.email || '', req.body.phone || '');
    const base = `${req.protocol}://${req.get('host')}`;
    res.status(201).json({ id: info.lastInsertRowid, token, link: `${base}/onboard/${token}` });
  }));
  app.post('/api/onboarding/:id/reject', h(async (req, res) => {
    await run(`UPDATE onboarding_invites SET status='pending', reject_reason=?,
         expires_at=${NOW_PLUS_7D} WHERE id=?`,
      req.body.reason || 'needs changes', req.params.id);
    res.json({ ok: true });
  }));
  app.post('/api/onboarding/:id/approve', h(async (req, res) => {
    const inv = await get('SELECT * FROM onboarding_invites WHERE id=?', req.params.id);
    if (!inv || inv.status !== 'submitted') return res.status(400).json({ error: 'not awaiting review' });
    const d = JSON.parse(inv.data);
    const docs = JSON.parse(inv.docs);
    const sigs = JSON.parse(inv.signatures);
    const w9 = sigs.find(s => s.agreement === 'ica') && d.tin_enc ? new Date().toISOString() : '';
    const info = await run(`INSERT INTO contractors
      (name, contact_name, phone, email, license_number, license_expiry, insurance_expiry,
       insurance_doc, w9_doc, license_doc, notes, legal_name, entity_type, address,
       wc_expiry, crew_size, service_zips, tin_enc, bank_enc, w9_signed_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      d.dba || d.legal_name, inv.name, d.phone || inv.phone, d.email || inv.email,
      d.hic_number || '', '', d.gl_expiry || '',
      docs.gl_cert || '', docs.w9_pdf || '', docs.hic_cert || '',
      `Onboarded ${inv.submitted_at}. ${d.trade_licenses ? 'Trade licenses: ' + d.trade_licenses : ''}`,
      d.legal_name, d.entity_type || '', [d.address, d.city, d.state, d.zip].filter(Boolean).join(', '),
      d.wc_expiry || (d.wc_exempt ? 'exempt' : ''), d.crew_size || '', d.service_zips || '',
      d.tin_enc || '', d.bank_enc || '', w9);
    const cid = info.lastInsertRowid;
    for (const sid of (Array.isArray(d.specialties) ? d.specialties : [])) {
      await run('INSERT INTO contractor_specialties (contractor_id, specialty_id) VALUES (?,?) ON CONFLICT DO NOTHING', cid, sid);
    }
    let login = null;
    const email = (d.email || inv.email || '').toLowerCase().trim();
    if (email) {
      const temp = crypto.randomBytes(6).toString('base64url');
      try {
        await run('INSERT INTO users (email, name, password_hash, role, contractor_id) VALUES (?,?,?,?,?)',
          email, d.legal_name || inv.name, hashPassword(temp), 'contractor', cid);
        login = { email, temp_password: temp };
      } catch (e) { login = { error: 'email already has a login' }; }
    }
    await run("UPDATE onboarding_invites SET status='approved', contractor_id=? WHERE id=?", cid, inv.id);
    res.json({ ok: true, contractor_id: cid, login,
      '1099_ready': !!(d.tin_enc && d.address && w9) });
  }));

  // ---------- 1099-NEC year-end export ----------
  app.get('/api/1099', h(async (req, res) => {
    const year = req.query.year || new Date().getFullYear();
    const rows = await all(`
      SELECT c.id, c.legal_name, c.name, c.address, c.tin_enc, c.w9_signed_at,
             COALESCE(SUM(e.amount_cents),0) paid_cents
      FROM contractors c
      JOIN expenses e ON e.contractor_id = c.id
      JOIN expense_categories cat ON cat.id = e.category_id AND cat.name='Contractor Payment'
      WHERE substr(e.date,1,4) = ?
      GROUP BY c.id HAVING COALESCE(SUM(e.amount_cents),0) >= 60000
      ORDER BY COALESCE(SUM(e.amount_cents),0) DESC`, String(year));
    if (req.query.format === 'csv') {
      const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
      const csv = ['Legal Name,TIN,Address,Total Paid,W9 On File',
        ...rows.map(r => [r.legal_name || r.name, r.tin_enc ? decrypt(r.tin_enc) : 'MISSING W-9',
          r.address, (r.paid_cents / 100).toFixed(2), r.w9_signed_at ? 'yes' : 'NO'].map(esc).join(','))
      ].join('\n');
      return res.type('text/csv').send(csv);
    }
    res.json(rows.map(r => ({ id: r.id, legal_name: r.legal_name || r.name, address: r.address,
      tin_masked: r.tin_enc ? mask(decrypt(r.tin_enc)) : '', w9_on_file: !!r.w9_signed_at,
      paid_cents: r.paid_cents, year: Number(year) })));
  }));

  // ---------- user management (Team tab) ----------
  app.get('/api/users', h(async (req, res) =>
    res.json(await all('SELECT id, email, name, role, contractor_id, job_id, active FROM users ORDER BY id'))));
  app.post('/api/users', h(async (req, res) => {
    const { email, name, role, contractor_id, job_id } = req.body;
    if (!email) return res.status(400).json({ error: 'email required' });
    const temp = crypto.randomBytes(6).toString('base64url');
    try {
      const info = await run(`INSERT INTO users (email, name, password_hash, role, contractor_id, job_id)
        VALUES (?,?,?,?,?,?)`, String(email).toLowerCase().trim(), name || '', hashPassword(temp),
        role || 'office', contractor_id || null, job_id || null);
      res.status(201).json({ ...await userById(info.lastInsertRowid), temp_password: temp });
    } catch (e) {
      res.status(400).json({ error: 'email already exists' });
    }
  }));
  app.put('/api/users/:id', h(async (req, res) => {
    const fields = ['name', 'role', 'contractor_id', 'job_id', 'active'];
    const cols = fields.filter(f => req.body[f] !== undefined);
    if (cols.length) await run(`UPDATE users SET ${cols.map(f => `${f}=?`).join(',')} WHERE id=?`,
      ...cols.map(f => req.body[f]), req.params.id);
    if (req.body.password) await run('UPDATE users SET password_hash=? WHERE id=?',
      hashPassword(req.body.password), req.params.id);
    if (req.body.pin !== undefined) {
      const pin = String(req.body.pin).trim();
      if (pin && !/^\d{4,6}$/.test(pin)) return res.status(400).json({ error: 'PIN must be 4 digits' });
      await run('UPDATE users SET pin_hash=? WHERE id=?', pin ? hashPassword(pin) : '', req.params.id);
    }
    res.json(await userById(req.params.id));
  }));
  app.delete('/api/users/:id', h(async (req, res) => {
    if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: "can't remove yourself" });
    await run('UPDATE users SET active=0 WHERE id=?', req.params.id);
    res.json({ ok: true });
  }));
  // Public wizard page — standalone, no app shell.
  app.get('/onboard/:token', (req, res) =>
    res.sendFile(path.join(__dirname, '..', 'public', 'onboard.html')));
  // Public self-serve onboarding door (Ellianna greets, auth, 1099 choice).
  app.get('/join', (req, res) =>
    res.sendFile(path.join(__dirname, '..', 'public', 'join.html')));

  app.use(express.static(path.join(__dirname, '..', 'public')));

  // Uploaded docs (receipts, licenses, onboarding files) are staff-only.
  app.use('/uploads', h(async (req, res, next) => {
    const cookie = (req.headers.cookie || '').split(/;\s*/).find(c => c.startsWith('auth='));
    const id = verifyToken(cookie ? cookie.slice(5) : '');
    const user = id && await get('SELECT role FROM users WHERE id=? AND active=1', id);
    if (!user || !['admin', 'office'].includes(user.role)) return res.status(403).send('staff only');
    next();
  }), h(async (req, res, next) => {
    if (!blobToken) return next();
    try {
      const { head } = require('@vercel/blob');
      const b = await head(`uploads/${decodeURIComponent(req.path.slice(1))}`, { token: blobToken });
      return res.redirect(b.url);
    } catch { return next(); } // not in Blob (old/local file) → disk fallback
  }), express.static(uploadDir));

  // ---------- derived job math ----------
  // Stages: Lead → Contacted → Inspection → Proposal → Signed → In Progress → Completed → Paid
  function jobStatus(j, paid) {
    if (j.completed_date) return paid ? 'Paid' : 'Completed';
    if (j.schedule_date) return 'In Progress';
    if (j.signed_contract) return 'Signed';
    if (j.proposal_sent) return 'Proposal';
    if (j.inspection_date) return 'Inspection';
    if (j.contacted_date) return 'Contacted';
    return 'Lead';
  }

  // Bulk computation: 3 grouped queries for ANY number of jobs (a per-job
  // loop was fine on embedded SQLite; over network Postgres it would be
  // thousands of round trips per list render).
  async function computedMaps() {
    const pay = new Map((await all('SELECT job_id, COALESCE(SUM(amount_cents),0) s FROM payments GROUP BY job_id'))
      .map(r => [r.job_id, r.s]));
    const mat = new Map((await all(`
      SELECT d.job_id, COALESCE(SUM(COALESCE(t.sub,0) + d.fuel_surcharge_cents + d.sales_tax_cents), 0) s
      FROM material_documents d
      LEFT JOIN (SELECT document_id, CAST(SUM(quantity * unit_price_cents) AS INTEGER) sub
                 FROM material_lines GROUP BY document_id) t ON t.document_id = d.id
      GROUP BY d.job_id`)).map(r => [r.job_id, r.s]));
    const expRows = await all(`
      SELECT e.job_id, c.name, COALESCE(SUM(e.amount_cents),0) s
      FROM expenses e JOIN expense_categories c ON c.id = e.category_id
      WHERE e.job_id IS NOT NULL AND c.qb_type='expense' GROUP BY e.job_id, c.name`);
    const exp = new Map();
    for (const r of expRows) {
      const m = exp.get(r.job_id) || { labor: 0, dumpster: 0, other: 0 };
      if (r.name === 'Contractor Payment') m.labor += r.s;
      else if (r.name === 'Dumpster') m.dumpster += r.s;
      else m.other += r.s;
      exp.set(r.job_id, m);
    }
    return { pay, mat, exp };
  }

  function computeJob(j, maps) {
    const payments = maps.pay.get(j.id) || 0;
    const material = maps.mat.get(j.id) || 0;
    const e = maps.exp.get(j.id) || { labor: 0, dumpster: 0, other: 0 };
    const totalCost = material + e.labor + e.dumpster + e.other;
    const netProfit = j.job_total_cents - totalCost;
    const balanceOwed = j.job_total_cents - payments;
    return {
      ...j,
      payments_cents: payments,
      balance_owed_cents: balanceOwed,
      material_cost_cents: material,
      labor_cost_cents: e.labor,
      dumpster_cost_cents: e.dumpster,
      other_cost_cents: e.other,
      total_cost_cents: totalCost,
      net_profit_cents: netProfit,
      margin_pct: j.job_total_cents ? +(netProfit / j.job_total_cents * 100).toFixed(1) : null,
      status: jobStatus(j, balanceOwed <= 0 && payments > 0),
    };
  }

  const withComputed = async (j) => computeJob(j, await computedMaps());

  // ---------- generic CRUD helper for reference tables ----------
  function crud(route, table, fields) {
    app.get(`/api/${route}`, h(async (req, res) => res.json(await all(`SELECT * FROM ${table} ORDER BY id`))));
    app.post(`/api/${route}`, h(async (req, res) => {
      const cols = fields.filter(f => req.body[f] !== undefined);
      const info = await run(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
        ...cols.map(f => req.body[f]));
      res.status(201).json(await get(`SELECT * FROM ${table} WHERE id=?`, info.lastInsertRowid));
    }));
    app.put(`/api/${route}/:id`, h(async (req, res) => {
      const cols = fields.filter(f => req.body[f] !== undefined);
      if (cols.length) await run(`UPDATE ${table} SET ${cols.map(f => `${f}=?`).join(',')} WHERE id=?`,
        ...cols.map(f => req.body[f]), req.params.id);
      res.json(await get(`SELECT * FROM ${table} WHERE id=?`, req.params.id));
    }));
    app.delete(`/api/${route}/:id`, h(async (req, res) => {
      await run(`DELETE FROM ${table} WHERE id=?`, req.params.id);
      res.json({ ok: true });
    }));
  }

  crud('scope-types', 'scope_types', ['name', 'unit']);
  crud('specialties', 'specialties', ['name']);
  crud('suppliers', 'suppliers', ['name', 'branch_address', 'account_number', 'rep', 'phone', 'materials_carried', 'notes']);
  crud('dumpster-vendors', 'dumpster_vendors', ['name', 'contact_info']);
  crud('dumpster-prices', 'dumpster_prices', ['vendor_id', 'size_label', 'cost_cents']);
  crud('expense-categories', 'expense_categories', ['name', 'parent_id', 'qb_type']);
  crud('team', 'team_members', ['name', 'email', 'phone', 'role', 'notes']);
  crud('integrations', 'integrations', ['kind', 'name', 'value', 'event', 'notes']);

  // Fire-and-forget outbound webhooks (Dev Tools tab).
  async function dispatchWebhooks(event, payload) {
    for (const w of await all("SELECT * FROM integrations WHERE kind='webhook' AND event=?", event)) {
      fetch(w.value, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event, data: payload }),
      }).catch(() => {});
    }
  }

  // ---------- contractors (with specialties + compliance flags) ----------
  async function contractorOut(c) {
    const today = new Date().toISOString().slice(0, 10);
    return {
      ...c,
      specialty_ids: (await all('SELECT specialty_id FROM contractor_specialties WHERE contractor_id=?', c.id))
        .map(r => r.specialty_id),
      insurance_lapsed: !!(c.insurance_expiry && c.insurance_expiry < today),
      license_lapsed: !!(c.license_expiry && c.license_expiry < today),
    };
  }
  const CONTRACTOR_FIELDS = ['name', 'contact_name', 'phone', 'email', 'license_number',
    'license_expiry', 'insurance_expiry', 'notes'];
  app.get('/api/contractors', h(async (req, res) =>
    res.json(await Promise.all((await all('SELECT * FROM contractors ORDER BY name')).map(contractorOut)))));
  app.post('/api/contractors', h(async (req, res) => {
    const cols = CONTRACTOR_FIELDS.filter(f => req.body[f] !== undefined);
    const info = await run(`INSERT INTO contractors (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
      ...cols.map(f => req.body[f]));
    await setSpecialties(info.lastInsertRowid, req.body.specialty_ids);
    const out = await contractorOut(await get('SELECT * FROM contractors WHERE id=?', info.lastInsertRowid));
    if (req.body.login_email) {
      const temp = crypto.randomBytes(6).toString('base64url');
      try {
        await run('INSERT INTO users (email, name, password_hash, role, contractor_id) VALUES (?,?,?,?,?)',
          String(req.body.login_email).toLowerCase().trim(), out.name, hashPassword(temp),
          'contractor', out.id);
        out.login = { email: req.body.login_email, temp_password: temp };
      } catch (e) { out.login = { error: 'email already exists' }; }
    }
    res.status(201).json(out);
  }));
  app.put('/api/contractors/:id', h(async (req, res) => {
    const cols = CONTRACTOR_FIELDS.filter(f => req.body[f] !== undefined);
    if (cols.length) await run(`UPDATE contractors SET ${cols.map(f => `${f}=?`).join(',')} WHERE id=?`,
      ...cols.map(f => req.body[f]), req.params.id);
    await setSpecialties(req.params.id, req.body.specialty_ids);
    res.json(await contractorOut(await get('SELECT * FROM contractors WHERE id=?', req.params.id)));
  }));
  app.delete('/api/contractors/:id', h(async (req, res) => {
    await run('DELETE FROM contractors WHERE id=?', req.params.id); res.json({ ok: true });
  }));
  async function setSpecialties(id, ids) {
    if (!Array.isArray(ids)) return;
    await run('DELETE FROM contractor_specialties WHERE contractor_id=?', id);
    for (const s of ids) {
      await run('INSERT INTO contractor_specialties (contractor_id, specialty_id) VALUES (?,?) ON CONFLICT DO NOTHING', id, s);
    }
  }
  app.post('/api/contractors/:id/docs/:kind', upload.single('file'), h(async (req, res) => {
    const col = { insurance: 'insurance_doc', w9: 'w9_doc', license: 'license_doc' }[req.params.kind];
    if (!col || !req.file) return res.status(400).json({ error: 'bad doc kind or missing file' });
    await persistUpload(req.file);
    await run(`UPDATE contractors SET ${col}=? WHERE id=?`, req.file.filename, req.params.id);
    res.json(await contractorOut(await get('SELECT * FROM contractors WHERE id=?', req.params.id)));
  }));

  // ---------- jobs ----------
  const JOB_FIELDS = ['customer_name', 'phone', 'email', 'address', 'city', 'state', 'zip',
    'notes', 'scope_of_work',
    'contacted_date', 'inspection_date',
    'proposal_sent', 'signed_contract', 'contractor_id', 'schedule_date', 'completed_date',
    'job_total_cents'];

  function jobScope(user) {
    if (user.role === 'contractor') return { sql: ' WHERE contractor_id=?', params: [user.contractor_id || -1] };
    if (user.role === 'client') return { sql: ' WHERE id=?', params: [user.job_id || -1] };
    return { sql: '', params: [] };
  }
  function limitJob(j, role) {
    if (role === 'contractor') {
      const { id, customer_name, address, scope_of_work, schedule_date, completed_date, status } = j;
      return { id, customer_name, address, scope_of_work, schedule_date, completed_date, status };
    }
    if (role === 'client') {
      const { id, customer_name, address, scope_of_work, schedule_date, completed_date, status,
        job_total_cents, payments_cents, balance_owed_cents } = j;
      return { id, customer_name, address, scope_of_work, schedule_date, completed_date, status,
        job_total_cents, payments_cents, balance_owed_cents };
    }
    return j;
  }

  // CRM sheet import/export ("CRM Outline" column layout the office uses).
  // Registered before /api/jobs/:id so "export.csv" isn't parsed as an id.
  // Staff-only: the export contains customer PII and money.
  const staffOnly = (req, res) =>
    ['admin', 'office'].includes(req.user.role) ? true : (res.status(403).json({ error: 'staff only' }), false);
  app.get('/api/jobs/export.csv', h(async (req, res) => {
    if (!staffOnly(req, res)) return;
    const rows = await crmSheet.buildExportRows({ all }, computeJob, await computedMaps());
    res.type('text/csv')
      .set('Content-Disposition', `attachment; filename="paragon-crm-${new Date().toISOString().slice(0, 10)}.csv"`)
      .send(crmSheet.toCsv(rows));
  }));
  app.get('/api/jobs/import-template.csv', h(async (req, res) => {
    if (!staffOnly(req, res)) return;
    res.type('text/csv')
      .set('Content-Disposition', 'attachment; filename="paragon-crm-template.csv"')
      .send(crmSheet.templateCsv());
  }));
  // Body: {csv: "..."} (or {rows:[...]}) + optional {dry_run:true} to preview.
  app.post('/api/jobs/import', h(async (req, res) => {
    if (!staffOnly(req, res)) return;
    const result = await crmSheet.importSheet({ all, get, run }, req.body,
      { dryRun: !!req.body.dry_run, defaultDate: new Date().toISOString().slice(0, 10) });
    if (result.error) return res.status(400).json(result);
    res.json(result);
  }));

  // Phone-agent call log (fed by the Hume webhook above).
  app.get('/api/calls', h(async (req, res) =>
    res.json(await all('SELECT id, event_name, chat_id, caller_number, duration_seconds, end_reason, created_at FROM call_events ORDER BY id DESC LIMIT 200'))));

  // Ellianna — back-office AI assistant (chat + optional photo/file upload).
  app.post('/api/assistant', upload.single('file'), createAssistantHandler({ all, get, run }));

  // Dev Dechado — the dev seat. Admin-only; his interface lives in Dev Tools.
  const { createDevAgentHandler } = require('./dev-agent');
  app.post('/api/dev-agent', createDevAgentHandler({ all, get, run }));

  // Mux video (staff): direct uploads from the browser, asset list, playback
  // IDs. Readable 503 until MUX_TOKEN_ID/MUX_TOKEN_SECRET are set.
  const video = require('./video');
  const videoReady = (req, res, next) => video.configured() ? next()
    : res.status(503).json({ error: 'Video is not connected yet — set MUX_TOKEN_ID and MUX_TOKEN_SECRET on the server.' });
  app.get('/api/video/status', (req, res) => res.json({ configured: video.configured() }));
  app.post('/api/video/uploads', videoReady, h(async (req, res) =>
    res.json(await video.createUpload(req.headers.origin || ''))));
  app.get('/api/video/uploads/:id', videoReady, h(async (req, res) =>
    res.json(await video.getUpload(req.params.id))));
  app.get('/api/video/assets', videoReady, h(async (req, res) =>
    res.json((await video.listAssets()).map((a) => ({
      id: a.id, status: a.status, duration: a.duration,
      created_at: a.created_at,
      playback_id: (a.playback_ids || []).length ? a.playback_ids[0].id : null,
      title: (a.meta && a.meta.title) || '',
    })))));
  app.delete('/api/video/assets/:id', videoReady, h(async (req, res) => {
    await video.deleteAsset(req.params.id);
    res.json({ ok: true });
  }));

  // Ellianna's mailbox — she sends/receives as Ellianna@paragonhomeimprovementco.com
  // (Google Workspace). Graceful 503 until ELLIANNA_EMAIL_PASSWORD (a Google
  // App Password for that mailbox) is set in the env.
  const email = require('./email');
  const emailReady = (req, res, next) => email.configured() ? next()
    : res.status(503).json({ error: `Ellianna's mailbox is not connected yet — set ELLIANNA_EMAIL_PASSWORD (Google App Password for ${email.ADDRESS}) on the server.` });
  app.get('/api/ellianna/email/status', (req, res) =>
    res.json({ configured: email.configured(), address: email.ADDRESS }));
  const emailBox = (req, res, next) => ['inbox', 'sent'].includes(req.params.box)
    ? next() : res.status(404).json({ error: 'unknown mailbox' });
  app.get('/api/ellianna/email/:box', emailBox, emailReady, h(async (req, res) =>
    res.json(await email.listMessages(req.params.box, Math.min(Number(req.query.limit) || 25, 100)))));
  app.get('/api/ellianna/email/:box/:uid', emailBox, emailReady, h(async (req, res) => {
    const msg = await email.getMessage(req.params.box, req.params.uid);
    if (!msg) return res.status(404).json({ error: 'message not found' });
    res.json(msg);
  }));
  app.post('/api/ellianna/email/send', emailReady, h(async (req, res) => {
    const { to, subject, body, in_reply_to, references } = req.body || {};
    if (!String(to || '').trim() || !String(body || '').trim()) {
      return res.status(400).json({ error: 'to and body are required' });
    }
    res.json(await email.send({ to: String(to).trim(), subject: String(subject || '').trim(),
      text: String(body), inReplyTo: in_reply_to, references }));
  }));

  // Ellianna's voice: Hume TTS playback of her replies. Staff-only (mounted
  // under /api/assistant). Graceful 503 until HUME_API_KEY is set in the env.
  app.post('/api/assistant/tts', h(async (req, res) => {
    if (!process.env.HUME_API_KEY) return res.status(503).json({ error: 'Voice is not set up yet (HUME_API_KEY missing on the server).' });
    const text = String(req.body.text || '').replace(/[*_#`]/g, '').slice(0, 1500);
    if (!text.trim()) return res.status(400).json({ error: 'nothing to say' });
    const r = await fetch('https://api.hume.ai/v0/tts/file', {
      method: 'POST',
      headers: { 'X-Hume-Api-Key': process.env.HUME_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        utterances: [{ text, description: 'Warm, upbeat, professional female office assistant. Clear and friendly.' }],
        format: { type: 'mp3' },
      }),
    });
    if (!r.ok) return res.status(502).json({ error: 'voice service error ' + r.status });
    res.type('audio/mpeg').send(Buffer.from(await r.arrayBuffer()));
  }));

  // ---------- P&L Job Tracker (Joe's spreadsheet, 1:1) ----------
  const TRACKER_MONEY = ['job_total_cents', 'interior_repair_cents', 'bathroom_cents',
    'material_cost_cents', 'labor_cost_cents', 'dumpster_cost_cents'];
  const trackerBody = (b) => Object.fromEntries(tracker.FIELDS
    .filter(f => b[f] !== undefined)
    .map(f => [f, TRACKER_MONEY.includes(f) ? cents(b[f])
      : f === 'windows_quantity' ? Math.round(Number(b[f]) || 0)
      : ['deck_feet', 'siding_feet', 'roof_sq_size'].includes(f) ? Number(b[f]) || 0
      : String(b[f] ?? '').trim()]));

  app.get('/api/tracker/jobs', h(async (req, res) =>
    res.json((await all('SELECT * FROM pnl_jobs ORDER BY date_signed DESC, id DESC')).map(tracker.computed))));
  app.post('/api/tracker/jobs', h(async (req, res) => {
    const f = trackerBody(req.body);
    if (!f.customer_name) return res.status(400).json({ error: 'customer_name required' });
    const cols = Object.keys(f);
    const info = await run(`INSERT INTO pnl_jobs (${cols.join(',')}, created_by, updated_by)
      VALUES (${cols.map(() => '?').join(',')},?,?)`, ...cols.map(c => f[c]), req.user.id, req.user.id);
    res.status(201).json(tracker.computed(await get('SELECT * FROM pnl_jobs WHERE id=?', info.lastInsertRowid)));
  }));
  app.put('/api/tracker/jobs/:id', h(async (req, res) => {
    const f = trackerBody(req.body);
    const cols = Object.keys(f);
    if (cols.length) await run(`UPDATE pnl_jobs SET ${cols.map(c => `${c}=?`).join(',')},
      updated_by=?, updated_at=${NOW} WHERE id=?`, ...cols.map(c => f[c]), req.user.id, req.params.id);
    const row = await get('SELECT * FROM pnl_jobs WHERE id=?', req.params.id);
    if (!row) return res.status(404).json({ error: 'not found' });
    res.json(tracker.computed(row));
  }));
  app.delete('/api/tracker/jobs/:id', h(async (req, res) => {
    await run('DELETE FROM pnl_jobs WHERE id=?', req.params.id); res.json({ ok: true });
  }));

  // Dashboard numbers: this month + a 6-month profit chart, from date_signed.
  app.get('/api/tracker/summary', h(async (req, res) => {
    const rows = (await all('SELECT * FROM pnl_jobs')).map(tracker.computed);
    const month = new Date().toISOString().slice(0, 7);
    const inMonth = rows.filter(j => (j.date_signed || '').startsWith(month));
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - i);
      const key = d.toISOString().slice(0, 7);
      const ms = rows.filter(j => (j.date_signed || '').startsWith(key));
      months.push({ month: key, jobs: ms.length,
        revenue_cents: ms.reduce((a, j) => a + j.job_total_cents, 0),
        profit_cents: ms.reduce((a, j) => a + j.net_profit_cents, 0) });
    }
    res.json({
      month,
      jobs_this_month: inMonth.length,
      revenue_this_month_cents: inMonth.reduce((a, j) => a + j.job_total_cents, 0),
      profit_this_month_cents: inMonth.reduce((a, j) => a + j.net_profit_cents, 0),
      months,
      total_jobs: rows.length,
    });
  }));

  // Import: multipart file (.xlsx/.csv) or JSON {csv}. dry_run previews only.
  app.post('/api/tracker/import', upload.single('file'), h(async (req, res) => {
    const buffer = req.file ? fs.readFileSync(req.file.path)
      : req.body.csv ? Buffer.from(String(req.body.csv)) : null;
    if (!buffer) return res.status(400).json({ error: 'no file received' });
    const parsed = tracker.parseWorkbook(buffer);
    if (parsed.error) return res.status(400).json(parsed);
    const dryRun = String(req.body.dry_run || '') === 'true' || req.body.dry_run === true;
    const preview = {
      count: parsed.jobs.length,
      headers_matched: parsed.headers_matched,
      headers_ignored: parsed.headers_ignored,
      jobs: parsed.jobs.slice(0, 100).map(tracker.computed),
    };
    if (dryRun) return res.json(preview);
    const saved = await tracker.saveImported({ all, run }, parsed.jobs, req.user.id, NOW);
    res.json({ ...preview, ...saved });
  }));

  app.get('/api/tracker/export.xlsx', h(async (req, res) => {
    const rows = await all('SELECT * FROM pnl_jobs ORDER BY date_signed, id');
    res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
      .set('Content-Disposition', `attachment; filename="Paragon Jobs ${new Date().toISOString().slice(0, 10)}.xlsx"`)
      .send(tracker.buildWorkbook(rows));
  }));

  app.get('/api/jobs', h(async (req, res) => {
    const sc = jobScope(req.user);
    const [rows, maps] = await Promise.all([
      all('SELECT * FROM jobs' + sc.sql + ' ORDER BY id DESC', ...sc.params), computedMaps()]);
    res.json(rows.map(j => limitJob(computeJob(j, maps), req.user.role)));
  }));
  app.get('/api/jobs/:id', h(async (req, res) => {
    const j = await get('SELECT * FROM jobs WHERE id=?', req.params.id);
    if (!j) return res.status(404).json({ error: 'not found' });
    if (req.user.role === 'contractor' && j.contractor_id !== req.user.contractor_id)
      return res.status(403).json({ error: 'not your job' });
    if (req.user.role === 'client' && j.id !== req.user.job_id)
      return res.status(403).json({ error: 'not your job' });
    if (['contractor', 'client'].includes(req.user.role))
      return res.json(limitJob(await withComputed(j), req.user.role));
    res.json({
      ...await withComputed(j),
      scope: await all(`SELECT js.*, st.name, st.unit FROM job_scope js
                  JOIN scope_types st ON st.id = js.scope_type_id WHERE js.job_id=?`, j.id),
      payment_list: await all('SELECT * FROM payments WHERE job_id=? ORDER BY date, id', j.id),
      material_documents: await Promise.all(
        (await all('SELECT * FROM material_documents WHERE job_id=?', j.id)).map(docOut)),
      expenses: await all(`SELECT e.*, c.name category FROM expenses e
                     JOIN expense_categories c ON c.id=e.category_id
                     WHERE e.job_id=? ORDER BY e.date`, j.id),
    });
  }));
  app.post('/api/jobs', h(async (req, res) => {
    if (!req.body.customer_name) return res.status(400).json({ error: 'customer_name required' });
    const cols = JOB_FIELDS.filter(f => req.body[f] !== undefined);
    const info = await run(`INSERT INTO jobs (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
      ...cols.map(f => f === 'job_total_cents' ? cents(req.body[f]) : req.body[f]));
    const job = await withComputed(await get('SELECT * FROM jobs WHERE id=?', info.lastInsertRowid));
    dispatchWebhooks('job.created', job);
    res.status(201).json(job);
  }));
  app.put('/api/jobs/:id', h(async (req, res) => {
    const cols = JOB_FIELDS.filter(f => req.body[f] !== undefined);
    if (cols.length) await run(`UPDATE jobs SET ${cols.map(f => `${f}=?`).join(',')} WHERE id=?`,
      ...cols.map(f => f === 'job_total_cents' ? cents(req.body[f]) : req.body[f]), req.params.id);
    res.json(await withComputed(await get('SELECT * FROM jobs WHERE id=?', req.params.id)));
  }));
  app.delete('/api/jobs/:id', h(async (req, res) => {
    await run('DELETE FROM jobs WHERE id=?', req.params.id); res.json({ ok: true });
  }));

  // scope lines & payments
  app.post('/api/jobs/:id/scope', h(async (req, res) => {
    const info = await run('INSERT INTO job_scope (job_id, scope_type_id, quantity) VALUES (?,?,?)',
      req.params.id, req.body.scope_type_id, req.body.quantity || 0);
    res.status(201).json(await get('SELECT * FROM job_scope WHERE id=?', info.lastInsertRowid));
  }));
  app.delete('/api/scope/:id', h(async (req, res) => { await run('DELETE FROM job_scope WHERE id=?', req.params.id); res.json({ ok: true }); }));
  app.post('/api/jobs/:id/payments', h(async (req, res) => {
    const info = await run('INSERT INTO payments (job_id, label, date, amount_cents) VALUES (?,?,?,?)',
      req.params.id, req.body.label || 'Payment', req.body.date || '', cents(req.body.amount_cents));
    res.status(201).json(await get('SELECT * FROM payments WHERE id=?', info.lastInsertRowid));
  }));
  app.delete('/api/payments/:id', h(async (req, res) => { await run('DELETE FROM payments WHERE id=?', req.params.id); res.json({ ok: true }); }));

  // ---------- material documents ----------
  async function docOut(d) {
    const lines = (await all('SELECT * FROM material_lines WHERE document_id=? ORDER BY id', d.id))
      .map(l => ({ ...l, amount_cents: Math.round(l.quantity * l.unit_price_cents) }));
    const subtotal = lines.reduce((a, l) => a + l.amount_cents, 0);
    return { ...d, lines, subtotal_cents: subtotal,
      total_cents: subtotal + d.fuel_surcharge_cents + d.sales_tax_cents };
  }
  const DOC_FIELDS = ['job_id', 'supplier_id', 'document_number', 'doc_type', 'ship_to',
    'activation_date', 'close_date', 'delivery_date', 'fuel_surcharge_cents', 'sales_tax_cents'];
  app.get('/api/material-documents/:id', h(async (req, res) => {
    const d = await get('SELECT * FROM material_documents WHERE id=?', req.params.id);
    if (!d) return res.status(404).json({ error: 'not found' });
    res.json(await docOut(d));
  }));
  app.post('/api/material-documents', h(async (req, res) => {
    if (!req.body.job_id) return res.status(400).json({ error: 'job_id required' });
    const cols = DOC_FIELDS.filter(f => req.body[f] !== undefined);
    const info = await run(`INSERT INTO material_documents (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
      ...cols.map(f => f.endsWith('_cents') ? cents(req.body[f]) : req.body[f]));
    for (const l of (req.body.lines || [])) await insertLine(info.lastInsertRowid, l);
    res.status(201).json(await docOut(await get('SELECT * FROM material_documents WHERE id=?', info.lastInsertRowid)));
  }));
  app.put('/api/material-documents/:id', h(async (req, res) => {
    const cols = DOC_FIELDS.filter(f => req.body[f] !== undefined);
    if (cols.length) await run(`UPDATE material_documents SET ${cols.map(f => `${f}=?`).join(',')} WHERE id=?`,
      ...cols.map(f => f.endsWith('_cents') ? cents(req.body[f]) : req.body[f]), req.params.id);
    res.json(await docOut(await get('SELECT * FROM material_documents WHERE id=?', req.params.id)));
  }));
  app.delete('/api/material-documents/:id', h(async (req, res) => {
    await run('DELETE FROM material_documents WHERE id=?', req.params.id); res.json({ ok: true });
  }));
  app.post('/api/material-documents/:id/lines', h(async (req, res) => {
    const id = await insertLine(req.params.id, req.body);
    res.status(201).json(await get('SELECT * FROM material_lines WHERE id=?', id));
  }));
  app.delete('/api/material-lines/:id', h(async (req, res) => {
    await run('DELETE FROM material_lines WHERE id=?', req.params.id); res.json({ ok: true });
  }));
  async function insertLine(docId, l) {
    return (await run(`INSERT INTO material_lines (document_id, sku, description, quantity, uom, unit_price_cents, trade_tag)
                VALUES (?,?,?,?,?,?,?)`,
      docId, l.sku || '', l.description || '', l.quantity || 0, l.uom || '',
      cents(l.unit_price_cents), l.trade_tag || '')).lastInsertRowid;
  }

  // ---------- expenses ----------
  app.get('/api/expenses', h(async (req, res) => {
    const { month, category_id, job_id } = req.query;
    let sql = `SELECT e.*, c.name category, c.qb_type FROM expenses e
               JOIN expense_categories c ON c.id=e.category_id WHERE 1=1`;
    const p = [];
    if (month) { sql += " AND substr(e.date,1,7)=?"; p.push(month); }
    if (category_id) { sql += ' AND e.category_id=?'; p.push(category_id); }
    if (job_id) { sql += ' AND e.job_id=?'; p.push(job_id); }
    res.json(await all(sql + ' ORDER BY e.date DESC, e.id DESC', ...p));
  }));
  app.post('/api/expenses', upload.single('receipt'), h(async (req, res) => {
    const b = req.body;
    if (!b.category_id) return res.status(400).json({ error: 'category_id required' });
    await persistUpload(req.file);
    const info = await run(`INSERT INTO expenses (date, amount_cents, category_id, vendor, job_id, contractor_id, payment_method, receipt_path, notes)
                      VALUES (?,?,?,?,?,?,?,?,?)`,
      b.date || new Date().toISOString().slice(0, 10), cents(b.amount_cents), b.category_id,
      b.vendor || '', b.job_id || null, b.contractor_id || null, b.payment_method || '',
      req.file ? req.file.filename : '', b.notes || '');
    res.status(201).json(await get('SELECT * FROM expenses WHERE id=?', info.lastInsertRowid));
  }));
  app.delete('/api/expenses/:id', h(async (req, res) => {
    await run('DELETE FROM expenses WHERE id=?', req.params.id); res.json({ ok: true });
  }));

  // QuickBooks phase 1: clean CSV export with category parity.
  app.get('/api/expenses/export.csv', h(async (req, res) => {
    const rows = await all(`SELECT e.date, e.amount_cents, c.name category,
        (SELECT name FROM expense_categories p WHERE p.id=c.parent_id) parent,
        c.qb_type, e.vendor, e.payment_method, e.notes,
        (SELECT customer_name FROM jobs j WHERE j.id=e.job_id) job
      FROM expenses e JOIN expense_categories c ON c.id=e.category_id ORDER BY e.date`);
    const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = ['Date,Amount,Category,Parent Category,QB Account Type,Vendor,Payment Method,Job,Notes',
      ...rows.map(r => [r.date, (r.amount_cents / 100).toFixed(2), r.category, r.parent || '',
        r.qb_type === 'equity' ? 'Equity' : 'Expense', r.vendor, r.payment_method, r.job || '', r.notes]
        .map(esc).join(','))].join('\n');
    res.type('text/csv').send(csv);
  }));

  // ---------- P&L view (one row per job, filterable by completed date) ----------
  app.get('/api/pnl', h(async (req, res) => {
    const { from, to } = req.query;
    let jobs = await all("SELECT * FROM jobs WHERE completed_date <> '' ORDER BY completed_date");
    if (from) jobs = jobs.filter(j => j.completed_date >= from);
    if (to) jobs = jobs.filter(j => j.completed_date <= to);
    const maps = await computedMaps();
    const rows = jobs.map(j => computeJob(j, maps));
    const sum = (k) => rows.reduce((a, r) => a + r[k], 0);
    res.json({
      rows,
      totals: {
        job_total_cents: sum('job_total_cents'),
        material_cost_cents: sum('material_cost_cents'),
        labor_cost_cents: sum('labor_cost_cents'),
        dumpster_cost_cents: sum('dumpster_cost_cents'),
        other_cost_cents: sum('other_cost_cents'),
        net_profit_cents: sum('net_profit_cents'),
      },
    });
  }));

  // ---------- lead pipeline (staged assessor → enriched → worked leads) ----------
  const LEAD_STAGES = ['scraped', 'enriched', 'emailed', 'called', 'contacted',
    'appointment', 'estimate', 'installed'];
  const LEAD_SIDE_STAGES = ['dead', 'dnc'];   // terminal, reachable from any stage

  const leadContacts = (id) => all('SELECT * FROM lead_contacts WHERE lead_id=? ORDER BY is_primary DESC, id', id);
  const leadHasType = async (id, types) => !!(await get(
    `SELECT 1 x FROM lead_contacts WHERE lead_id=? AND type IN (${types.map(() => '?').join(',')}) LIMIT 1`, id, ...types));

  async function moveStage(lead, to, userId) {
    if (![...LEAD_STAGES, ...LEAD_SIDE_STAGES].includes(to)) return { error: 'unknown stage: ' + to };
    if (to === lead.pipeline_stage) return { ok: true };
    if (to === 'emailed' && !(await leadHasType(lead.id, ['email']))) return { error: 'no email on file — cannot enter emailed' };
    if (to === 'called' && !(await leadHasType(lead.id, ['mobile', 'landline']))) return { error: 'no phone on file — cannot enter called' };
    if (lead.dnc && ['emailed', 'called'].includes(to)) return { error: 'lead is DNC — outbound blocked' };
    await run(`UPDATE leads SET pipeline_stage=?, dnc=CASE WHEN ?='dnc' THEN 1 ELSE dnc END,
         last_touch_at=${NOW}, updated_at=${NOW} WHERE id=?`, to, to, lead.id);
    await run('INSERT INTO lead_stage_history (lead_id, from_stage, to_stage, user_id) VALUES (?,?,?,?)',
      lead.id, lead.pipeline_stage, to, userId || null);
    await run('INSERT INTO lead_activities (lead_id, kind, detail, user_id) VALUES (?,?,?,?)',
      lead.id, 'stage', `${lead.pipeline_stage} → ${to}`, userId || null);
    return { ok: true };
  }

  app.get('/api/leads', h(async (req, res) => {
    const { stage, zip, source, q, enriched, assigned_to, min_roof_age, limit, offset } = req.query;
    let sql = `SELECT l.*,
        EXISTS(SELECT 1 FROM lead_contacts c WHERE c.lead_id=l.id AND c.type='email') has_email,
        EXISTS(SELECT 1 FROM lead_contacts c WHERE c.lead_id=l.id AND c.type IN ('mobile','landline')) has_phone
      FROM leads l WHERE 1=1`;
    const p = [];
    if (stage) { sql += ' AND l.pipeline_stage=?'; p.push(stage); }
    if (zip) { sql += ' AND l.zip=?'; p.push(zip); }
    if (source) { sql += ' AND l.source=?'; p.push(source); }
    if (enriched !== undefined && enriched !== '') { sql += ' AND l.enriched=?'; p.push(enriched === 'Y' || enriched === '1' ? 1 : 0); }
    if (assigned_to) { sql += ' AND l.assigned_to=?'; p.push(assigned_to); }
    if (min_roof_age) { sql += ' AND l.roof_age_min >= ?'; p.push(Number(min_roof_age)); }
    if (q) {
      sql += ` AND (l.property_address ILIKE ? OR l.owner_first||' '||l.owner_last ILIKE ?
               OR l.primary_phone LIKE ? OR l.zip LIKE ?)`;
      const like = `%${q}%`;
      p.push(like, like, like, like);
    }
    sql += ' ORDER BY l.score DESC, l.id LIMIT ? OFFSET ?';
    p.push(Math.min(Number(limit) || 500, 2000), Number(offset) || 0);
    res.json(await all(sql, ...p));
  }));

  app.get('/api/leads/counts', h(async (req, res) => {
    const rows = await all('SELECT pipeline_stage stage, COUNT(*) n FROM leads GROUP BY pipeline_stage');
    res.json({
      total: rows.reduce((a, r) => a + r.n, 0),
      enriched_total: (await get('SELECT COUNT(*) c FROM leads WHERE enriched=1')).c,
      dnc_total: (await get('SELECT COUNT(*) c FROM leads WHERE dnc=1')).c,
      stages: Object.fromEntries([...LEAD_STAGES, ...LEAD_SIDE_STAGES].map(s =>
        [s, (rows.find(r => r.stage === s) || {}).n || 0])),
      sources: await all('SELECT source, COUNT(*) n FROM leads GROUP BY source ORDER BY n DESC'),
      zips: await all('SELECT zip, COUNT(*) n FROM leads GROUP BY zip ORDER BY n DESC'),
    });
  }));

  app.get('/api/leads/:id', h(async (req, res) => {
    const l = await get('SELECT * FROM leads WHERE id=?', req.params.id);
    if (!l) return res.status(404).json({ error: 'not found' });
    res.json({
      ...l,
      contacts: await leadContacts(l.id),
      stage_history: await all(`SELECT h.*, u.name user_name FROM lead_stage_history h
        LEFT JOIN users u ON u.id=h.user_id WHERE h.lead_id=? ORDER BY h.id`, l.id),
      activities: await all(`SELECT a.*, u.name user_name FROM lead_activities a
        LEFT JOIN users u ON u.id=a.user_id WHERE a.lead_id=? ORDER BY a.id DESC`, l.id),
    });
  }));

  // Editable workflow fields only — property/contact facts come from import,
  // never hand-typed (no fabricated data).
  app.put('/api/leads/:id', h(async (req, res) => {
    const l = await get('SELECT * FROM leads WHERE id=?', req.params.id);
    if (!l) return res.status(404).json({ error: 'not found' });
    const fields = ['notes', 'assigned_to', 'next_action_at'];
    const cols = fields.filter(f => req.body[f] !== undefined);
    if (cols.length) await run(`UPDATE leads SET ${cols.map(f => `${f}=?`).join(',')}, updated_at=${NOW} WHERE id=?`,
      ...cols.map(f => req.body[f]), l.id);
    if (req.body.dnc !== undefined && !!req.body.dnc !== !!l.dnc) {
      await run(`UPDATE leads SET dnc=?, updated_at=${NOW} WHERE id=?`, req.body.dnc ? 1 : 0, l.id);
      await run('INSERT INTO lead_activities (lead_id, kind, detail, user_id) VALUES (?,?,?,?)',
        l.id, 'dnc', req.body.dnc ? 'marked DO NOT CONTACT' : 'DNC cleared', req.user.id);
    }
    res.json(await get('SELECT * FROM leads WHERE id=?', l.id));
  }));

  app.post('/api/leads/:id/stage', h(async (req, res) => {
    const l = await get('SELECT * FROM leads WHERE id=?', req.params.id);
    if (!l) return res.status(404).json({ error: 'not found' });
    const r = await moveStage(l, String(req.body.stage || ''), req.user.id);
    if (r.error) return res.status(400).json(r);
    res.json(await get('SELECT * FROM leads WHERE id=?', l.id));
  }));

  app.post('/api/leads/:id/activities', h(async (req, res) => {
    const l = await get('SELECT * FROM leads WHERE id=?', req.params.id);
    if (!l) return res.status(404).json({ error: 'not found' });
    const kind = String(req.body.kind || 'note');
    if (l.dnc && ['call', 'email'].includes(kind)) return res.status(400).json({ error: 'lead is DNC — outbound blocked' });
    const info = await run('INSERT INTO lead_activities (lead_id, kind, detail, user_id) VALUES (?,?,?,?)',
      l.id, kind, String(req.body.detail || ''), req.user.id);
    await run(`UPDATE leads SET last_touch_at=${NOW}, updated_at=${NOW} WHERE id=?`, l.id);
    res.status(201).json(await get('SELECT * FROM lead_activities WHERE id=?', info.lastInsertRowid));
  }));

  // Bulk import (admin). Upserts by address_norm+zip; parses contact arrays
  // into lead_contacts; writes truthful stage history (scraped, then enriched).
  app.post('/api/leads/import', adminOnly, h(async (req, res) => {
    const rows = Array.isArray(req.body.rows) ? req.body.rows : [];
    if (!rows.length) return res.status(400).json({ error: 'rows[] required' });
    let created = 0, updated = 0, skipped = 0;
    for (const r of rows) {
      const street = String(r.property_address || '').trim();
      const zip = String(r.zip || '').trim();
      if (!street || !zip) { skipped++; continue; }
      const norm = normalizeAddress(street);
      const mailNorm = normalizeAddress(r.mail_address);
      // Absentee = mailing address is a different place. Prefix match absorbs
      // assessor quirks like "167 PARK AVE-ORCHARD ST" vs mail "167 Park Ave".
      const sameAddr = mailNorm && (norm.startsWith(mailNorm) || mailNorm.startsWith(norm));
      const mailZip = String(r.mail_zip || '').trim();
      const absentee = r.absentee !== undefined && r.absentee !== ''
        ? (r.absentee === true || r.absentee === 'Y' || r.absentee === 1 ? 1 : 0)
        : ((mailNorm && (!sameAddr || (mailZip && mailZip !== zip))) ? 1 : 0);
      const contacts = [];
      const push = (type, list) => String(list || '').split(';').map(s => s.trim()).filter(Boolean)
        .forEach(v => contacts.push([type, v]));
      push('mobile', r.mobiles); push('landline', r.landlines); push('email', r.emails);
      if (r.primary_phone && !contacts.some(([, v]) => v === String(r.primary_phone).trim())) {
        contacts.unshift([String(r.phone_type || '').toLowerCase() === 'landline' ? 'landline' : 'mobile',
          String(r.primary_phone).trim()]);
      }
      const enriched = contacts.length > 0 ? 1 : 0;
      const score = scoreLead({ roof_age_min: r.roof_age_min, assessed_value: r.assessed_value, absentee });
      const vals = {
        external_id: r.external_id || '', source: r.source || '',
        property_address: street, address_norm: norm,
        city: r.city || '', state: r.state || '', zip,
        owner_first: r.owner_first || '', owner_last: r.owner_last || '',
        primary_phone: r.primary_phone || '', phone_type: r.phone_type || '',
        mail_address: r.mail_address || '', mail_city: r.mail_city || '',
        mail_state: r.mail_state || '', mail_zip: r.mail_zip || '',
        absentee, year_built: Number(r.year_built) || null,
        roof_age_min: Number(r.roof_age_min) || null,
        assessed_value: Number(r.assessed_value) || null,
        bldg_desc: r.bldg_desc || '', enriched, score,
      };
      const existing = await get('SELECT * FROM leads WHERE address_norm=? AND zip=?', norm, zip);
      let leadId;
      if (existing) {
        // Refresh facts; never regress workflow state or stage.
        vals.enriched = Math.max(vals.enriched, existing.enriched);
        const keys = Object.keys(vals);
        await run(`UPDATE leads SET ${keys.map(k => `${k}=?`).join(',')},
             updated_at=${NOW} WHERE id=?`,
          ...keys.map(k => vals[k]), existing.id);
        leadId = existing.id;
        updated++;
      } else {
        const keys = Object.keys(vals);
        const info = await run(`INSERT INTO leads (${keys.join(',')}, pipeline_stage)
          VALUES (${keys.map(() => '?').join(',')}, 'scraped')`, ...keys.map(k => vals[k]));
        leadId = info.lastInsertRowid;
        // Truthful history: everything lands in scraped, then promotes.
        await run("INSERT INTO lead_stage_history (lead_id, from_stage, to_stage) VALUES (?,'','scraped')", leadId);
        created++;
      }
      let ci = 0;
      for (const [type, value] of contacts) {
        await run(`INSERT INTO lead_contacts (lead_id, type, value, is_primary) VALUES (?,?,?,?)
                   ON CONFLICT DO NOTHING`, leadId, type, value,
          (value === String(r.primary_phone || '').trim() || (type === 'email' && ci === 0 && !r.primary_phone)) ? 1 : 0);
        ci++;
      }
      const now = await get('SELECT * FROM leads WHERE id=?', leadId);
      if (enriched && now.pipeline_stage === 'scraped') await moveStage(now, 'enriched', req.user.id);
    }
    res.json({ created, updated, skipped,
      totals: await get('SELECT COUNT(*) total, COALESCE(SUM(enriched),0) enriched FROM leads') });
  }));

  // ---------- storm watch (South Jersey roof-damage alerts) ----------
  // Serverless has no background loop: refresh lazily when the data is stale.
  const affectedCount = async (zips) => zips.length
    ? (await get(`SELECT COUNT(*) c FROM jobs WHERE zip IN (${zips.map(() => '?').join(',')})`, ...zips)).c
    : 0;
  const storms = startStormWatch({
    background: !process.env.VERCEL,
    onNew: async (a) => dispatchWebhooks('storm.alert', { ...a, affected_leads: await affectedCount(a.zips) }),
  });
  app.get('/api/storms', h(async (req, res) => {
    if (storms.ageMs() > 15 * 60 * 1000) await storms.refresh();
    res.json({
      alerts: await Promise.all(storms.getAlerts().map(async a => ({ ...a, affected_leads: await affectedCount(a.zips) }))),
      checked: new Date().toISOString(),
    });
  }));
  app.post('/api/storms/refresh', h(async (req, res) => {
    await storms.refresh();
    res.json({ ok: true });
  }));

  // Which integration keys are configured (names only, never values).
  app.get('/api/integration-status', requireRole('admin'), (req, res) => {
    const KEYS = ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'FIRECRAWL_API_KEY', 'EXA_API_KEY',
      'PARALLEL_API_KEY', 'HUME_API_KEY', 'HUME_WEBHOOK_SIGNING_KEY', 'DAILY_API_KEY',
      'CAL_COM_API_KEY', 'CLOUDFLARE_API_TOKEN', 'COMPOSIO_API_KEY',
      'BROWSERBASE_API_KEY', 'NIMBLE_API_KEY', 'CLAY_API_KEY', 'CARGO_API_KEY',
      'SLACK_BOT_TOKEN', 'ELLIANNA_EMAIL_PASSWORD'];
    res.json(KEYS.map(k => ({ key: k, configured: !!process.env[k] })));
  });

  // JSON errors, never HTML stack pages.
  app.use((err, req, res, next) => {
    console.error('[api]', err.message);
    res.status(500).json({ error: err.message });
  });

  app.locals.db = db;
  app.locals.storms = storms;
  return app;
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createApp().listen(port, () => console.log(`Paragon CRM running on http://localhost:${port}`));
}

module.exports = { createApp };
