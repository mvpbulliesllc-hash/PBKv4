// CSV + spreadsheet-value helpers for the CRM import/export.
// The target audience pastes from Excel/Google Sheets, so parsing is
// forgiving: quoted fields, $1,234.56 money, 6/1/2026 dates all work.

function csvEscape(v) {
  const s = String(v ?? '');
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

// rows: array of arrays. \r\n line endings so Excel opens it cleanly.
function toCsv(rows) {
  return rows.map(r => r.map(csvEscape).join(',')).join('\r\n');
}

// Standard CSV state machine. Returns array of string arrays; blank lines skipped.
function parseCsv(text) {
  const rows = [];
  let row = [], field = '', inQuotes = false;
  const src = String(text ?? '').replace(/^﻿/, ''); // strip Excel BOM
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (inQuotes) {
      if (c === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += c;
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      row.push(field); field = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some(f => f.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some(f => f.trim() !== '')) rows.push(row);
  return rows;
}

// "$18,500.00" / "18500" / "  $1,234 " → integer cents. Blank → null.
function parseMoneyCents(v) {
  const s = String(v ?? '').replace(/[$,\s]/g, '');
  if (s === '') return null;
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) : null;
}

// "2026-06-01", "6/1/2026", "6/1/26" → "2026-06-01". Blank → ''.
// Anything unparseable comes back unchanged (the DB stores dates as text).
function parseDateText(v) {
  const s = String(v ?? '').trim();
  if (!s) return '';
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const m = s.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})$/);
  if (m) {
    let [, mo, d, y] = m;
    if (y.length === 2) y = (Number(y) > 50 ? '19' : '20') + y;
    return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  const t = Date.parse(s);
  return Number.isNaN(t) ? s : new Date(t).toISOString().slice(0, 10);
}

// Header matching: "Phone Number", "phone#", " PHONE  NUMBER " all line up.
function normalizeHeader(h) {
  return String(h ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

module.exports = { toCsv, parseCsv, parseMoneyCents, parseDateText, normalizeHeader, csvEscape };
