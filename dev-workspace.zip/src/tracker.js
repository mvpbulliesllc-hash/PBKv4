// P&L Job Tracker — replaces Joe's spreadsheet 1:1.
// Import accepts his real .xlsx/.csv mess (currency symbols, any common US
// date, blank rows, trailing header spaces). Export produces .xlsx in his
// exact column order plus a totals row. Net Profit / Cost / Profit are
// computed here, never hand-entered. Money is integer cents internally.
const XLSX = require('xlsx');
const { parseMoneyCents, parseDateText, normalizeHeader } = require('./csv-utils');

// Joe's sheet is the source of truth for header spelling and order —
// including "Interior Repir" (his misspelling; the UI spells it correctly).
const EXPORT_HEADERS = ['Date Signed', 'Date Completed', 'Customer Name', 'Job Total',
  'Interior Repir', 'Bathroom', 'Windows Quantity', 'Deck Feet', 'Siding Feet',
  'Roof SQ Size', 'Material Cost', 'Labor Cost', 'Dumpster Cost',
  'Net Profit', 'Cost', 'Profit', 'Notes'];

// normalized import header → [field, kind]
const IMPORT_MAP = {
  'date signed': ['date_signed', 'date'], 'signed': ['date_signed', 'date'],
  'date completed': ['date_completed', 'date'], 'completed': ['date_completed', 'date'],
  'customer name': ['customer_name', 'text'], 'customer': ['customer_name', 'text'], 'name': ['customer_name', 'text'],
  'job total': ['job_total_cents', 'money'], 'total': ['job_total_cents', 'money'],
  'interior repir': ['interior_repair_cents', 'money'], 'interior repair': ['interior_repair_cents', 'money'],
  'bathroom': ['bathroom_cents', 'money'],
  'windows quantity': ['windows_quantity', 'int'], 'windows': ['windows_quantity', 'int'],
  'deck feet': ['deck_feet', 'num'], 'deck': ['deck_feet', 'num'],
  'siding feet': ['siding_feet', 'num'], 'siding': ['siding_feet', 'num'],
  'roof sq size': ['roof_sq_size', 'num'], 'roof sq': ['roof_sq_size', 'num'],
  'roof squares': ['roof_sq_size', 'num'], 'roof': ['roof_sq_size', 'num'],
  'notes': ['notes', 'text'], 'note': ['notes', 'text'],
  'material cost': ['material_cost_cents', 'money'], 'materials': ['material_cost_cents', 'money'],
  'labor cost': ['labor_cost_cents', 'money'], 'labor': ['labor_cost_cents', 'money'],
  'dumpster cost': ['dumpster_cost_cents', 'money'], 'dumpster': ['dumpster_cost_cents', 'money'],
  // computed — recognized so they don't show as "ignored", but never stored
  'net profit': [null, 'computed'], 'cost': [null, 'computed'], 'profit': [null, 'computed'],
};

const FIELDS = ['date_signed', 'date_completed', 'customer_name', 'job_total_cents',
  'interior_repair_cents', 'bathroom_cents', 'windows_quantity', 'deck_feet',
  'siding_feet', 'roof_sq_size', 'material_cost_cents', 'labor_cost_cents',
  'dumpster_cost_cents', 'notes'];

function computed(j) {
  const costs = j.material_cost_cents + j.labor_cost_cents + j.dumpster_cost_cents;
  const net = j.job_total_cents - costs;
  return {
    ...j,
    total_cost_cents: costs,
    net_profit_cents: net,
    cost_pct: j.job_total_cents ? +(costs / j.job_total_cents * 100).toFixed(1) : null,
    profit_pct: j.job_total_cents ? +(net / j.job_total_cents * 100).toFixed(1) : null,
  };
}

// ---- import ------------------------------------------------------------

function cellDate(v) {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === 'number' && v > 20000 && v < 80000) {   // Excel date serial
    return new Date((v - 25569) * 86400000).toISOString().slice(0, 10);
  }
  return parseDateText(v);
}
function cellNum(v) {
  if (typeof v === 'number') return v;
  const n = Number(String(v ?? '').replace(/[$,\s]/g, ''));
  return Number.isFinite(n) ? n : 0;
}
function cellMoney(v) {
  if (typeof v === 'number') return Math.round(v * 100);
  const c = parseMoneyCents(v);
  return c === null ? 0 : c;
}

// file buffer (.xlsx or .csv) → {jobs, headers_matched, headers_ignored} or {error}
function parseWorkbook(buffer) {
  let wb;
  try { wb = XLSX.read(buffer, { type: 'buffer', cellDates: true }); }
  catch { return { error: 'Could not read that file. Save it as Excel (.xlsx) or CSV and try again.' }; }
  const sheet = wb.Sheets[wb.SheetNames[0]];
  if (!sheet) return { error: 'That file has no sheets in it.' };
  const grid = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
  const headerIdx = grid.findIndex(r => r.some(c =>
    IMPORT_MAP[normalizeHeader(c)] && IMPORT_MAP[normalizeHeader(c)][0] === 'customer_name'));
  if (headerIdx === -1) return { error: 'Could not find the header row — the sheet needs a "Customer Name" column.' };

  const headers = grid[headerIdx].map(h => String(h).trim());
  const cols = headers.map(h => IMPORT_MAP[normalizeHeader(h)] || null);
  const headers_matched = headers.filter((h, i) => cols[i] && cols[i][0]);
  // Recognized-but-computed columns (Net Profit / Cost / Profit) aren't
  // "ignored" — the system just recalculates them itself.
  const headers_ignored = headers.filter((h, i) => h && !cols[i]);

  const jobs = [];
  for (const row of grid.slice(headerIdx + 1)) {
    const j = {};
    row.forEach((v, i) => {
      const col = cols[i];
      if (!col || !col[0]) return;
      const [field, kind] = col;
      j[field] = kind === 'money' ? cellMoney(v)
        : kind === 'date' ? cellDate(v)
        : kind === 'int' ? Math.round(cellNum(v))
        : kind === 'num' ? cellNum(v)
        : String(v ?? '').trim();
    });
    const name = String(j.customer_name || '').trim();
    if (!name) continue;                     // blank / spacer rows
    if (/^(grand )?totals?$/i.test(name)) continue;  // our own export's totals row
    for (const f of FIELDS) if (j[f] === undefined) j[f] = /cents|quantity/.test(f) ? 0 : /feet|size/.test(f) ? 0 : '';
    jobs.push(j);
  }
  return { jobs, headers_matched, headers_ignored };
}

// ---- export ------------------------------------------------------------

const $ = { t: 'n', z: '"$"#,##0.00' };
const pct = { t: 'n', z: '0.0%' };
const usDate = (iso) => /^\d{4}-\d{2}-\d{2}$/.test(iso)
  ? `${+iso.slice(5, 7)}/${+iso.slice(8, 10)}/${iso.slice(0, 4)}` : (iso || '');

function buildWorkbook(rows) {
  const aoa = [EXPORT_HEADERS];
  const totals = { job: 0, ir: 0, bath: 0, win: 0, deck: 0, sid: 0, roof: 0, mat: 0, lab: 0, dump: 0, net: 0 };
  for (const raw of rows) {
    const j = computed(raw);
    totals.job += j.job_total_cents; totals.ir += j.interior_repair_cents; totals.bath += j.bathroom_cents;
    totals.win += j.windows_quantity; totals.deck += j.deck_feet; totals.sid += j.siding_feet;
    totals.roof += j.roof_sq_size; totals.mat += j.material_cost_cents; totals.lab += j.labor_cost_cents;
    totals.dump += j.dumpster_cost_cents; totals.net += j.net_profit_cents;
    aoa.push([
      usDate(j.date_signed), usDate(j.date_completed), j.customer_name,
      { ...$, v: j.job_total_cents / 100 }, { ...$, v: j.interior_repair_cents / 100 },
      { ...$, v: j.bathroom_cents / 100 }, j.windows_quantity, j.deck_feet, j.siding_feet, j.roof_sq_size,
      { ...$, v: j.material_cost_cents / 100 }, { ...$, v: j.labor_cost_cents / 100 },
      { ...$, v: j.dumpster_cost_cents / 100 }, { ...$, v: j.net_profit_cents / 100 },
      j.cost_pct === null ? '' : { ...pct, v: j.cost_pct / 100 },
      j.profit_pct === null ? '' : { ...pct, v: j.profit_pct / 100 },
      j.notes,
    ]);
  }
  const totalCosts = totals.mat + totals.lab + totals.dump;
  aoa.push(['', '', 'TOTALS',
    { ...$, v: totals.job / 100 }, { ...$, v: totals.ir / 100 }, { ...$, v: totals.bath / 100 },
    totals.win, totals.deck, totals.sid, totals.roof,
    { ...$, v: totals.mat / 100 }, { ...$, v: totals.lab / 100 }, { ...$, v: totals.dump / 100 },
    { ...$, v: totals.net / 100 },
    totals.job ? { ...pct, v: totalCosts / totals.job } : '',
    totals.job ? { ...pct, v: totals.net / totals.job } : '', '']);
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = EXPORT_HEADERS.map(h => ({ wch: Math.max(h.length + 2, 12) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Jobs');
  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
}

// ---- persistence -------------------------------------------------------

async function saveImported({ all, run }, jobs, userId, NOW) {
  let created = 0, updated = 0;
  for (const j of jobs) {
    const existing = (await all('SELECT id FROM pnl_jobs WHERE LOWER(customer_name)=? AND date_signed=?',
      j.customer_name.toLowerCase(), j.date_signed || ''))[0];
    const cols = FIELDS;
    if (existing) {
      await run(`UPDATE pnl_jobs SET ${cols.map(c => `${c}=?`).join(',')}, updated_by=?, updated_at=${NOW} WHERE id=?`,
        ...cols.map(c => j[c]), userId, existing.id);
      updated++;
    } else {
      await run(`INSERT INTO pnl_jobs (${cols.join(',')}, created_by, updated_by) VALUES (${cols.map(() => '?').join(',')},?,?)`,
        ...cols.map(c => j[c]), userId, userId);
      created++;
    }
  }
  return { created, updated };
}

module.exports = { EXPORT_HEADERS, FIELDS, computed, parseWorkbook, buildWorkbook, saveImported };
