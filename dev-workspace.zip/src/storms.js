// Storm watch: polls the National Weather Service (api.weather.gov, free/no key)
// for active alerts in New Jersey, keeps the roof-damage-relevant ones for the
// South/Central Jersey market, and matches them to CRM leads by county → zip.
const ROOF_DAMAGE_EVENTS = [
  'Severe Thunderstorm Warning', 'Severe Thunderstorm Watch',
  'Tornado Warning', 'Tornado Watch',
  'High Wind Warning', 'High Wind Watch', 'Wind Advisory',
  'Hurricane Warning', 'Hurricane Watch',
  'Tropical Storm Warning', 'Tropical Storm Watch',
  'Coastal Flood Warning', 'Winter Storm Warning', 'Ice Storm Warning',
];

const SOUTH_JERSEY_COUNTIES = [
  'Monmouth', 'Ocean', 'Middlesex', 'Burlington', 'Atlantic', 'Cape May',
  'Camden', 'Gloucester', 'Salem', 'Cumberland', 'Mercer',
];

// Market zips by county — extend as new target cells come online.
const COUNTY_ZIPS = {
  Monmouth: ['07734', '07748', '07730', '07712', '07735', '07740', '07753', '07719'],
  Ocean: ['08753', '08757', '08701', '08723', '08724', '08050'],
};

function severityRank(a) {
  return ({ Extreme: 3, Severe: 2, Moderate: 1 }[a.severity] || 0);
}

async function fetchAlerts() {
  const res = await fetch('https://api.weather.gov/alerts/active?area=NJ', {
    headers: { 'User-Agent': 'ParagonExteriorsCRM/1.0 (j@ecoaisolutions.com)' },
  });
  if (!res.ok) throw new Error('NWS ' + res.status);
  const feed = await res.json();
  return (feed.features || [])
    .map(f => f.properties)
    .filter(p => ROOF_DAMAGE_EVENTS.includes(p.event))
    .map(p => {
      const counties = SOUTH_JERSEY_COUNTIES.filter(c => (p.areaDesc || '').includes(c));
      return {
        nws_id: p.id,
        event: p.event,
        severity: p.severity || '',
        headline: p.headline || '',
        area: p.areaDesc || '',
        counties,
        zips: [...new Set(counties.flatMap(c => COUNTY_ZIPS[c] || []))],
        onset: p.onset || '',
        ends: p.ends || p.expires || '',
      };
    })
    .filter(a => a.counties.length)
    .sort((a, b) => severityRank(b) - severityRank(a));
}

// Change-detected fetch; onNew fires once per newly-seen alert id.
// background:true = classic poll loop (long-running server). background:false
// (serverless) = no timer; the API route calls refresh() when data is stale.
function startStormWatch({ intervalMs = 15 * 60 * 1000, onNew, log = console.log, background = true }) {
  let current = [];
  let lastFetch = 0;
  const seen = new Set();
  const tick = async () => {
    try {
      current = await fetchAlerts();
      lastFetch = Date.now();
      for (const a of current) {
        if (!seen.has(a.nws_id)) {
          seen.add(a.nws_id);
          log(`[storm-watch] ${a.event} — ${a.counties.join(', ')}`);
          if (onNew) onNew(a);
        }
      }
      if (seen.size > 2000) seen.clear();
    } catch (e) {
      log('[storm-watch] poll failed: ' + e.message);
    }
  };
  let timer = null;
  if (background) {
    tick();
    timer = setInterval(tick, intervalMs);
    timer.unref && timer.unref();
  }
  return {
    getAlerts: () => current,
    ageMs: () => Date.now() - lastFetch,
    stop: () => timer && clearInterval(timer),
    refresh: tick,
  };
}

module.exports = { startStormWatch, fetchAlerts, ROOF_DAMAGE_EVENTS, COUNTY_ZIPS };
